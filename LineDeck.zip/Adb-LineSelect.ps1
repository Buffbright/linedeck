﻿<#
.SYNOPSIS
  หน้า "เลือก" เพื่อนใน LINE (เช่น สร้างกลุ่ม / เชิญเข้ากลุ่ม) บน LDPlayer ผ่าน ADB
  - แตะวงกลมสีขาว (ยังไม่เลือก) ตามจำนวน -Count
  - วงกลมสีเขียว (เลือกแล้ว) จะข้าม ไม่กดซ้ำ
  - กดทุกวงในหน้าจอด้วยคำสั่ง adb ครั้งเดียว (เร็ว) แล้วถ่ายภาพตรวจซ้ำว่าเปลี่ยนเป็นสีเขียวจริง
    วงที่กดไม่ติดจะกดซ้ำให้อัตโนมัติ
  - ถ้าในหน้าจอไม่พอ จะเลื่อนลงแล้วทำต่อจนครบหรือจนสุดรายการ
  - ตอนจบตรวจตัวเลข "เลือก N" บนหัวจอว่าเพิ่มขึ้นครบตามจำนวนหรือไม่
  ต้องเปิดหน้าเลือกเพื่อนค้างไว้ก่อนสั่ง
.OUTPUTS
  JSON บรรทัดเดียว:
  {"ok":true,"requested":10,"selected":10,"tapped":11,"retried":1,"before":1,"after":11,"headerOk":true,...}
  selected = จำนวนที่ตรวจแล้วว่าเป็นสีเขียวจริง
  Exit code 0 = ครบและตรวจผ่าน, 1 = ไม่ครบ / ตรวจไม่ผ่าน, 2 = ผิดพลาด
#>
param(
    [string]$Adb          = '',
    [string]$Serial       = '',
    [int]$Count           = 1,
    [string]$OutDir       = '',
    [int]$MaxScrolls      = 60,
    [int]$Retries         = 2,      # กดซ้ำวงที่ยังไม่เขียว กี่รอบต่อหน้าจอ
    [int]$SettleMs        = 250,    # รอหลังกดก่อนถ่ายภาพตรวจ
    [int]$ScrollDelayMs   = 450,    # รอหลังเลื่อนหน้าจอ
    [switch]$All,                   # ติ๊กทุกวงจนถึงล่างสุด แล้วย้อนตรวจซ้ำอีกรอบให้เขียวหมด
    [string]$ExcludeB64   = ''      # base64(UTF-8 JSON array): ชื่อที่ห้ามติ๊ก (มีคำนี้อยู่ในชื่อ = ข้าม)
)

$ErrorActionPreference = 'Stop'
function Out-Result($o, [int]$code) {
    $json = $o | ConvertTo-Json -Compress -Depth 5
    # escape non-ASCII (Thai names) so the result survives console-codepage redirection
    $json = [regex]::Replace($json, '[^\x00-\x7F]', [System.Text.RegularExpressions.MatchEvaluator]{ param($m) '\u{0:x4}' -f [int][char]$m.Value })
    $json
    exit $code
}

# ---------- Find adb ----------
if (-not $Adb) {
    $cands = @('C:\LDPlayer\LDPlayer9\adb.exe', 'C:\LDPlayer\LDPlayer4.0\adb.exe', 'D:\LDPlayer\LDPlayer9\adb.exe', "$env:ProgramFiles\LDPlayer\LDPlayer9\adb.exe")
    $p = Get-Process -Name 'dnplayer', 'Ld9BoxHeadless' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($p -and $p.Path) { $cands = @((Join-Path (Split-Path $p.Path) 'adb.exe')) + $cands }
    $Adb = $cands | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (-not $Adb) { $c = Get-Command adb -ErrorAction SilentlyContinue; if ($c) { $Adb = $c.Source } }
}
if (-not $Adb -or -not (Test-Path $Adb)) { Out-Result @{ ok = $false; error = 'adb.exe not found, specify -Adb' } 2 }
if (-not $All -and $Count -lt 1) { Out-Result @{ ok = $false; error = 'Count must be at least 1' } 2 }

function Invoke-Adb([string[]]$a) {
    $all = @(); if ($Serial) { $all += @('-s', $Serial) }; $all += $a
    $old = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { return (& $Adb @all 2>&1 | Out-String) } finally { $ErrorActionPreference = $old }
}

if (-not $OutDir) { $OutDir = Join-Path $env:TEMP 'adb_line' }
[void][System.IO.Directory]::CreateDirectory($OutDir)
$safeSerial = ($Serial -replace '[^\w\-\.]', '_')

# ---------- Pixel scanner (green = selected, gray ring = empty circle) ----------
Add-Type -AssemblyName System.Drawing
if (-not ('LineSelPx' -as [type])) {
    Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition @'
using System; using System.Drawing; using System.Drawing.Imaging; using System.Runtime.InteropServices;
public class LineSelShot : IDisposable {
    public int Width, Height; int[] px;
    public LineSelShot(int w, int h, int[] pixels) { Width = w; Height = h; px = pixels; }
    public LineSelShot(Bitmap bmp) {
        Width = bmp.Width; Height = bmp.Height;
        var d = bmp.LockBits(new Rectangle(0, 0, Width, Height), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        px = new int[Width * Height];
        Marshal.Copy(d.Scan0, px, 0, px.Length);
        bmp.UnlockBits(d);
    }
    // returns: green, ring, minX, minY, maxX, maxY  (bbox of green+ring pixels, -1 if none)
    public int[] Scan(int x1, int y1, int x2, int y2) {
        x1 = Math.Max(0, x1); y1 = Math.Max(0, y1);
        x2 = Math.Min(Width - 1, x2); y2 = Math.Min(Height - 1, y2);
        int[] r = new int[] { 0, 0, -1, -1, -1, -1 };
        if (x2 <= x1 || y2 <= y1) return r;
        int minX = int.MaxValue, minY = int.MaxValue, maxX = -1, maxY = -1;
        for (int y = y1; y <= y2; y++) {
            int row = y * Width;
            for (int x = x1; x <= x2; x++) {
                int c = px[row + x];
                int R = (c >> 16) & 0xFF, G = (c >> 8) & 0xFF, B = c & 0xFF;
                bool green = G > 140 && G - R > 70 && G - B > 40;
                int mx = Math.Max(R, Math.Max(G, B)), mn = Math.Min(R, Math.Min(G, B));
                bool ring = !green && (mx - mn) < 18 && mx >= 60 && mx <= 238;
                if (green) r[0]++;
                if (ring) r[1]++;
                if (green || ring) {
                    if (x < minX) minX = x;
                    if (y < minY) minY = y;
                    if (x > maxX) maxX = x;
                    if (y > maxY) maxY = y;
                }
            }
        }
        if (maxX >= 0) { r[2] = minX; r[3] = minY; r[4] = maxX; r[5] = maxY; }
        return r;
    }
    // scan a vertical strip; returns groups of 5 ints per circle: cx, cy, size, greenPixels, ringPixels
    public int[] FindCircles(int x1, int y1, int x2, int y2, int minD, int maxD) {
        x1 = Math.Max(0, x1); y1 = Math.Max(0, y1);
        x2 = Math.Min(Width - 1, x2); y2 = Math.Min(Height - 1, y2);
        int[] buf = new int[5 * 1000]; int n = 0;
        if (x2 <= x1 || y2 <= y1) return new int[0];
        int start = -1, lastHit = -1, g = 0, r = 0, minX = int.MaxValue, maxX = -1;
        for (int y = y1; y <= y2 + 3; y++) {
            int rg = 0, rr = 0, rmin = int.MaxValue, rmax = -1;
            if (y <= y2) {
                int row = y * Width;
                for (int x = x1; x <= x2; x++) {
                    int c = px[row + x];
                    int R = (c >> 16) & 0xFF, G = (c >> 8) & 0xFF, B = c & 0xFF;
                    bool green = G > 140 && G - R > 70 && G - B > 40;
                    int mx = Math.Max(R, Math.Max(G, B)), mn = Math.Min(R, Math.Min(G, B));
                    bool ring = !green && (mx - mn) < 18 && mx >= 60 && mx <= 238;
                    if (green) rg++;
                    if (ring) rr++;
                    if (green || ring) { if (x < rmin) rmin = x; if (x > rmax) rmax = x; }
                }
            }
            if (rg + rr > 0) {
                if (start < 0) { start = y; g = 0; r = 0; minX = int.MaxValue; maxX = -1; }
                g += rg; r += rr;
                if (rmin < minX) minX = rmin;
                if (rmax > maxX) maxX = rmax;
                lastHit = y;
            } else if (start >= 0 && y - lastHit > 2) {
                int h = lastHit - start + 1, w = maxX - minX + 1;
                bool inside = minX > x1 + 1 && maxX < x2 - 1;      // fully inside the strip (not a wide bar / button)
                bool round = w >= h * 0.6 && w <= h * 1.5;
                if (h >= minD && h <= maxD && inside && round && n + 5 <= buf.Length) {
                    buf[n++] = (minX + maxX) / 2; buf[n++] = (start + lastHit) / 2; buf[n++] = Math.Max(h, w); buf[n++] = g; buf[n++] = r;
                }
                start = -1;
            }
        }
        int[] res = new int[n];
        Array.Copy(buf, res, n);
        return res;
    }
    public void Dispose() { px = null; }
}
public static class LineSelPx { public static int Version = 2; }
'@
}

# ---------- Screen helpers ----------
$script:N = 0
function Get-Ui {
    for ($i = 1; $i -le 3; $i++) {
        $script:N++
        $local = Join-Path $OutDir ("sel_{0}_{1}.xml" -f $safeSerial, $script:N)
        [void](Invoke-Adb @('shell', 'uiautomator dump /sdcard/__linesel.xml >/dev/null 2>&1'))
        [void](Invoke-Adb @('pull', '/sdcard/__linesel.xml', $local))
        if (Test-Path -LiteralPath $local) {
            try {
                [xml]$x = [System.IO.File]::ReadAllText($local, [System.Text.Encoding]::UTF8)
                Remove-Item -LiteralPath $local -Force -ErrorAction SilentlyContinue
                $nodes = New-Object System.Collections.ArrayList
                foreach ($n in $x.SelectNodes('//node')) {
                    $b = [string]$n.bounds
                    if ($b -match '\[(-?\d+),(-?\d+)\]\[(-?\d+),(-?\d+)\]') {
                        [void]$nodes.Add([pscustomobject]@{
                            Text      = ([string]$n.text).Trim()
                            Desc      = ([string]$n.'content-desc').Trim()
                            Class     = [string]$n.class
                            Click     = ([string]$n.clickable -eq 'true')
                            Checkable = ([string]$n.checkable -eq 'true')
                            Checked   = ([string]$n.checked -eq 'true')
                            X1 = [int]$Matches[1]; Y1 = [int]$Matches[2]; X2 = [int]$Matches[3]; Y2 = [int]$Matches[4]
                        })
                    }
                }
                if ($nodes.Count -gt 0) { return , $nodes.ToArray() }
            } catch { }
        }
        Start-Sleep -Milliseconds 400
    }
    return , @()
}
function Get-Shot {
    $local = Join-Path $OutDir ("sel_{0}.png" -f $safeSerial)
    Remove-Item -LiteralPath $local -Force -ErrorAction SilentlyContinue
    [void](Invoke-Adb @('shell', 'screencap -p /sdcard/__linesel.png'))
    [void](Invoke-Adb @('pull', '/sdcard/__linesel.png', $local))
    if (-not (Test-Path -LiteralPath $local)) { throw 'ถ่ายภาพหน้าจอไม่สำเร็จ' }
    $bytes = [System.IO.File]::ReadAllBytes($local)
    if ($bytes.Length -gt 15 -and [System.Text.Encoding]::ASCII.GetString($bytes, 0, 7) -eq 'RAWARGB') {
        $w = [BitConverter]::ToInt32($bytes, 7); $h = [BitConverter]::ToInt32($bytes, 11)
        $px = New-Object int[] ($w * $h)
        [Buffer]::BlockCopy($bytes, 15, $px, 0, $w * $h * 4)
        return (New-Object LineSelShot($w, $h, $px))
    }
    $fs = [System.IO.File]::OpenRead($local)
    try {
        $img = [System.Drawing.Image]::FromStream($fs)
        $bmp = New-Object System.Drawing.Bitmap($img)
        $img.Dispose()
        try { return (New-Object LineSelShot($bmp)) } finally { $bmp.Dispose() }
    } finally { $fs.Dispose() }
}
function Get-SelectedCount($nodes) {
    foreach ($n in $nodes) {
        foreach ($t in @($n.Text, $n.Desc)) {
            if (-not $t) { continue }
            $m = [regex]::Match($t, '(?i)^\s*(เลือก|select(?:ed)?|選択|선택)\s*\(?\s*(\d+)\s*\)?\s*$')
            if ($m.Success) { return [int]$m.Groups[2].Value }
        }
    }
    return $null
}

# แถวรายชื่อ: กว้างเกือบเต็มจอ สูงพอดีแถว อยู่ใต้แถบค้นหา และมีชื่ออยู่ข้างใน
function Get-Rows($nodes, [int]$W, [int]$H) {
    $minY = [int]($H * 0.10)
    $search = '(?i)(ค้นหา|search|検索|검색)'
    $cand = @($nodes | Where-Object {
            ($_.Click -or $_.Checkable) -and
            ($_.X2 - $_.X1) -ge ($W * 0.6) -and
            ($_.Y2 - $_.Y1) -ge ($H * 0.035) -and ($_.Y2 - $_.Y1) -le ($H * 0.16) -and
            $_.Y1 -ge $minY -and $_.Y2 -le ($H - 4) -and
            $_.Class -notmatch 'EditText'
        })
    $rows = @()
    foreach ($c in $cand) {
        # keep the innermost row only
        $inner = @($cand | Where-Object { $_ -ne $c -and $_.X1 -ge $c.X1 -and $_.X2 -le $c.X2 -and $_.Y1 -ge $c.Y1 -and $_.Y2 -le $c.Y2 -and (($_.Y2 - $_.Y1) -lt ($c.Y2 - $c.Y1)) })
        if ($inner.Count) { continue }
        $texts = @($nodes | Where-Object { $_.Text -and $_.X1 -ge $c.X1 -and $_.X2 -le $c.X2 -and $_.Y1 -ge $c.Y1 -and $_.Y2 -le $c.Y2 } | Sort-Object X1)
        $name = if ($texts.Count) { $texts[0].Text } else { '' }
        if (-not $name) {
            # name only in the description (no text): the left-most labelled node that is not the circle
            $descs = @($nodes | Where-Object { $_.Desc -and -not $_.Checkable -and $_.X1 -ge $c.X1 -and $_.X2 -le $c.X2 -and $_.Y1 -ge $c.Y1 -and $_.Y2 -le $c.Y2 -and $_.X1 -lt ($c.X1 + ($c.X2 - $c.X1) * 0.7) } | Sort-Object X1)
            if ($descs.Count) { $name = $descs[0].Desc }
        }
        if ($name -match $search) { continue }
        $chk = @($nodes | Where-Object { $_.Checkable -and $_.X1 -ge $c.X1 -and $_.X2 -le $c.X2 -and $_.Y1 -ge $c.Y1 -and $_.Y2 -le $c.Y2 })
        $rows += [pscustomobject]@{
            Name = $name; X1 = $c.X1; Y1 = $c.Y1; X2 = $c.X2; Y2 = $c.Y2
            HasAttr = [bool]$chk.Count; AttrChecked = [bool](@($chk | Where-Object { $_.Checked }).Count)
        }
    }
    # fallback: rows not marked clickable -> build rows from the name labels
    if (-not $rows.Count) {
        $labels = @($nodes | Where-Object {
                $lt = if ($_.Text) { $_.Text } else { $_.Desc }
                $lt -and $lt -notmatch $search -and -not $_.Checkable -and
                $_.X1 -ge ($W * 0.12) -and $_.X1 -le ($W * 0.5) -and
                $_.Y1 -ge $minY -and ($_.Y2 - $_.Y1) -le ($H * 0.06) -and $_.Y2 -le ($H - 4)
            })
        foreach ($l in $labels) {
            $pad = [int][Math]::Max(($l.Y2 - $l.Y1), ($H * 0.02))
            $rows += [pscustomobject]@{
                Name = $(if ($l.Text) { $l.Text } else { $l.Desc }); X1 = 0; Y1 = [Math]::Max($minY, $l.Y1 - $pad); X2 = $W; Y2 = [Math]::Min($H - 1, $l.Y2 + $pad)
                HasAttr = $false; AttrChecked = $false
            }
        }
    }
    $seen = @{}
    return , @($rows | Sort-Object Y1 | Where-Object { $k = "$($_.X1),$($_.Y1),$($_.X2),$($_.Y2)"; if ($seen.ContainsKey($k)) { $false } else { $seen[$k] = $true; $true } })
}

# สถานะวงกลมของแถวจากภาพหน้าจอ: 'green' / 'white' / 'none'  + จุดกด
function Get-RowState($shot, $r, [int]$W, [int]$H) {
    $sx = $shot.Width / [double]$W
    $sy = $shot.Height / [double]$H
    $rh = $r.Y2 - $r.Y1
    $x1 = [int](($r.X2 - $W * 0.18) * $sx); $x2 = [int](($r.X2 - 2) * $sx)
    $y1 = [int](($r.Y1 + $rh * 0.12) * $sy); $y2 = [int](($r.Y2 - $rh * 0.12) * $sy)
    $s = $shot.Scan($x1, $y1, $x2, $y2)
    $state = 'none'
    if ($s[0] -ge 40) { $state = 'green' }
    elseif ($s[1] -ge 12 -or $r.HasAttr) { $state = 'white' }
    if ($s[2] -ge 0) {
        $tx = [int]((($s[2] + $s[4]) / 2) / $sx)
        $ty = [int]((($s[3] + $s[5]) / 2) / $sy)
    } else {
        $tx = [int]($r.X2 - $W * 0.08)
        $ty = [int](($r.Y1 + $r.Y2) / 2)
    }
    return [pscustomobject]@{ State = $state; X = $tx; Y = $ty }
}

# หาวงกลมทุกวงจากภาพ (ไม่พึ่งโครงสร้างหน้าจอ) ตั้งแต่บนสุดของรายการจนถึงขอบล่างของจอ
function Get-Circles($shot, $rows, [int]$W, [int]$H) {
    $sx = $shot.Width / [double]$W
    $sy = $shot.Height / [double]$H
    $topUi = if (@($rows).Count) { [int](@($rows)[0].Y1) } else { [int]($H * 0.30) }
    $raw = $shot.FindCircles([int]($W * 0.78 * $sx), [int]($topUi * $sy), $shot.Width - 1, $shot.Height - 1,
                             [int]([Math]::Max(8, $shot.Height * 0.012)), [int]($shot.Height * 0.07))
    $out = @()
    for ($i = 0; $i + 4 -lt $raw.Count; $i += 5) {
        $d = [double]$raw[$i + 2]
        $green = ($raw[$i + 3] -ge [Math]::Max(30, 0.30 * $d * $d))
        # filled grey circle = already a member / cannot be selected (not an empty white ring)
        $disabled = (-not $green) -and ($raw[$i + 4] -ge 0.35 * $d * $d)
        $cx = [int]($raw[$i] / $sx); $cy = [int]($raw[$i + 1] / $sy)
        $row = @($rows | Where-Object { $_.Y1 -le $cy -and $_.Y2 -ge $cy } | Select-Object -First 1)
        $name = if ($row.Count) { [string]$row[0].Name } else { '' }
        $out += [pscustomobject]@{ X = $cx; Y = $cy; D = [int]($d / $sy); State = $(if ($green) { 'green' } elseif ($disabled) { 'disabled' } else { 'white' }); Name = $name }
    }
    return , $out
}
function Get-CircleAt($circles, [int]$y, [int]$d) {
    $tol = [Math]::Max(6, [int]($d * 0.6))
    $hit = @($circles | Where-Object { [Math]::Abs($_.Y - $y) -le $tol } | Select-Object -First 1)
    if ($hit.Count) { return $hit[0] }
    return $null
}

# กดหลายจุดด้วยคำสั่ง adb ครั้งเดียว
function Invoke-Taps($points) {
    if (-not @($points).Count) { return }
    $cmd = (@($points) | ForEach-Object { "input tap $($_.X) $($_.Y)" }) -join '; '
    [void](Invoke-Adb @('shell', $cmd))
}

# เลื่อนกลับขึ้นบนสุดของรายการ (ปัดเร็ว ๆ จนรายชื่อบนจอไม่เปลี่ยน)
function Invoke-ScrollToTop([int]$W, [int]$H) {
    $x = [int]($W * 0.5)
    $prev = ''
    for ($k = 0; $k -lt 200; $k++) {
        for ($f = 0; $f -lt 3; $f++) {
            [void](Invoke-Adb @('shell', "input swipe $x $([int]($H * 0.30)) $x $([int]($H * 0.92)) 120"))
            Start-Sleep -Milliseconds 120
        }
        Start-Sleep -Milliseconds 500
        $rows = Get-Rows (Get-Ui) $W $H
        $sig = (@($rows | ForEach-Object { "$($_.Name)@$($_.Y1)" }) -join '|')
        if ($sig -eq $prev) { return }
        $prev = $sig
    }
}

try {
    if (-not $Serial) {
        $dev = (Invoke-Adb @('devices')) -split "`r?`n" | Where-Object { $_ -match '^\S+\s+device$' } | Select-Object -First 1
        if (-not $dev) { Out-Result @{ ok = $false; error = 'No ADB device found' } 2 }
        $Serial = ($dev -split '\s+')[0]
        $safeSerial = ($Serial -replace '[^\w\-\.]', '_')
    }

    $W = 720; $H = 1280
    $ws = Invoke-Adb @('shell', 'wm size')
    $sm = [regex]::Matches($ws, '(\d{3,5})x(\d{3,5})')
    if ($sm.Count -gt 0) { $W = [int]$sm[$sm.Count - 1].Groups[1].Value; $H = [int]$sm[$sm.Count - 1].Groups[2].Value }

    $nodes = Get-Ui
    if (-not $nodes.Count) { Out-Result @{ ok = $false; serial = $Serial; error = 'อ่านหน้าจอไม่ได้ (uiautomator)' } 2 }
    $before = Get-SelectedCount $nodes

    $verified = 0         # ตรวจแล้วว่าเป็นสีเขียวจริง
    $tapped = 0           # จำนวนครั้งที่กดทั้งหมด
    $retried = 0
    $failedRows = 0       # กดซ้ำแล้วก็ยังไม่เขียว
    $skippedGreen = 0
    $names = @()
    $endOfList = $false
    $lastSig = ''
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $sweeps = if ($All) { 2 } else { 1 }
    $limit = if ($All) { [Math]::Max($MaxScrolls, 600) } else { $MaxScrolls }
    $failedFinal = 0      # วงที่ยังขาวอยู่ในรอบสุดท้าย
    $greenSeen = @{}      # ชื่อที่เป็นสีเขียวอยู่แล้วตั้งแต่ก่อนเริ่ม (นับครั้งเดียว)
    $tappedNames = @{}
    $failedNames = @{}
    $exclude = @()
    if ($ExcludeB64) { $exclude = @(([System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($ExcludeB64)) | ConvertFrom-Json) | ForEach-Object { (([string]$_) -replace '\s+', ' ').Trim().ToLowerInvariant() } | Where-Object { $_ }) }
    $excludedNames = @{}
    $unknownNames = 0
    $fixedInCheck = 0     # รอบตรวจซ้ำ เจอวงขาวที่หลุดแล้วกดให้เขียว
    for ($sweep = 0; $sweep -lt $sweeps; $sweep++) {
    if ($sweep -gt 0) {
        Invoke-ScrollToTop $W $H
        $nodes = Get-Ui
        $lastSig = ''
        $endOfList = $false
    }
    $failedFinal = 0
    $failedNames = @{}
    for ($pass = 0; $pass -le $limit; $pass++) {
        if ($pass -gt 0) { $nodes = Get-Ui }
        $rows = Get-Rows $nodes $W $H
        # 1) หาวงกลมทุกวงจากภาพเดียว (รวมแถวล่างสุดที่โดนขอบจอ) แล้วเลือกวงสีขาวเท่าที่ยังขาด
        $shot = Get-Shot
        $circles = Get-Circles $shot $rows $W $H
        $shot.Dispose()
        if (-not $rows.Count -and -not $circles.Count -and $pass -eq 0 -and $sweep -eq 0) {
            Out-Result @{ ok = $false; serial = $Serial; error = 'ไม่พบรายชื่อในหน้าจอ กรุณาเปิดหน้า "เลือก" เพื่อนใน LINE ค้างไว้ก่อน' } 1
        }
        $todo = @()
        foreach ($c in $circles) {
            $nk = if ($c.Name) { $c.Name } else { "y$($c.Y)#$sweep#$pass" }
            if ($c.State -eq 'disabled') { continue }   # already in the group / not selectable
            if ($exclude.Count -and $c.State -ne 'green') {
                if ($c.Name) {
                    $k0 = (($c.Name -replace '\s+', ' ').Trim().ToLowerInvariant())
                    if (@($exclude | Where-Object { $k0.Contains($_) }).Count) { $excludedNames[$c.Name] = $true; continue }   # name on the "do not tick" list
                } else { $unknownNames++ }
            }
            if ($c.State -eq 'green') {
                if ($sweep -eq 0 -and -not $tappedNames.ContainsKey($nk) -and -not $greenSeen.ContainsKey($nk)) { $greenSeen[$nk] = $true; $skippedGreen++ }
                continue
            }
            if (-not $All -and ($verified + $todo.Count) -ge $Count) { break }
            $todo += [pscustomobject]@{ X = $c.X; Y = $c.Y; D = $c.D; Key = $nk; Name = $c.Name }
        }

        # 2) กดทั้งหมดในครั้งเดียว แล้วถ่ายภาพตรวจ กดซ้ำเฉพาะวงที่ยังไม่เขียว
        $pending = @($todo)
        for ($attempt = 0; $attempt -le $Retries -and $pending.Count; $attempt++) {
            if ($attempt -gt 0) { $retried += $pending.Count }
            Invoke-Taps $pending
            $tapped += $pending.Count
            Start-Sleep -Milliseconds $SettleMs
            $shot = Get-Shot
            $now = Get-Circles $shot $rows $W $H
            $shot.Dispose()
            $still = @()
            foreach ($t in $pending) {
                $c = Get-CircleAt $now $t.Y $t.D
                if ($c -and $c.State -eq 'green') {
                    $verified++; $names += $t.Name
                    $tappedNames[$t.Key] = $true; [void]$failedNames.Remove($t.Key)
                    if ($sweep -gt 0) { $fixedInCheck++ }
                }
                else { $still += $t }
            }
            $pending = $still
        }
        foreach ($pf in $pending) {
            if (-not $failedNames.ContainsKey($pf.Key)) { $failedNames[$pf.Key] = $true; $failedRows++ }
        }
        $failedFinal = $failedNames.Count
        if (-not $All -and $verified -ge $Count) { break }

        # 3) สุดรายการ: รายชื่อและวงกลมที่เห็นไม่เปลี่ยนหลังเลื่อน
        $sig = (@($rows | ForEach-Object { "$($_.Name)@$($_.Y1)" }) -join '|') + '#' + (@($circles | ForEach-Object { $_.Y }) -join ',')
        if ($pass -gt 0 -and $sig -eq $lastSig) { $endOfList = $true; break }
        $lastSig = $sig

        # 4) เลื่อนลง: ลากแถวสุดท้ายที่เห็นขึ้นไปไว้ตำแหน่งแถวแรก (ซ้อนกัน 1 แถว จึงไม่ข้ามใคร)
        $x = [int]($W * 0.5)
        if ($rows.Count -ge 2) {
            $first = $rows[0]; $last = $rows[$rows.Count - 1]
            $fromY = [int](($last.Y1 + $last.Y2) / 2)
            $toY = [int](($first.Y1 + $first.Y2) / 2)
        } elseif ($circles.Count -ge 2) {
            $fromY = $circles[$circles.Count - 1].Y
            $toY = $circles[0].Y
        } else {
            $fromY = [int]($H * 0.80); $toY = [int]($H * 0.45)
        }
        [void](Invoke-Adb @('shell', "input swipe $x $fromY $x $toY 600"))
        Start-Sleep -Milliseconds $ScrollDelayMs
    }
    }

    # 5) ตรวจตัวเลข "เลือก N" บนหัวจอ
    Start-Sleep -Milliseconds 300
    $after = Get-SelectedCount (Get-Ui)
    [void](Invoke-Adb @('shell', 'rm -f /sdcard/__linesel.xml /sdcard/__linesel.png'))
    $headerOk = $null
    if ($All) {
        if ($null -ne $before -and $null -ne $after) { $headerOk = (($after - $before) -eq $verified) }
        $ok = $endOfList -and ($failedFinal -eq 0) -and ($headerOk -ne $false)
    } else {
        if ($null -ne $before -and $null -ne $after) { $headerOk = (($after - $before) -ge [Math]::Min($Count, $verified)) -and ($verified -ge $Count) }
        $ok = ($verified -ge $Count) -and ($headerOk -ne $false)
    }
    $res = [ordered]@{
        ok = [bool]$ok; serial = $Serial; all = [bool]$All; requested = $(if ($All) { -1 } else { $Count }); selected = $verified
        whiteLeft = $failedFinal; fixedInCheck = $fixedInCheck; tapped = $tapped; retried = $retried
        failed = $failedRows; skippedGreen = $skippedGreen; before = $before; after = $after; headerOk = $headerOk
        endOfList = $endOfList; seconds = [Math]::Round($sw.Elapsed.TotalSeconds, 1); names = @($names)
        excluded = @($excludedNames.Keys); noName = $unknownNames
    }
    if (-not $ok -and $All) {
        if (-not $endOfList) { $res.error = "ยังไปไม่ถึงล่างสุดของรายการ (เลื่อนเกิน $limit ครั้ง)" }
        elseif ($failedFinal -gt 0) { $res.error = "ยังมีวงสีขาวเหลือ $failedFinal แถว (กดแล้วไม่ติด อาจเลือกได้เต็มจำนวนที่ LINE กำหนดแล้ว)" }
        else { $res.error = "ตัวเลขบนหัวจอไม่ตรง: เลือก $before -> $after (ควรเพิ่ม $verified)" }
    } elseif (-not $ok) {
        if ($verified -lt $Count) {
            $res.error = if ($endOfList) { "สุดรายการแล้ว เลือกได้ $verified จาก $Count" } else { "เลือกได้ $verified จาก $Count" }
            if ($failedRows) { $res.error += " (กดไม่ติด $failedRows แถว)" }
        } else {
            $res.error = "ตัวเลขบนหัวจอไม่ตรง: เลือก $before -> $after (ควรเพิ่ม $Count)"
        }
    }
    Out-Result $res ([int](-not $ok))
}
catch {
    Out-Result @{ ok = $false; serial = $Serial; error = $_.Exception.Message } 2
}
