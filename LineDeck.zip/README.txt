Run PowerShell: powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\LineDeck.ps1
Select LD devices by checkbox, right-click to start in parallel or stop.
