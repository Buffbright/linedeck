﻿<#
.SYNOPSIS
  In LINE on LDPlayer via ADB (precise mode):
    Step 1: tap "add friend"
    Step 2: tap "search"
    Step 3: choose ID / phone number
    Step 4+: for each entry: type -> verify typed text -> search -> wait for result -> tap "add" -> verify added
  Every tap waits until the target is on screen AND not moving (two identical reads in a row),
  and every step is verified before the next one starts. Screen text is read as a UTF-8 file
  (not through the console), so Thai / Japanese / Korean button names match correctly.
  Image matching is only a last resort when the element cannot be found by name.
.OUTPUTS
  JSON: {"ok":true,"serial":"..","steps":[{"step":"addfriend","found":true,"method":"..","x":..,"y":..},...],"rounds":[...]}
  Exit code 0 = all steps done, 1 = some step not found, 2 = error
.EXAMPLE
  .\Adb-LineAddFriend.ps1 -LaunchLine
#>
param(
    [string]$Adb          = '',
    [string]$Serial       = '',
    [string]$Package      = 'jp.naver.line.android',

    # Step 1: add friend
    [string]$AddTemplate  = (Join-Path $PSScriptRoot 'addfriend.png'),
    [string]$AddName      = '(?i)^\s*(add\s*friends?|เพิ่มเพื่อน|友だち追加|친구\s*추가)\s*$',
    [string]$AddId        = '(?i)add_?friend',

    # Step 2: search
    [string]$SearchTemplate = (Join-Path $PSScriptRoot 'search.png'),
    [string]$SearchName     = '(?i)^\s*(search|ค้นหา|検索|검색)\s*$',
    [string]$SearchId       = '(?i)search',

    # Step 3-5: type text, search, add friend
    [string]$Text         = '',     # single ID/phone number (overrides config.json)
    [string[]]$Texts      = @(),    # multiple entries, one per round, e.g. -Texts id1,id2 (duplicates are removed)
    [ValidateSet('','ID','Phone')][string]$SearchBy = '',
    [string]$ConfigPath   = (Join-Path $PSScriptRoot 'config.json'),   # {"text":"myid","searchBy":"ID"}
    [string]$IdTabName    = '(?i)^\s*ID\s*$',
    [string]$PhoneTabName = '(?i)^\s*(phone\s*number|หมายเลขโทรศัพท์|เบอร์โทรศัพท์|電話番号|전화번호)\s*$',
    [string]$AddBtnName   = '(?i)^\s*(\+\s*)?(add|add\s*friends?|add\s*as\s*friend|เพิ่ม|เพิ่มเพื่อน|เพิ่มเป็นเพื่อน|追加|友だち追加|추가|친구\s*추가)\s*$',
    [string]$ConfirmName  = '(?i)^\s*(ok|yes|confirm|add|ตกลง|ยืนยัน|ใช่|เพิ่ม|確認|はい|追加|확인|예|추가)\s*$',
    [string]$AddBtnTemplate = (Join-Path $PSScriptRoot 'addbtn.png'),
    [string]$NotFoundText = '(?i)(not\s*found|no\s*results?|doesn.?t\s*exist|ไม่พบ|ไม่มีผู้ใช้|見つかりません|존재하지\s*않|찾을\s*수\s*없)',
    [string]$HomeName     = '(?i)^\s*(home|หน้าหลัก|ホーム|홈)\s*$',
    [string]$HomeId       = '(?i)(bnb_home|tab_home|home_tab|main_tab_home|bottom_navigation_home)',
    [switch]$GoHomeEachId,          # old behaviour: return to the LINE home screen after every ID
    [switch]$CreateGroup,           # after all IDs: group step (see -GroupAction)
    [switch]$GroupOnly,             # skip the IDs, only do the group step
    [ValidateSet('auto','invite','create')][string]$GroupAction = 'auto',
    [switch]$CheckOnly,
    [switch]$NameOnly,              # only read our own LINE name from the home screen, then stop
    [switch]$CreateWithNames,       # with -CreateGroup -GroupAction create: search + tick the names scanned from the IDs first
    [string]$PreTickB64   = '',     # base64(UTF-8 JSON array): names / first letters to search and tick on the invite screen BEFORE the normal circle ticking
    [string]$ReplaceOaB64 = '',     # base64(UTF-8 JSON array): names of broken OAs -> remove them from every group with > MinMembers members, add the new OA (IDs), invite it back
    [int]$MinMembers      = 50,     # "groups with more than N members"
    [string]$MembersName  = '(?i)^\s*(members?|สมาชิก|メンバー|멤버)\s*\(?\s*\d*\s*\)?\s*$',
    [string]$EditName     = '(?i)^\s*(edit|แก้ไข|編集|편집)\s*$',
    [string]$RemoveName   = '(?i)^\s*(remove|delete|ลบ|ลบออก|削除|삭제)\s*$',
    [string]$RemoveOkName = '(?i)^\s*(ok|yes|confirm|remove|delete|ตกลง|ยืนยัน|ใช่|ลบ|ลบออก|はい|削除|확인|예|삭제)\s*$',             # search each ID and read the LINE name only (never taps "add") -> which IDs still work
    [switch]$ScanGroups,            # after all IDs: go home -> กลุ่ม -> list every group (name + members) for the user to choose
    [string]$JoinGroupB64 = '',     # with -GroupOnly: base64(UTF-8) name of the group to open (exactly as listed by -ScanGroups)
    [string]$InviteNamesB64 = '',   # base64(UTF-8 JSON array) of display names to search + tick on the invite screen
    [string]$LdConsole    = '',     # ldconsole.exe (types Thai / emoji names into LINE)
    [int]$LdIndex         = -1,
    [string]$ProgressFile = '',
    [string]$NameFile = '',
    [string]$ExcludeB64   = '',     # base64(UTF-8 JSON array): names never to tick (a name containing one of these is skipped)
    [string]$FindOaB64    = '',
    [string]$FriendsName  = '(?i)^\s*(friends?|เพื่อน|友だち|친구)\s*\(?\s*[\d,]*\s*\)?\s*[>›]?\s*$',
    [string]$OaTabName    = '(?i)^\s*(official\s*accounts?|บัญชีทางการ|บัญชี\s*official|公式アカウント|공식\s*계정)\s*\(?\s*[\d,]*\s*\)?\s*$',
    [string]$SearchByName = '(?i)^\s*(search\s*(by\s*)?name|ค้นหาด้วยชื่อ|ค้นหาชื่อ|ค้นหา|search|名前で検索|検索|이름으로\s*검색|검색)\s*$',     # base64(UTF-8 JSON array): OA names -> home -> search box -> type each name -> report found / not found
    [string]$ResultSection = '(?i)^\s*(friends?|เพื่อน|official\s*accounts?|บัญชีทางการ|บัญชี\s*official|groups?|กลุ่ม|chats?|แชท|messages?|ข้อความ|stickers?|สติกเกอร์|themes?|ธีม|emojis?|อีโมจิ|news|ข่าว|services?|บริการ|line\s*voom|voom|web|เว็บ|shopping|ช้อปปิ้ง|友だち|公式アカウント|グループ|トーク|メッセージ|친구|공식\s*계정|그룹|채팅|메시지)\s*\(?\s*[\d,]*\s*\)?\s*[>›]?\s*$',
    [string]$SkipSection   = '(?i)(messages?|ข้อความ|stickers?|สติกเกอร์|themes?|ธีม|emojis?|อีโมจิ|news|ข่าว|voom|web|เว็บ|shopping|ช้อปปิ้ง|メッセージ|메시지)',     # live progress for the GUI status column: one line 'state<TAB>term<TAB>name|name'     # LDPlayer index of this device (for ldconsole)
    [string]$AdbKeyboardApk = (Join-Path $PSScriptRoot 'ADBKeyboard.apk'),   # keyboard app that can type Thai / emoji through ADB   # auto = invite into an existing group, or create one if there is none
    [string]$InviteName   = '(?i)^\s*(\+\s*)?(invite|invite\s*friends?|invite\s*members?|เชิญ|เชิญเพื่อน|เชิญสมาชิก|招待|友だちを招待|초대|친구\s*초대)\s*$',
    [string]$InviteId     = '(?i)(invite)',
    [string]$MenuName     = '(?i)^\s*(menu|เมนู|メニュー|메뉴|more\s*options|ตัวเลือกเพิ่มเติม|その他のオプション)\s*$',
    [string]$MenuId       = '(?i)(header_button_more|chathistory_header_menu|header.*menu|menu_button)',
    [string]$ChatName     = '(?i)^\s*(chat|แชท|トーク|채팅)\s*$',
    [int]$MaxMembers      = 50,     # only invite into a group with this many members or fewer
    [string]$NextSection  = '(?i)^\s*(friends?|เพื่อน|友だち|친구|official\s*accounts?|บัญชีทางการ|services?|บริการ|favorites?|รายการโปรด)\s*\(?\s*\d*\s*\)?\s*$',
    [string]$GroupName    = '(?i)^\s*(\+\s*)?(create\s*(a\s*)?(new\s*)?group|new\s*group|make\s*a\s*group|สร้างกลุ่ม|สร้างกลุ่มใหม่|เพิ่มกลุ่ม|グループ作成|グループを作成|新しいグループ|그룹\s*만들기|그룹\s*생성)\s*$',
    [string]$GroupId      = '(?i)(create_?group|new_?group|make_?group)',
    [string]$GroupsHeader = '(?i)^\s*(groups?|กลุ่ม|グループ|그룹)\s*\(?\d*\)?\s*$',
    [string]$SelectTitle  = '(?i)^\s*(เลือก|เลือกเพื่อน|select|selected|select\s*friends|選択|友だちを選択|선택|친구\s*선택)\s*\(?\s*\d*\s*\)?\s*$',
    [string]$FriendStatusText = '(?i)(เป็นเพื่อน(กับคุณ)?(อยู่)?แล้ว|เพิ่มเป็นเพื่อนแล้ว|already\s*(your\s*)?friends?|you.?re\s*already|friends?\s*with\s*you|既に友だち|友だちです|이미\s*친구)',
    [string]$AddedText    = '(?i)^\s*(chat|แชท|トーク|채팅|added|เพิ่มแล้ว|追加済み)\s*$',

    [int]$StepDelayMs     = 600,    # pause after every tap so the screen can react
    [int]$WaitSec         = 10,     # max wait for an element to appear
    [int]$ResultWaitSec   = 8,      # max wait for a search result
    [int]$Retries         = 2,      # extra tries for a step that did not take effect
    [int]$Tolerance       = 40,
    [double]$MaxMissRatio = 0.05,
    [switch]$LaunchLine,
    [switch]$NoTap
)

$ErrorActionPreference = 'Stop'
function Out-Result($o, [int]$code) {
    if ($script:OwnName) { $o['ownName'] = $script:OwnName; $o['ownNameSource'] = $script:OwnNameSrc }
    $json = $o | ConvertTo-Json -Compress -Depth 6
    # escape non-ASCII so the result survives console-codepage redirection
    $json = [regex]::Replace($json, '[^\x00-\x7F]', [System.Text.RegularExpressions.MatchEvaluator]{ param($m) '\u{0:x4}' -f [int][char]$m.Value })
    $json
    exit $code
}

# ---------- Find adb ----------
if (-not $Adb) {
    $cands = @('C:\LDPlayer\LDPlayer9\adb.exe','C:\LDPlayer\LDPlayer4.0\adb.exe','D:\LDPlayer\LDPlayer9\adb.exe',"$env:ProgramFiles\LDPlayer\LDPlayer9\adb.exe")
    $p = Get-Process -Name 'dnplayer','Ld9BoxHeadless' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($p -and $p.Path) { $cands = @((Join-Path (Split-Path $p.Path) 'adb.exe')) + $cands }
    $Adb = $cands | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (-not $Adb) { $c = Get-Command adb -ErrorAction SilentlyContinue; if ($c) { $Adb = $c.Source } }
}
if (-not $Adb -or -not (Test-Path $Adb)) { Out-Result @{ ok = $false; error = 'adb.exe not found, specify -Adb' } 2 }

function Invoke-Adb([string[]]$a) {
    $all = @(); if ($Serial) { $all += @('-s', $Serial) }; $all += $a
    $old = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { return (& $Adb @all 2>&1 | Out-String) } finally { $ErrorActionPreference = $old }
}

$tmpDir = Join-Path $env:TEMP 'adb_line'
New-Item -ItemType Directory -Force -Path $tmpDir | Out-Null
$script:SafeSerial = 'dev'

# ---------- Image matching (last resort only) ----------
function Initialize-Img {
    if ('AdbImg' -as [type]) { return }
    Add-Type -AssemblyName System.Drawing
    Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition @'
using System; using System.Collections.Generic; using System.Drawing;
using System.Drawing.Drawing2D; using System.Drawing.Imaging; using System.Runtime.InteropServices;
public static class AdbImg {
    static int[] Px(Bitmap b) {
        var c = b.Clone(new Rectangle(0,0,b.Width,b.Height), PixelFormat.Format32bppArgb);
        var d = c.LockBits(new Rectangle(0,0,c.Width,c.Height), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        int[] a = new int[c.Width*c.Height]; Marshal.Copy(d.Scan0,a,0,a.Length); c.UnlockBits(d); c.Dispose(); return a;
    }
    public static Bitmap Resize(Bitmap s, double k) {
        int w=Math.Max(1,(int)Math.Round(s.Width*k)), h=Math.Max(1,(int)Math.Round(s.Height*k));
        var r=new Bitmap(w,h,PixelFormat.Format32bppArgb);
        using(var g=Graphics.FromImage(r)){g.InterpolationMode=InterpolationMode.HighQualityBicubic;g.PixelOffsetMode=PixelOffsetMode.HighQuality;g.DrawImage(s,0,0,w,h);}
        return r;
    }
    public static int[] Pixels(Bitmap b) { return Px(b); }
    static int Lum(int c) { return (((c >> 16) & 0xFF) * 299 + ((c >> 8) & 0xFF) * 587 + (c & 0xFF) * 114) / 1000; }
    // returns {cx, cy} of the right-most "three lines" icon inside [x1..x2, y1..y2], or null
    // try: dark lines (any background, incl. a highlighted button), light lines (dark mode), then contrast to the main background
    public static int[] FindHamburger(int[] px, int w, int h, int x1, int y1, int x2, int y2) {
        x1 = Math.Max(0, x1); y1 = Math.Max(0, y1); x2 = Math.Min(w - 1, x2); y2 = Math.Min(h - 1, y2);
        if (x2 <= x1 || y2 <= y1) return null;
        int[] hist = new int[16];
        for (int y = y1; y <= y2; y++) for (int x = x1; x <= x2; x++) hist[Lum(px[y * w + x]) >> 4]++;
        int bb = 0; for (int i = 1; i < 16; i++) if (hist[i] > hist[bb]) bb = i;
        int bg = bb * 16 + 8;
        int[] best = null;
        for (int mode = 0; mode < 3; mode++) {
            int[] r = FindBars(px, w, h, x1, y1, x2, y2, mode, bg);
            if (r != null && (best == null || r[2] > best[2])) best = r;
        }
        return best == null ? null : new int[] { best[0], best[1] };
    }
    static bool Ink(int c, int mode, int bg) {
        int l = Lum(c);
        if (mode == 0) return l < 120 && bg > 140;
        if (mode == 1) return l > 215 && bg < 110;
        return Math.Abs(l - bg) > 70;
    }
    static int[] FindBars(int[] px, int w, int h, int x1, int y1, int x2, int y2, int mode, int bg) {
        int minL = Math.Max(6, w * 2 / 100), maxL = Math.Max(minL + 2, w * 10 / 100);
        int maxThick = Math.Max(6, h * 12 / 1000);
        var open = new List<int[]>(); var done = new List<int[]>();
        for (int y = y1; y <= y2; y++) {
            var next = new List<int[]>();
            int x = x1;
            while (x <= x2) {
                if (Ink(px[y * w + x], mode, bg)) {
                    int s = x;
                    while (x <= x2 && Ink(px[y * w + x], mode, bg)) x++;
                    int e = x - 1, len = e - s + 1;
                    if (len >= minL && len <= maxL && s > x1 && e < x2) {
                        int[] hit = null;
                        foreach (var b in open) if (Math.Abs(b[2] - s) <= 2 && Math.Abs(b[3] - e) <= 2) { hit = b; break; }
                        if (hit != null) { open.Remove(hit); hit[1] = y; next.Add(hit); }
                        else next.Add(new int[] { y, y, s, e });
                    }
                } else x++;
            }
            done.AddRange(open);
            open = next;
        }
        done.AddRange(open);
        var bars = new List<int[]>();
        foreach (var b in done) if (b[1] - b[0] + 1 <= maxThick) bars.Add(b);
        bars.Sort((a, b) => a[0].CompareTo(b[0]));
        int[] best = null; int bestRight = -1;
        for (int i = 0; i < bars.Count; i++)
            for (int j = i + 1; j < bars.Count; j++) {
                var A = bars[i]; var B = bars[j];
                if (Math.Abs(A[2] - B[2]) > 3 || Math.Abs(A[3] - B[3]) > 3) continue;
                int g1 = B[0] - A[1]; if (g1 < 2) continue;
                for (int k = j + 1; k < bars.Count; k++) {
                    var C = bars[k];
                    if (Math.Abs(A[2] - C[2]) > 3 || Math.Abs(A[3] - C[3]) > 3) continue;
                    int g2 = C[0] - B[1];
                    if (g2 < 2 || Math.Abs(g1 - g2) > 3) continue;
                    int tot = C[1] - A[0] + 1;
                    if (tot < Math.Max(6, h * 12 / 1000) || tot > h * 7 / 100) continue;
                    if (A[3] > bestRight) { bestRight = A[3]; best = new int[] { (A[2] + A[3]) / 2, (A[0] + C[1]) / 2, A[3] }; }
                }
            }
        return best;
    }
    public static int[] Find(Bitmap hay, Bitmap tpl, int tol, double ratio) {
        int hw=hay.Width,hh=hay.Height,tw=tpl.Width,th=tpl.Height; if(tw>hw||th>hh) return null;
        int[] H=Px(hay),T=Px(tpl); var O=new List<int>(); var C=new List<int>();
        for(int y=0;y<th;y++)for(int x=0;x<tw;x++){int c=T[y*tw+x]; if(((c>>24)&0xFF)>=128){O.Add(y*hw+x);C.Add(c);}}
        int n=O.Count; if(n==0) return null; int[] o=O.ToArray(), cc=C.ToArray();
        int best=(int)(n*ratio)+1,bx=-1,by=-1;
        for(int y=0;y<=hh-th;y++)for(int x=0;x<=hw-tw;x++){
            int b=y*hw+x,m=0;
            for(int i=0;i<n;i++){int p=H[b+o[i]],q=cc[i];
                if(Math.Abs(((p>>16)&0xFF)-((q>>16)&0xFF))>tol||Math.Abs(((p>>8)&0xFF)-((q>>8)&0xFF))>tol||Math.Abs((p&0xFF)-(q&0xFF))>tol){if(++m>=best)break;}}
            if(m<best){best=m;bx=x;by=y;if(m==0)return new[]{bx,by,0,n};}
        }
        return bx<0?null:new[]{bx,by,best,n};
    }
}
'@
}
function Find-ByImage([string]$Template) {
    if (-not $Template -or -not (Test-Path $Template)) { return $null }
    Initialize-Img
    $shot = Join-Path $tmpDir ("screen_{0}.png" -f $script:SafeSerial)
    Remove-Item -LiteralPath $shot -Force -ErrorAction SilentlyContinue
    [void](Invoke-Adb @('shell', 'screencap -p /sdcard/__screen.png'))
    [void](Invoke-Adb @('pull', '/sdcard/__screen.png', $shot))
    if (-not (Test-Path $shot)) { return $null }
    $hay = New-Object System.Drawing.Bitmap $shot
    $orig = New-Object System.Drawing.Bitmap (Resolve-Path $Template).Path
    $hit = $null
    try {
        foreach ($k in 1.0, 1.5, 2.0, 0.75, 1.25, 3.0, 0.5) {
            $t = if ($k -eq 1.0) { New-Object System.Drawing.Bitmap $orig } else { [AdbImg]::Resize($orig, $k) }
            $m = [AdbImg]::Find($hay, $t, $Tolerance, $MaxMissRatio)
            if ($m) { $hit = @{ X = $m[0] + [int]($t.Width / 2); Y = $m[1] + [int]($t.Height / 2); Score = [math]::Round(1 - $m[2] / [double]$m[3], 4); Scale = $k } }
            $t.Dispose(); if ($hit) { break }
        }
    } finally { $hay.Dispose(); $orig.Dispose() }
    return $hit
}

function Find-MenuIconByImage {
    try { return (Find-MenuIconByImageCore) } catch { return $null }
}
function Find-MenuIconByImageCore {
    Initialize-Img
    $shot = Join-Path $tmpDir ("chat_{0}.png" -f $script:SafeSerial)
    Remove-Item -LiteralPath $shot -Force -ErrorAction SilentlyContinue
    [void](Invoke-Adb @('shell', 'screencap -p /sdcard/__screen.png'))
    [void](Invoke-Adb @('pull', '/sdcard/__screen.png', $shot))
    if (-not (Test-Path $shot)) { return $null }
    $script:LastChatShot = $shot
    $bmp = New-Object System.Drawing.Bitmap $shot
    try {
        $w = $bmp.Width; $h = $bmp.Height
        $px = [AdbImg]::Pixels($bmp)
        $hit = [AdbImg]::FindHamburger($px, $w, $h, [int]($w * 0.55), 0, $w - 1, [int]($h * 0.16))
        if (-not $hit) { return $null }
        # screenshot pixels -> tap coordinates (same unless the screen is scaled)
        $sw = if ($script:ScreenW -gt 0) { $script:ScreenW / [double]$w } else { 1.0 }
        $sh = if ($script:ScreenH -gt 0) { $script:ScreenH / [double]$h } else { 1.0 }
        return @([int]($hit[0] * $sw), [int]($hit[1] * $sh))
    } finally { $bmp.Dispose() }
}
$script:LastChatShot = ''

# ---------- Read screen structure as a UTF-8 file ----------
$script:ScreenW = 0; $script:ScreenH = 0
function Get-Ui {
    for ($i = 1; $i -le 3; $i++) {
        $local = Join-Path $tmpDir ("ui_{0}.xml" -f $script:SafeSerial)
        Remove-Item -LiteralPath $local -Force -ErrorAction SilentlyContinue
        [void](Invoke-Adb @('shell', 'uiautomator dump /sdcard/__ui.xml >/dev/null 2>&1'))
        [void](Invoke-Adb @('pull', '/sdcard/__ui.xml', $local))
        if (Test-Path -LiteralPath $local) {
            try {
                [xml]$x = [System.IO.File]::ReadAllText($local, [System.Text.Encoding]::UTF8)
                $nodes = New-Object System.Collections.ArrayList
                foreach ($n in $x.SelectNodes('//node')) {
                    $b = [string]$n.bounds
                    if ($b -match '\[(-?\d+),(-?\d+)\]\[(-?\d+),(-?\d+)\]') {
                        $o = [pscustomobject]@{
                            Text = ([string]$n.text).Trim(); Desc = ([string]$n.'content-desc').Trim()
                            Id = [string]$n.'resource-id'; Class = [string]$n.class
                            Click = ([string]$n.clickable -eq 'true'); Enabled = ([string]$n.enabled -ne 'false')
                            Checkable = ([string]$n.checkable -eq 'true'); Checked = ([string]$n.checked -eq 'true') -or ([string]$n.selected -eq 'true'); Focused = ([string]$n.focused -eq 'true'); Hint = ([string]$n.hint).Trim()
                            X1 = [int]$Matches[1]; Y1 = [int]$Matches[2]; X2 = [int]$Matches[3]; Y2 = [int]$Matches[4]
                        }
                        if ($o.X2 -gt $script:ScreenW) { $script:ScreenW = $o.X2 }
                        if ($o.Y2 -gt $script:ScreenH) { $script:ScreenH = $o.Y2 }
                        [void]$nodes.Add($o)
                    }
                }
                if ($nodes.Count -gt 0) { $script:UiFailCount = 0; return , $nodes.ToArray() }
            } catch { }
        }
        Start-Sleep -Milliseconds 300
    }
    $script:UiFailCount = 1 + [int]$script:UiFailCount
    $script:UiFailTotal = 1 + [int]$script:UiFailTotal
    return , @()
}
function Test-Visible($n) {
    $w = $n.X2 - $n.X1; $h = $n.Y2 - $n.Y1
    if ($w -lt 8 -or $h -lt 8) { return $false }
    if ($n.X1 -lt 0 -or $n.Y1 -lt 0) { return $false }
    if ($script:ScreenW -gt 0 -and $n.X2 -gt $script:ScreenW) { return $false }
    if ($script:ScreenH -gt 0 -and $n.Y2 -gt $script:ScreenH) { return $false }
    return $true
}
# best match: exact name (text / content-desc) first, then resource-id; prefer clickable + enabled
function Find-Node($nodes, [string]$NamePattern, [string]$IdPattern) {
    $hits = @($nodes | Where-Object { (Test-Visible $_) -and (($_.Text -match $NamePattern) -or ($_.Desc -match $NamePattern)) })
    if (-not $hits.Count -and $IdPattern) { $hits = @($nodes | Where-Object { (Test-Visible $_) -and $_.Id -match $IdPattern }) }
    if (-not $hits.Count) { return $null }
    $best = @($hits | Where-Object { $_.Click -and $_.Enabled } | Select-Object -First 1)
    if ($best.Count) { return $best[0] }
    # label not clickable itself -> use the smallest clickable parent that contains it
    $h = $hits[0]
    $parent = @($nodes | Where-Object { $_.Click -and $_.Enabled -and (Test-Visible $_) -and $_.X1 -le $h.X1 -and $_.Y1 -le $h.Y1 -and $_.X2 -ge $h.X2 -and $_.Y2 -ge $h.Y2 } |
        Sort-Object { ($_.X2 - $_.X1) * ($_.Y2 - $_.Y1) } | Select-Object -First 1)
    if ($parent.Count) { return $parent[0] }
    return $h
}
function Get-Center($n) { return @([int](($n.X1 + $n.X2) / 2), [int](($n.Y1 + $n.Y2) / 2)) }
function Test-SameSpot($a, $b) {
    return ([Math]::Abs($a.X1 - $b.X1) -le 4 -and [Math]::Abs($a.Y1 - $b.Y1) -le 4 -and [Math]::Abs($a.X2 - $b.X2) -le 4 -and [Math]::Abs($a.Y2 - $b.Y2) -le 4)
}
# wait until the element is on screen AND in the same place on two reads in a row (screen finished moving)
function Wait-StableNode([string]$NamePattern, [string]$IdPattern, [int]$TimeoutSec) {
    $deadline = (Get-Date).AddSeconds($TimeoutSec)
    $prev = $null
    do {
        $node = Find-Node (Get-Ui) $NamePattern $IdPattern
        if ($node) {
            if ($prev -and (Test-SameSpot $prev $node)) { return $node }
            $prev = $node
            Start-Sleep -Milliseconds 250
        } else {
            $prev = $null
            Start-Sleep -Milliseconds 400
        }
    } while ((Get-Date) -lt $deadline)
    return $null
}
function Invoke-Tap([int]$x, [int]$y) {
    if (-not $NoTap) { [void](Invoke-Adb @('shell', "input tap $x $y")) }
    Start-Sleep -Milliseconds $StepDelayMs
}

# ---------- One tap step, verified by the element that should appear next ----------
function Invoke-TapStep([string]$StepName, [string]$NamePattern, [string]$IdPattern, [string]$Template,
                        [string]$NextName = '', [string]$NextId = '', [int]$TimeoutSec = $WaitSec) {
    for ($try = 0; $try -le $Retries; $try++) {
        $method = 'uiautomator'
        $node = Wait-StableNode $NamePattern $IdPattern $TimeoutSec
        if ($node) {
            $c = Get-Center $node
            $info = [ordered]@{ step = $StepName; found = $true; method = $method; x = $c[0]; y = $c[1]; tapped = (-not $NoTap)
                                desc = $node.Desc; text = $node.Text; id = $node.Id; attempt = $try + 1 }
        } else {
            $hit = Find-ByImage $Template
            if (-not $hit) { continue }
            $c = @($hit.X, $hit.Y); $method = 'image'
            $info = [ordered]@{ step = $StepName; found = $true; method = $method; x = $c[0]; y = $c[1]; score = $hit.Score; scale = $hit.Scale
                                tapped = (-not $NoTap); attempt = $try + 1 }
        }
        Invoke-Tap $c[0] $c[1]
        if (-not $NextName -and -not $NextId) { return $info }
        # verify: the next screen's element must appear
        if (Wait-StableNode $NextName $NextId 6) { $info.verified = $true; return $info }
        $info.verified = $false
        if ($try -ge $Retries -or $method -ne 'uiautomator') { return $info }
        $cur = Find-Node (Get-Ui) $NamePattern $IdPattern
        if (-not $cur -or -not (Test-SameSpot $cur $node)) { return $info }   # screen did change; do not tap something else
    }
    return [ordered]@{ step = $StepName; found = $false }
}

# ---------- Type text into the input field and verify it ----------
function ConvertTo-AdbText([string]$t) {
    $sb = New-Object System.Text.StringBuilder
    foreach ($ch in $t.ToCharArray()) {
        if ($ch -eq ' ') { [void]$sb.Append('%s') }
        elseif ('\"''`$&|;<>()*?!#~^[]{}%'.Contains($ch)) { [void]$sb.Append('\').Append($ch) }
        else { [void]$sb.Append($ch) }
    }
    $sb.ToString()
}
function Get-EditNode {
    $deadline = (Get-Date).AddSeconds(6)
    do {
        $ui = Get-Ui
        $e = @($ui | Where-Object { $_.Class -match 'EditText' -and (Test-Visible $_) } | Select-Object -First 1)
        if ($e.Count) { return $e[0] }
        Start-Sleep -Milliseconds 400
    } while ((Get-Date) -lt $deadline)
    return $null
}
function Invoke-TypeStep([string]$Value) {
    if ($Value -match '[^\x20-\x7E]') {
        return [ordered]@{ step = 'type'; found = $false; text = $Value; error = 'adb input text only supports English letters/digits/symbols' }
    }
    $typed = ''
    for ($try = 0; $try -le $Retries; $try++) {
        $edit = Get-EditNode
        if (-not $edit) { return [ordered]@{ step = 'type'; found = $false; text = $Value; error = 'Input field not found' } }
        $c = Get-Center $edit
        if ($NoTap) { return [ordered]@{ step = 'type'; found = $true; x = $c[0]; y = $c[1]; text = $Value; tapped = $false } }
        # focus the field, clear it, then type (separate commands, each given time to apply)
        Invoke-Tap $c[0] $c[1]
        $dels = (1..(([Math]::Max(40, $Value.Length + 20))) | ForEach-Object { '67' }) -join ' '
        [void](Invoke-Adb @('shell', "input keyevent 123; input keyevent $dels"))
        Start-Sleep -Milliseconds 250
        [void](Invoke-Adb @('shell', "input text $(ConvertTo-AdbText $Value)"))
        Start-Sleep -Milliseconds 400
        # verify what is in the field now
        $now = Get-EditNode
        $typed = if ($now) { $now.Text } else { '' }
        if ($typed -eq $Value) {
            return [ordered]@{ step = 'type'; found = $true; x = $c[0]; y = $c[1]; text = $Value; verified = $true; attempt = $try + 1; tapped = $true }
        }
    }
    return [ordered]@{ step = 'type'; found = $false; text = $Value; error = "Typed text did not match (field shows '$typed')" }
}

# ---------- After pressing Enter: wait for a clear result ----------
function Find-AddButton($nodes) {
    $minY = [int]([Math]::Max(1, $script:ScreenH) * 0.15)
    $area = @($nodes | Where-Object { $_.Y1 -ge $minY -and $_.Class -notmatch 'EditText' })
    return (Find-Node $area $AddBtnName '(?!)')
}
function Get-ResultSig($nodes) {
    return ((@($nodes | Where-Object { $_.Class -notmatch 'EditText' -and ($_.Text -or $_.Desc) } | ForEach-Object { "$($_.Text)|$($_.Desc)@$($_.Y1)" })) -join ';')
}
# returns 'add' (node), 'notfound', 'already', or 'timeout'
function Wait-SearchResult([string]$BeforeSig = '') {
    $start = Get-Date
    $deadline = $start.AddSeconds($ResultWaitSec)
    $prev = $null
    do {
        $nodes = Get-Ui
        # ignore what was on screen before Enter (previous round's result) for up to 3 seconds
        if ($BeforeSig -and ((Get-Date) - $start).TotalSeconds -lt 3 -and (Get-ResultSig $nodes) -eq $BeforeSig) {
            Start-Sleep -Milliseconds 300
            continue
        }
        $add = Find-AddButton $nodes
        if ($add) {
            if ($prev -and (Test-SameSpot $prev $add)) { return @{ Kind = 'add'; Node = $add } }
            $prev = $add
            Start-Sleep -Milliseconds 250
            continue
        }
        $prev = $null
        if (@($nodes | Where-Object { $_.Class -notmatch 'EditText' -and ($_.Text -match $NotFoundText -or $_.Desc -match $NotFoundText) }).Count) { return @{ Kind = 'notfound' } }
        if (@($nodes | Where-Object { $_.Class -notmatch 'EditText' -and (Test-Visible $_) -and ($_.Text -match $AddedText -or $_.Desc -match $AddedText -or $_.Text -match $FriendStatusText -or $_.Desc -match $FriendStatusText) }).Count) { return @{ Kind = 'already' } }
        Start-Sleep -Milliseconds 400
    } while ((Get-Date) -lt $deadline)
    return @{ Kind = 'timeout' }
}
# after tapping "add": the add button must disappear (or turn into chat / added)
function Test-Added($addNode) {
    $deadline = (Get-Date).AddSeconds(6)
    $confirmed = $false
    do {
        $nodes = Get-Ui
        $still = Find-AddButton $nodes
        if ($still -and (Test-SameSpot $still $addNode)) { Start-Sleep -Milliseconds 400; continue }
        # a confirmation popup may appear (OK / ยืนยัน / เพิ่ม in a dialog): tap it once
        if (-not $confirmed) {
            $dlg = @($nodes | Where-Object { $_.Id -match '(?i)(button1|positive|confirm|dialog)' -or $_.Class -match 'Button' })
            $btn = Find-Node $dlg $ConfirmName '(?!)'
            if ($btn -and -not (Test-SameSpot $btn $addNode)) {
                $c = Get-Center $btn
                Invoke-Tap $c[0] $c[1]
                $confirmed = $true
                continue
            }
        }
        return $true
    } while ((Get-Date) -lt $deadline)
    return $false
}

# ---------- Go back to the LINE home screen (bottom tab "หน้าหลัก") ----------
function Invoke-GoHome {
    if ($NoTap) { return $true }
    for ($k = 0; $k -lt 8; $k++) {
        $nodes = Get-Ui
        if (-not $nodes.Count) {
            # the screen cannot be read (busy home screen): do not press back blindly; make sure LINE is in front and stop
            $focus = Invoke-Adb @('shell', 'dumpsys window | grep -E "mCurrentFocus"')
            if ($focus -notmatch [regex]::Escape($Package)) { [void](Invoke-Adb @('shell', "monkey -p $Package -c android.intent.category.LAUNCHER 1")); Start-Sleep -Seconds 3 }
            if ($k -ge 1) { return $false }
            continue
        }
        $minY = [int]([Math]::Max(1, $script:ScreenH) * 0.75)
        $bottom = @($nodes | Where-Object { $_.Y1 -ge $minY })
        $homeTab = Find-Node $bottom $HomeName $HomeId
        if ($homeTab) {
            $c = Get-Center $homeTab
            Invoke-Tap $c[0] $c[1]
            # verify: the add-friend entry of the home screen is visible
            if (Wait-HomeScreen 5) { return $true }
            continue
        }
        # left LINE completely? open it again (it starts on home)
        $focus = Invoke-Adb @('shell', 'dumpsys window | grep -E "mCurrentFocus"')
        if ($focus -notmatch [regex]::Escape($Package)) {
            [void](Invoke-Adb @('shell', "monkey -p $Package -c android.intent.category.LAUNCHER 1"))
            Start-Sleep -Seconds 3
            continue
        }
        [void](Invoke-Adb @('shell', 'input keyevent 4'))
        Start-Sleep -Milliseconds 800
    }
    # stuck somewhere (popup / OA page without the bottom tabs): restart LINE, it opens on the home screen
    [void](Invoke-Adb @('shell', "am force-stop $Package"))
    Start-Sleep -Milliseconds 800
    [void](Invoke-Adb @('shell', "monkey -p $Package -c android.intent.category.LAUNCHER 1"))
    if (Wait-HomeScreen 15) { return $true }
    return $false
}
# home = the add-friend entry, or the "ค้นหา" bar near the top together with the bottom tabs
function Wait-HomeScreen([int]$sec) {
    $deadline = (Get-Date).AddSeconds($sec)
    do {
        $nodes = Get-Ui
        if (Find-Node $nodes $AddName $AddId) { Read-OwnName $nodes; return $true }
        $H = [Math]::Max(500, $script:ScreenH)
        $bar = @($nodes | Where-Object { (Test-Visible $_) -and $_.Y2 -le ($H * 0.5) -and ($_.Text -match $SearchName -or $_.Desc -match $SearchName) })
        $tab = Find-Node @($nodes | Where-Object { $_.Y1 -ge ($H * 0.75) }) $HomeName $HomeId
        if ($bar.Count -and $tab) { Read-OwnName $nodes; return $true }
        Start-Sleep -Milliseconds 400
    } while ((Get-Date) -lt $deadline)
    return $false
}

# ---------- Own LINE display name (read from the home screen, no extra navigation) ----------
$script:OwnName = ''; $script:OwnNameSrc = ''
$OwnNameId = '(?i)(profile[_\.]?name|name[_\.]?profile|my[_\.]?name|home.*(user|profile|my).*name|display[_\.]?name|header.*name)'
$OwnSkip   = '(?i)^\s*(home|หน้าหลัก|chats?|แชท|voom|news|ข่าว|today|wallet|วอลเล็ท|shopping|ช็อปปิ้ง|mini|search|ค้นหา|friends?|เพื่อน|groups?|กลุ่ม|' +
             'services?|บริการ|see all|ดูทั้งหมด|more|เพิ่มเติม|add friends?|เพิ่มเพื่อน|settings?|ตั้งค่า|keep|notes?|โน้ต|edit|แก้ไข|official accounts?|บัญชีทางการ|' +
             'stickers?|สติกเกอร์|themes?|ธีม|สร้างกลุ่ม|create a? ?group|calls?|โทร|line|ホーム|トーク|友だち|グループ|検索|홈|친구|그룹|검색|' +
             'ใส่ข้อความสถานะ|ข้อความสถานะ|(enter a |set a )?status message|ステータスメッセージ.*|상태메시지.*|birthday.*|วันเกิด.*)\s*$'
$OwnSection = '(?i)^\s*(friends?|เพื่อน|groups?|กลุ่ม|services?|บริการ|favorites?|รายการโปรด|友だち|グループ|サービス|친구|그룹|서비스)\s*\(?\s*[\d,]*\s*\)?\s*[>›]?\s*$'
function Read-OwnName($nodes) {
    if ($script:OwnName -or -not $nodes -or -not $nodes.Count) { return }
    try {
        $H = [Math]::Max(500, $script:ScreenH)
        # must really be the HOME tab: the bottom Home tab + (the add-friend entry or a friends/groups section)
        $tab = Find-Node @($nodes | Where-Object { $_.Y1 -ge ($H * 0.75) }) $HomeName $HomeId
        if (-not $tab) { return }
        $sect = @($nodes | Where-Object { (Test-Visible $_) -and $_.Y1 -lt ($H * 0.75) -and ($_.Text -match $OwnSection) } | Sort-Object Y1)
        $add = Find-Node @($nodes | Where-Object { $_.Y2 -le ($H * 0.3) }) $AddName $AddId
        if (-not $sect.Count -and -not $add) { return }
        $ok = { param($t) $t -and $t.Length -le 50 -and $t -notmatch $OwnSkip -and $t -notmatch '^[\d,\.\s\(\)\+\-:/]+$' }
        # 1) the profile-name view (resource-id)
        $byId = @($nodes | Where-Object { (Test-Visible $_) -and $_.Id -match $OwnNameId -and (& $ok $_.Text) -and $_.Y2 -le ($H * 0.5) } | Sort-Object Y1 | Select-Object -First 1)
        if ($byId.Count) { $script:OwnName = $byId[0].Text; $script:OwnNameSrc = 'id' }
        else {
            # 2) the topmost plain text above the first section (friends / groups), below the status bar; not an input field
            $limit = if ($sect.Count) { $sect[0].Y1 } else { [int]($H * 0.4) }
            $cand = @($nodes | Where-Object { (Test-Visible $_) -and $_.Class -notmatch 'EditText' -and (& $ok $_.Text) -and $_.Y1 -ge 40 -and $_.Y2 -le $limit -and $_.X1 -lt ($script:ScreenW * 0.7) } | Sort-Object Y1, X1 | Select-Object -First 1)
            if (-not $cand.Count) { return }
            $script:OwnName = $cand[0].Text; $script:OwnNameSrc = 'top'
        }
        if ($NameFile) { [System.IO.File]::WriteAllText($NameFile, "$($script:OwnName)`t$($script:OwnNameSrc)", (New-Object System.Text.UTF8Encoding($false))) }
    } catch { }
}

# ---------- Home screen -> "create group" -> friend selection screen ----------
function Invoke-CreateGroup {
    $r = [ordered]@{ step = 'creategroup'; home = $false; found = $false; opened = $false }
    if ($NoTap) { return $r }
    $r.home = [bool](Invoke-GoHome)
    $expanded = $false
    for ($k = 0; $k -lt 6; $k++) {
        $node = Wait-StableNode $GroupName $GroupId 3
        if ($node) {
            $r.found = $true
            $c = Get-Center $node
            Invoke-Tap $c[0] $c[1]
            $r.x = $c[0]; $r.y = $c[1]; $r.text = if ($node.Text) { $node.Text } else { $node.Desc }
            # verify: the friend selection screen ("เลือก") is open
            if (Wait-StableNode $SelectTitle '(?!)' 8) { $r.opened = $true; return $r }
            continue
        }
        # groups section may be collapsed on the home screen: open it once
        if (-not $expanded) {
            $nodes = Get-Ui
            $hdr = Find-Node $nodes $GroupsHeader '(?!)'
            if ($hdr) { $c = Get-Center $hdr; Invoke-Tap $c[0] $c[1]; $expanded = $true; continue }
        }
        # scroll the home screen down a little and look again
        $W = [Math]::Max(300, $script:ScreenW); $H = [Math]::Max(500, $script:ScreenH)
        [void](Invoke-Adb @('shell', "input swipe $([int]($W/2)) $([int]($H*0.75)) $([int]($W/2)) $([int]($H*0.40)) 500"))
        Start-Sleep -Milliseconds 700
    }
    return $r
}

# ---------- Existing group -> invite friends ----------
# groups listed on the home screen under the "กลุ่ม N" header
# member count of a group row: "ชื่อกลุ่ม (23)", "23 คน", "23 members" or a separate "23"
function Get-MemberCount($nodes, $row) {
    $texts = @($nodes | Where-Object { ($_.Text -or $_.Desc) -and $_.X1 -ge $row.X1 -and $_.X2 -le $row.X2 -and $_.Y1 -ge $row.Y1 -and $_.Y2 -le $row.Y2 } | ForEach-Object { if ($_.Text) { $_.Text } else { $_.Desc } })
    foreach ($tx in $texts) {
        $m = [regex]::Match($tx, '\(\s*(\d[\d,]*)\s*\)')
        if ($m.Success) { return [int]($m.Groups[1].Value -replace ',', '') }
        $m = [regex]::Match($tx, '(?i)(\d[\d,]*)\s*(คน|สมาชิก|members?|名|명)')
        if ($m.Success) { return [int]($m.Groups[1].Value -replace ',', '') }
    }
    foreach ($tx in $texts) {
        if ($tx -match '^\s*(\d[\d,]*)\s*$') { return [int]($Matches[1] -replace ',', '') }
    }
    return $null
}
# rows of a list screen (groups list): clickable, wide, row-sized, with a name; innermost only
function Get-ListRows($nodes, [int]$minY) {
    $W = [Math]::Max(300, $script:ScreenW); $H = [Math]::Max(500, $script:ScreenH)
    $cand = @($nodes | Where-Object {
            $_.Click -and (Test-Visible $_) -and $_.Y1 -ge $minY -and $_.Class -notmatch 'EditText' -and
            ($_.X2 - $_.X1) -ge ($W * 0.6) -and ($_.Y2 - $_.Y1) -ge ($H * 0.035) -and ($_.Y2 - $_.Y1) -le ($H * 0.16)
        })
    $rows = @()
    foreach ($c in $cand) {
        $inner = @($cand | Where-Object { $_ -ne $c -and $_.X1 -ge $c.X1 -and $_.X2 -le $c.X2 -and $_.Y1 -ge $c.Y1 -and $_.Y2 -le $c.Y2 -and (($_.Y2 - $_.Y1) -lt ($c.Y2 - $c.Y1)) })
        if ($inner.Count) { continue }
        $texts = @($nodes | Where-Object { $_.Text -and $_.X1 -ge $c.X1 -and $_.X2 -le $c.X2 -and $_.Y1 -ge $c.Y1 -and $_.Y2 -le $c.Y2 } | Sort-Object Y1, X1)
        $name = if ($texts.Count) { $texts[0].Text } else { $c.Desc }
        if (-not $name) { continue }
        if ($name -match $GroupName -or $name -match $GroupsHeader -or $name -match $NextSection -or $name -match $SearchName) { continue }
        $rows += [pscustomobject]@{ Name = $name; Node = $c; Count = (Get-MemberCount $nodes $c) }
    }
    return , @($rows | Sort-Object { $_.Node.Y1 })
}
function Test-InviteScreen {
    $nodes = Get-Ui
    if (Find-Node $nodes $SelectTitle '(?!)') { return $true }
    # invite screen titled "เชิญ" with a search box
    $hasEdit = @($nodes | Where-Object { (Test-Visible $_) -and ($_.Class -match 'EditText' -or (($_.Text -match $SearchName -or $_.Desc -match $SearchName) -and $_.Y2 -le ([Math]::Max(500, $script:ScreenH) * 0.4))) }).Count -gt 0
    $title = @($nodes | Where-Object { $_.Y2 -le ([Math]::Max(500, $script:ScreenH) * 0.15) -and ($_.Text -match $InviteName) }).Count -gt 0
    return ($hasEdit -and $title)
}
# หน้าแรก -> กด "กลุ่ม" -> หากลุ่มที่สมาชิกไม่เกิน MaxMembers -> เข้ากลุ่ม -> แชท -> ≡ (ขวาบน) -> เชิญ
# after tapping a group: 'profile' (group page with the "แชท" button), 'chat' (chat room) or '' (nothing opened)
function Wait-EnteredGroup($row, [int]$sec = 6) {
    $H = [Math]::Max(500, $script:ScreenH)
    $key = ConvertTo-GroupKey ([string]$row.Name)
    $deadline = (Get-Date).AddSeconds($sec)
    do {
        Start-Sleep -Milliseconds 400
        $nodes = Get-Ui
        $script:LastUi = $nodes
        # still showing the same list row at the same place -> not opened yet
        $rows = Get-ListRows $nodes ([int]($H * 0.10))
        $same = @($rows | Where-Object { (ConvertTo-GroupKey $_.Name) -eq $key -and (Test-SameSpot $_.Node $row.Node) }).Count -gt 0
        if ($same) { continue }
        if (Find-Node $nodes $ChatName '(?!)') { return 'profile' }
        $bottomEdit = @($nodes | Where-Object { $_.Class -match 'EditText' -and (Test-Visible $_) -and $_.Y1 -ge ($H * 0.70) }).Count -gt 0
        $title = @($nodes | Where-Object { $_.Y2 -le ($H * 0.15) -and ($_.Text -or $_.Desc) -and (ConvertTo-GroupKey $(if ($_.Text) { $_.Text } else { $_.Desc })) -eq $key }).Count -gt 0
        if ($bottomEdit -or ($title -and -not $rows.Count)) { return 'chat' }
    } while ((Get-Date) -lt $deadline)
    return ''
}
$script:LastUi = @()
function ConvertTo-GroupKey([string]$n) { return (($n -replace '\(\s*\d[\d,]*\s*\)\s*$', '') -replace '\s+', ' ').Trim().ToLowerInvariant() }
function Find-GroupRow($rows, [string]$want) {
    $k = ConvertTo-GroupKey $want
    foreach ($r in @($rows)) { if ($r.Name -eq $want -or (ConvertTo-GroupKey $r.Name) -eq $k) { return $r } }
    $part = @(@($rows) | Where-Object { $rk = ConvertTo-GroupKey $_.Name; $rk.Length -ge 2 -and ($rk.Contains($k) -or $k.Contains($rk.TrimEnd('…', '.'))) })
    if ($part.Count -eq 1) { return $part[0] }
    return $null
}
function Invoke-InviteToGroup([string]$WantName = '', [string]$MenuTarget = 'invite', [switch]$FromHome) {
    $tName = if ($MenuTarget -eq 'members') { $MembersName } else { $InviteName }
    $tId = if ($MenuTarget -eq 'members') { '(?i)(member)' } else { $InviteId }
    $r = [ordered]@{ step = 'invitegroup'; mode = 'invite'; home = $false; groupsOpened = $false; noGroup = $null; allTooBig = $false
                     groupFound = $false; group = ''; members = $null; chat = $false; menu = $false; inviteFound = $false; opened = $false; checked = @() }
    if ($NoTap) { return $r }
    $direct = $null
    if ($WantName -and -not $FromHome) {
        $nodes0 = Get-Ui
        $H0 = [Math]::Max(500, $script:ScreenH)
        $rows0 = Get-ListRows $nodes0 ([int]($H0 * 0.10))
        $direct = Find-GroupRow $rows0 $WantName
    }
    $W = [Math]::Max(300, $script:ScreenW); $H = [Math]::Max(500, $script:ScreenH)
    if ($direct) {
        $r.direct = $true
        $r.groupsOpened = $true
        $chosen = $direct
    }
    if (-not $direct) {
    $r.home = [bool](Invoke-GoHome)
    $W = [Math]::Max(300, $script:ScreenW); $H = [Math]::Max(500, $script:ScreenH)

    # 1) tap the word "กลุ่ม" on the home screen
    $hdr = $null
    for ($k = 0; $k -lt 4 -and -not $hdr; $k++) {
        $hdr = Wait-StableNode $GroupsHeader '(?i)(group_?list|groups?_(tab|header|title)|home_group)' 3
        if (-not $hdr) {
            [void](Invoke-Adb @('shell', "input swipe $([int]($W/2)) $([int]($H*0.75)) $([int]($W/2)) $([int]($H*0.40)) 500"))
            Start-Sleep -Milliseconds 700
        }
    }
    if (-not $hdr) { $r.noGroup = $true; return $r }
    $label = if ($hdr.Text) { $hdr.Text } else { $hdr.Desc }
    $m = [regex]::Match($label, '(\d+)')
    if ($m.Success -and [int]$m.Groups[1].Value -eq 0) { $r.noGroup = $true; return $r }
    $c = Get-Center $hdr
    Invoke-Tap $c[0] $c[1]
    $r.groupsOpened = $true
    Start-Sleep -Milliseconds 900

    # 2) scan the groups for one with <= MaxMembers members (scroll down if needed)
    $chosen = $null
    $firstUnknown = $null
    $anyCount = $false
    $lastSig = ''
    for ($page = 0; $page -lt 15 -and -not $chosen; $page++) {
        $nodes = Get-Ui
        $rows = Get-ListRows $nodes ([int]($H * 0.10))
        foreach ($row in $rows) {
            $entry = "$($row.Name)=$($row.Count)"
            if ($r.checked.Count -lt 40 -and $r.checked -notcontains $entry) { $r.checked += $entry }
            if ($WantName) { if (Find-GroupRow @($row) $WantName) { $chosen = $row; break } else { continue } }
            if ($null -eq $row.Count) { if (-not $firstUnknown) { $firstUnknown = $row }; continue }
            $anyCount = $true
            if ($row.Count -le $MaxMembers) { $chosen = $row; break }
        }
        if ($chosen) { break }
        $sig = (@($rows | ForEach-Object { "$($_.Name)@$($_.Node.Y1)" }) -join '|')
        if ($sig -eq $lastSig) { break }
        $lastSig = $sig
        if ($rows.Count -ge 2) {
            $fromY = [int](($rows[$rows.Count - 1].Node.Y1 + $rows[$rows.Count - 1].Node.Y2) / 2)
            $toY = [int](($rows[0].Node.Y1 + $rows[0].Node.Y2) / 2)
        } else { $fromY = [int]($H * 0.80); $toY = [int]($H * 0.40) }
        [void](Invoke-Adb @('shell', "input swipe $([int]($W/2)) $fromY $([int]($W/2)) $toY 600"))
        Start-Sleep -Milliseconds 700
    }
    if (-not $chosen -and -not $WantName -and -not $anyCount -and $firstUnknown) { $chosen = $firstUnknown }   # list shows no member counts at all
    }
    if (-not $chosen -and $WantName) { $r.wantedMissing = $true; $r.group = $WantName; return $r }
    if (-not $chosen) {
        if ($r.checked.Count) { $r.allTooBig = $true } else { $r.noGroup = $true }
        return $r
    }
    $r.groupFound = $true
    $r.group = $chosen.Name
    $r.members = $chosen.Count
    # tap the group and make sure it really opened (group page with "แชท", or the chat room itself)
    $r.entered = ''
    for ($try = 0; $try -lt 3 -and -not $r.entered; $try++) {
        if ($try -gt 0) {
            # still on the list? find the row again (it may have moved) and tap its name
            $nodesR = Get-Ui
            $script:LastUi = $nodesR
            $rowsR = Get-ListRows $nodesR ([int]([Math]::Max(500, $script:ScreenH) * 0.10))
            $again = Find-GroupRow $rowsR $chosen.Name
            if (-not $again) { break }
            $chosen = $again
        }
        $lab = @($script:LastUi | Where-Object { $_.Text -and $_.X1 -ge $chosen.Node.X1 -and $_.X2 -le $chosen.Node.X2 -and $_.Y1 -ge $chosen.Node.Y1 -and $_.Y2 -le $chosen.Node.Y2 } | Select-Object -First 1)
        $c = if ($try -gt 0 -and $lab.Count) { Get-Center $lab[0] } else { Get-Center $chosen.Node }
        Invoke-Tap $c[0] $c[1]
        $r.entered = Wait-EnteredGroup $chosen
    }
    $r.tapTries = $try
    if (-not $r.entered) { $r.enterFailed = $true; $r.dump = Save-UiDump 'group_notopened'; return $r }

    # 3) group page -> "แชท" (verified: the chat room opened)
    if ($r.entered -eq 'profile') {
        $chat = Wait-StableNode $ChatName '(?!)' 5
        if ($chat) {
            $c = Get-Center $chat; Invoke-Tap $c[0] $c[1]
            Start-Sleep -Milliseconds 900
            $r.chat = ((Wait-EnteredGroup $chosen 5) -eq 'chat') -or -not (Find-Node (Get-Ui) $ChatName '(?!)')
        }
    } else { $r.chat = $true }
    if (-not $r.chat) { $r.dump = Save-UiDump 'group_nochat'; return $r }

    # 4) three lines (≡) at the top right of the chat: try several ways, each checked by "เชิญ" appearing
    Start-Sleep -Milliseconds 800
    $inv = $null
    $r.menuTried = @()
    # a) by name / id
    $menu = Wait-StableNode $MenuName $MenuId 3
    if ($menu) {
        $c = Get-Center $menu; Invoke-Tap $c[0] $c[1]; $r.menuTried += "name($($c[0]),$($c[1]))"
        $inv = Wait-StableNode $tName $tId 4
    }
    # b) by the shape of the icon in a screenshot (3 equal bars at the top right)
    if (-not $inv) {
        $xy = Find-MenuIconByImage
        if ($xy) {
            Invoke-Tap $xy[0] $xy[1]; $r.menuTried += "icon($($xy[0]),$($xy[1]))"
            $inv = Wait-StableNode $tName $tId 4
        }
    }
    # c) last resort: the top-right corner of the chat header (where ≡ always is; never the call / search icons)
    if (-not $inv) {
        $nodes = Get-Ui
        $title = @($nodes | Where-Object { $_.Text -and $_.Y2 -le ($H * 0.15) -and $_.Text -eq $r.group } | Select-Object -First 1)
        $hy = if ($title.Count) { [int](($title[0].Y1 + $title[0].Y2) / 2) } else { [int]($H * 0.065) }
        $hx = [int]($W * 0.94)
        Invoke-Tap $hx $hy; $r.menuTried += "corner($hx,$hy)"
        $inv = Wait-StableNode $tName $tId 4
    }
    if (-not $inv) {
        $r.menu = $false
        if (-not $script:LastChatShot) { [void](Find-MenuIconByImage) }
        $r.chatShot = $script:LastChatShot
        return $r
    }
    $r.menu = $true

    # 5) "เชิญ" (or "สมาชิก")
    $r.inviteFound = $true
    $c = Get-Center $inv
    Invoke-Tap $c[0] $c[1]
    if ($MenuTarget -eq 'members') {
        # members list: verified by "แก้ไข" at the top right
        $H5 = [Math]::Max(500, $script:ScreenH)
        $deadline = (Get-Date).AddSeconds(6)
        do {
            $nodes5 = Get-Ui
            $top5 = @($nodes5 | Where-Object { $_.Y2 -le ($H5 * 0.15) })
            if (Find-Node $top5 $EditName '(?i)(edit)') { $r.opened = $true; return $r }
            Start-Sleep -Milliseconds 400
        } while ((Get-Date) -lt $deadline)
        return $r
    }
    $deadline = (Get-Date).AddSeconds(6)
    do {
        if (Test-InviteScreen) { $r.opened = $true; return $r }
        Start-Sleep -Milliseconds 400
    } while ((Get-Date) -lt $deadline)
    # "invite with: friends / QR / link" -> choose friends
    $opt = Wait-StableNode '(?i)^\s*(friends?|เพื่อน|友だち|친구)\s*$' '(?!)' 3
    if ($opt) {
        $c = Get-Center $opt; Invoke-Tap $c[0] $c[1]
        $deadline = (Get-Date).AddSeconds(6)
        do {
            if (Test-InviteScreen) { $r.opened = $true; return $r }
            Start-Sleep -Milliseconds 400
        } while ((Get-Date) -lt $deadline)
    }
    return $r
}
# auto: invite into the existing group if there is one, otherwise create a group
function Invoke-GroupStep {
    $g = Invoke-GroupStepCore
    if ($g.opened -and $script:PreTickTerms.Count) { $g.preTick = Invoke-PreTickByTerms $script:PreTickTerms $script:PreTickExact }
    return $g
}
function Invoke-GroupStepCore {
    if ($GroupAction -eq 'create') { $c = Invoke-CreateGroup; $c.mode = 'create'; return $c }
    $inv = Invoke-InviteToGroup
    if ($inv.opened -or $GroupAction -eq 'invite') { return $inv }
    if ($inv.noGroup -ne $true -and -not $inv.allTooBig) { return $inv }
    # no group, or every group has more than MaxMembers members -> create a new group
    $c = Invoke-CreateGroup
    $c.mode = 'create'
    $c.noGroup = $inv.noGroup
    $c.allTooBig = $inv.allTooBig
    $c.checked = $inv.checked
    return $c
}

# ---------- Display name shown on the search result (above the add / chat button) ----------
function Get-ResultName($nodes, $anchor, [string]$typed) {
    $H = [Math]::Max(500, $script:ScreenH)
    $edit = @($nodes | Where-Object { $_.Class -match 'EditText' -and (Test-Visible $_) } | Select-Object -First 1)
    $top = if ($edit.Count) { $edit[0].Y2 } else { [int]($H * 0.10) }
    $bottom = if ($anchor) { $anchor.Y1 } else { [int]($H * 0.85) }
    $skip = "$IdTabName|$PhoneTabName|$SearchName|$AddBtnName|$AddedText|$NotFoundText|$FriendStatusText"
    # every line of text in the result area (the name is often only in content-desc)
    $lines = @($nodes | Where-Object { $_.Class -notmatch 'EditText' -and (Test-Visible $_) -and ($_.Text -or $_.Desc) -and $_.Y1 -ge $top -and $_.Y2 -le ($bottom + 2) } |
        ForEach-Object { [pscustomobject]@{ T = $(if ($_.Text) { $_.Text.Trim() } else { $_.Desc.Trim() }); Y1 = $_.Y1; Y2 = $_.Y2; X1 = $_.X1 } } |
        Sort-Object Y1, X1)
    $ok = { param($l) $l.T -and $l.T -notmatch $skip -and $l.T -ne $typed -and $l.T -notmatch '^\s*[\d\s\-\+\(\)]+\s*$' -and $l.T -notmatch '(?i)^\s*(line\s*)?id\s*[:：]' }
    # "เป็นเพื่อนกับคุณแล้ว" (already friends) sits right under the name: take the line just above it
    $status = @($lines | Where-Object { $_.T -match $FriendStatusText } | Select-Object -First 1)
    if ($status.Count) {
        $above = @($lines | Where-Object { $_.Y2 -le ($status[0].Y1 + 4) -and $_.Y1 -lt $status[0].Y1 -and (& $ok $_) } | Sort-Object Y1 -Descending | Select-Object -First 1)
        if ($above.Count) { return $above[0].T }
    }
    $cand = @($lines | Where-Object { & $ok $_ })
    if ($cand.Count) { return $cand[0].T }
    return ''
}

# ---------- Type any text (Thai / emoji too) into the focused input field and verify it ----------
function Clear-EditField($edit) {
    $c = Get-Center $edit
    Invoke-Tap $c[0] $c[1]
    $len = [Math]::Max(40, ([string]$edit.Text).Length + 20)
    $dels = (1..$len | ForEach-Object { '67' }) -join ' '
    [void](Invoke-Adb @('shell', "input keyevent 123; input keyevent $dels"))
    Start-Sleep -Milliseconds 250
}
function Test-FieldText([string]$want) {
    $now = Get-EditNode
    $have = if ($now) { ([string]$now.Text).Trim() } else { '' }
    return @(($have -eq $want.Trim()), $have)
}
# ADBKeyboard: install once, switch to it while typing names, switch back afterwards
$script:AdbKbId = 'com.android.adbkeyboard/.AdbIME'
$script:PrevIme = $null
$script:AdbKbReady = $null
function Enable-AdbKeyboard {
    if ($null -ne $script:AdbKbReady) { return $script:AdbKbReady }
    $script:AdbKbReady = $false
    if ($NoTap) { return $false }
    $has = Invoke-Adb @('shell', 'pm list packages com.android.adbkeyboard')
    if ($has -notmatch 'com\.android\.adbkeyboard') {
        if (-not $AdbKeyboardApk -or -not (Test-Path -LiteralPath $AdbKeyboardApk)) { $script:KbNote = 'ADBKeyboard.apk not found next to the script'; return $false }
        $ins = Invoke-Adb @('install', '-r', $AdbKeyboardApk)
        $script:KbNote = "install: $(($ins -split "`r?`n" | Where-Object { $_.Trim() } | Select-Object -Last 1))"
        $has = Invoke-Adb @('shell', 'pm list packages com.android.adbkeyboard')
        if ($has -notmatch 'com\.android\.adbkeyboard') { return $false }
    }
    $cur = (Invoke-Adb @('shell', 'settings get secure default_input_method')).Trim()
    if ($cur -and $cur -ne 'null' -and $cur -notmatch 'adbkeyboard') { $script:PrevIme = $cur }
    [void](Invoke-Adb @('shell', "ime enable $($script:AdbKbId)"))
    [void](Invoke-Adb @('shell', "ime set $($script:AdbKbId)"))
    Start-Sleep -Milliseconds 800
    $now = (Invoke-Adb @('shell', 'settings get secure default_input_method')).Trim()
    $script:AdbKbReady = ($now -match 'adbkeyboard')
    if (-not $script:AdbKbReady) { $script:KbNote = "could not switch keyboard (now: $now)" }
    return $script:AdbKbReady
}
function Restore-Ime {
    if ($script:PrevIme -and -not $NoTap) { [void](Invoke-Adb @('shell', "ime set $($script:PrevIme)")) }
    $script:AdbKbReady = $null   # switch to ADBKeyboard again the next time a name is typed
}
# the invite screen may show "ค้นหา" as a plain bar: tap it so the real input field appears
function Open-SearchField {
    if (Get-EditNodeQuick) { return $true }
    $H = [Math]::Max(500, $script:ScreenH)
    for ($k = 0; $k -lt 3; $k++) {
        $nodes = Get-Ui
        if (@($nodes | Where-Object { $_.Class -match 'EditText' -and (Test-Visible $_) }).Count) { return $true }
        $bar = @($nodes | Where-Object { (Test-Visible $_) -and $_.Y2 -le ($H * 0.4) -and (($_.Text -match $SearchName -or $_.Desc -match $SearchName) -or $_.Id -match '(?i)search') } | Sort-Object Y1 | Select-Object -First 1)
        if (-not $bar.Count) { break }
        $c = Get-Center $bar[0]
        Invoke-Tap $c[0] $c[1]
        Start-Sleep -Milliseconds 600
    }
    return [bool](Get-EditNodeQuick)
}
function Get-EditNodeQuick {
    $ui = Get-Ui
    $e = @($ui | Where-Object { $_.Class -match 'EditText' -and (Test-Visible $_) } | Select-Object -First 1)
    if ($e.Count) { return $e[0] } else { return $null }
}
function Save-UiDump([string]$tag) {
    try {
        $src = Join-Path $tmpDir ("ui_{0}.xml" -f $script:SafeSerial)
        [void](Get-Ui)
        $dst = Join-Path $tmpDir ("{0}_{1}_{2}.xml" -f $tag, $script:SafeSerial, (Get-Date).ToString('HHmmss'))
        Copy-Item -LiteralPath $src -Destination $dst -Force
        return $dst
    } catch { return '' }
}
function Invoke-TypeAny([string]$Value) {
    $methods = @()
    if ($Value -notmatch '[^\x20-\x7E]') { $methods += 'adb' }
    if (Enable-AdbKeyboard) { $methods += 'adbkeyboard' }
    if ($LdConsole -and (Test-Path -LiteralPath $LdConsole) -and $LdIndex -ge 0) { $methods += 'ldconsole' }
    if (-not $methods.Count) { return [ordered]@{ found = $false; text = $Value; error = "No way to type Thai/emoji: $($script:KbNote)" } }
    if (-not (Open-SearchField)) { return [ordered]@{ found = $false; text = $Value; error = 'Search field not found on the invite screen'; dump = (Save-UiDump 'invite_nofield') } }
    $have = ''
    foreach ($m in $methods) {
        $edit = Get-EditNode
        if (-not $edit) { return [ordered]@{ found = $false; text = $Value; error = 'Input field not found' } }
        if ($NoTap) { return [ordered]@{ found = $true; text = $Value; method = $m } }
        Clear-EditField $edit
        switch ($m) {
            'adb' { [void](Invoke-Adb @('shell', "input text $(ConvertTo-AdbText $Value)")) }
            'ldconsole' {
                $old = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
                try { [void](& $LdConsole action --index $LdIndex --key call.input --value $Value 2>&1) } catch {} finally { $ErrorActionPreference = $old }
            }
            'adbkeyboard' {
                $b64 = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($Value))
                [void](Invoke-Adb @('shell', 'am broadcast -a ADB_CLEAR_TEXT'))
                Start-Sleep -Milliseconds 150
                [void](Invoke-Adb @('shell', "am broadcast -a ADB_INPUT_B64 --es msg $b64"))
            }
        }
        Start-Sleep -Milliseconds 700
        $chk = Test-FieldText $Value
        $have = $chk[1]
        if ($chk[0]) { return [ordered]@{ found = $true; text = $Value; method = $m; verified = $true } }
    }
    return [ordered]@{ found = $false; text = $Value; error = "Could not type the name (field shows '$have', tried: $($methods -join ', ')) $($script:KbNote)"; dump = (Save-UiDump 'invite_type') }
}

# ---------- Home -> "กลุ่ม" (the group list) ----------
function Open-GroupList {
    $r = [ordered]@{ home = $false; groupsOpened = $false; noGroup = $null }
    $r.home = [bool](Invoke-GoHome)
    $W = [Math]::Max(300, $script:ScreenW); $H = [Math]::Max(500, $script:ScreenH)
    $hdr = $null
    for ($k = 0; $k -lt 4 -and -not $hdr; $k++) {
        $hdr = Wait-StableNode $GroupsHeader '(?i)(group_?list|groups?_(tab|header|title)|home_group)' 3
        if (-not $hdr) {
            [void](Invoke-Adb @('shell', "input swipe $([int]($W/2)) $([int]($H*0.75)) $([int]($W/2)) $([int]($H*0.40)) 500"))
            Start-Sleep -Milliseconds 700
        }
    }
    if (-not $hdr) { $r.noGroup = $true; return $r }
    $label = if ($hdr.Text) { $hdr.Text } else { $hdr.Desc }
    $m = [regex]::Match($label, '(\d+)')
    if ($m.Success -and [int]$m.Groups[1].Value -eq 0) { $r.noGroup = $true; return $r }
    $c = Get-Center $hdr
    Invoke-Tap $c[0] $c[1]
    $r.groupsOpened = $true
    Start-Sleep -Milliseconds 900
    return $r
}
# list every group (name + member count), scrolling to the end
function Invoke-ScanGroups {
    $r = Open-GroupList
    $r.step = 'scangroups'
    $r.groups = @()
    if ($NoTap -or -not $r.groupsOpened) { return $r }
    $W = [Math]::Max(300, $script:ScreenW); $H = [Math]::Max(500, $script:ScreenH)
    $seenG = @{}
    $lastSig = ''
    for ($page = 0; $page -lt 30; $page++) {
        $nodes = Get-Ui
        $rows = Get-ListRows $nodes ([int]($H * 0.10))
        foreach ($row in $rows) {
            if ($seenG.ContainsKey($row.Name)) { continue }
            $seenG[$row.Name] = $true
            $r.groups += [ordered]@{ name = $row.Name; members = $row.Count }
        }
        $sig = (@($rows | ForEach-Object { "$($_.Name)@$($_.Node.Y1)" }) -join '|')
        if ($sig -eq $lastSig -or $rows.Count -eq 0) { break }
        $lastSig = $sig
        if ($rows.Count -ge 2) {
            $fromY = [int](($rows[$rows.Count - 1].Node.Y1 + $rows[$rows.Count - 1].Node.Y2) / 2)
            $toY = [int](($rows[0].Node.Y1 + $rows[0].Node.Y2) / 2)
        } else { $fromY = [int]($H * 0.80); $toY = [int]($H * 0.40) }
        [void](Invoke-Adb @('shell', "input swipe $([int]($W/2)) $fromY $([int]($W/2)) $toY 600"))
        Start-Sleep -Milliseconds 700
    }
    if (-not $r.groups.Count) { $r.noGroup = $true }
    return $r
}
# invite screen: search each display name, tick its circle (skip if already ticked / green)
function Get-TickSig($nodes) {
    $H = [Math]::Max(500, $script:ScreenH)
    return ((@($nodes | Where-Object { ($_.Text -match '\d' -and $_.Y2 -le $H * 0.2) -or $_.Checked } | ForEach-Object { "$($_.Text)|$($_.Checked)@$($_.X1),$($_.Y1)" })) -join ';')
}
function Get-NameRow($nodes, [string]$name, [switch]$ExactOnly) {
    $W = [Math]::Max(300, $script:ScreenW)
    $edit = @($nodes | Where-Object { $_.Class -match 'EditText' -and (Test-Visible $_) } | Select-Object -First 1)
    $minY = if ($edit.Count) { $edit[0].Y2 } else { 0 }
    $want = $name.Trim()
    foreach ($exact in @($true, $false)) {
        $hits = @($nodes | Where-Object {
                $lab = if ($_.Text) { $_.Text.Trim() } else { ([string]$_.Desc).Trim() }
                $_.Class -notmatch 'EditText' -and (Test-Visible $_) -and $lab -and $_.Y1 -ge $minY -and
                $(if ($exact) { $lab -eq $want } else { $lab.Contains($want) -or $want.Contains($lab) -and $lab.Length -ge 2 })
            } | Sort-Object Y1)
        if (-not $exact -and $ExactOnly) { break }
        $found = @()
        foreach ($h in $hits) {
            # the list row that holds this name (wide; the selected-people strip has narrow chips)
            $row = @($nodes | Where-Object { $_.Click -and (Test-Visible $_) -and $_.X1 -le $h.X1 -and $_.Y1 -le $h.Y1 -and $_.X2 -ge $h.X2 -and $_.Y2 -ge $h.Y2 -and ($_.X2 - $_.X1) -ge ($W * 0.6) } |
                Sort-Object { ($_.X2 - $_.X1) * ($_.Y2 - $_.Y1) } | Select-Object -First 1)
            if ($row.Count) { $found += @{ Row = $row[0]; Label = [pscustomobject]@{ Text = $(if ($h.Text) { $h.Text } else { $h.Desc }) }; Exact = $exact } }
        }
        if ($exact -and $found.Count) { return $found[0] }
        # a partial match (name cut short with "…") only when it is the only one, so the wrong person is never ticked
        if (-not $exact -and $found.Count -eq 1) { return $found[0] }
    }
    return $null
}
function Test-RowTicked($nodes, $row) {
    $inside = @($nodes | Where-Object { $_.X1 -ge $row.X1 -and $_.X2 -le $row.X2 -and $_.Y1 -ge $row.Y1 -and $_.Y2 -le $row.Y2 })
    if (@($inside | Where-Object { $_.Checkable }).Count -or $row.Checkable) { return @{ Known = $true; On = [bool](@($inside | Where-Object { $_.Checked }).Count -or $row.Checked) } }
    return @{ Known = $false; On = $false }
}
# ---------- circles from a screenshot (green = ticked, gray ring = empty, filled gray = cannot select) ----------
if (-not ('LinePxShot' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
public class LinePxShot {
    public int Width, Height; int[] px;
    public LinePxShot(int w, int h, int[] pixels) { Width = w; Height = h; px = pixels; }
    // light-gray wide bar (the search box): rows whose longest light-gray run is >= minRun, band height in [minH, maxH]
    // returns { x1, x2, yTop, yBottom } or empty
    public int[] FindGrayBar(int y1, int y2, int minRun, int minH, int maxH) {
        y1 = Math.Max(0, y1); y2 = Math.Min(Height - 1, y2);
        int bandStart = -1, bx1 = 0, bx2 = 0;
        for (int y = y1; y <= y2 + 1; y++) {
            int best = 0, bs = 0, cur = 0, cs = 0;
            if (y <= y2) {
                int row = y * Width;
                for (int x = 0; x < Width; x++) {
                    int p = px[row + x];
                    int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
                    int mx = Math.Max(r, Math.Max(g, b)), mn = Math.Min(r, Math.Min(g, b));
                    bool gray = mn >= 222 && mx <= 251 && (mx - mn) <= 10;
                    if (gray) { if (cur == 0) cs = x; cur++; if (cur > best) { best = cur; bs = cs; } } else cur = 0;
                }
            }
            if (best >= minRun) {
                if (bandStart < 0) { bandStart = y; bx1 = bs; bx2 = bs + best - 1; }
                else { bx1 = Math.Max(bx1, bs); bx2 = Math.Min(bx2, bs + best - 1); }
            } else if (bandStart >= 0) {
                int h = y - bandStart;
                if (h >= minH && h <= maxH && bx2 - bx1 >= minRun / 2) return new int[] { bx1, bx2, bandStart, y - 1 };
                bandStart = -1;
            }
        }
        return new int[0];
    }
    public int[] FindCircles(int x1, int y1, int x2, int y2, int minD, int maxD) {
        x1 = Math.Max(0, x1); y1 = Math.Max(0, y1);
        x2 = Math.Min(Width - 1, x2); y2 = Math.Min(Height - 1, y2);
        int[] buf = new int[5 * 1000]; int n = 0;
        if (x2 <= x1 || y2 <= y1) return new int[0];
        int start = -1, lastHit = -1, g = 0, r = 0, minX = int.MaxValue, maxX = -1;
        for (int y = y1; y <= y2 + 3; y++) {
            int rg = 0, rr = 0, rmin = int.MaxValue, rmax = -1;
            if (y <= y2) {
                int row = y * Width;
                for (int x = x1; x <= x2; x++) {
                    int c = px[row + x];
                    int R = (c >> 16) & 0xFF, G = (c >> 8) & 0xFF, B = c & 0xFF;
                    bool green = G > 140 && G - R > 70 && G - B > 40;
                    int mx = Math.Max(R, Math.Max(G, B)), mn = Math.Min(R, Math.Min(G, B));
                    bool ring = !green && (mx - mn) < 18 && mx >= 60 && mx <= 238;
                    if (green) rg++;
                    if (ring) rr++;
                    if (green || ring) { if (x < rmin) rmin = x; if (x > rmax) rmax = x; }
                }
            }
            if (rg + rr > 0) {
                if (start < 0) { start = y; g = 0; r = 0; minX = int.MaxValue; maxX = -1; }
                g += rg; r += rr;
                if (rmin < minX) minX = rmin;
                if (rmax > maxX) maxX = rmax;
                lastHit = y;
            } else if (start >= 0 && y - lastHit > 2) {
                int h = lastHit - start + 1, w = maxX - minX + 1;
                bool inside = minX > x1 + 1 && maxX < x2 - 1;
                bool round = w >= h * 0.6 && w <= h * 1.5;
                if (h >= minD && h <= maxD && inside && round && n + 5 <= buf.Length) {
                    buf[n++] = (minX + maxX) / 2; buf[n++] = (start + lastHit) / 2; buf[n++] = Math.Max(h, w); buf[n++] = g; buf[n++] = r;
                }
                start = -1;
            }
        }
        int[] res = new int[n];
        Array.Copy(buf, res, n);
        return res;
    }
}
'@
}
function Get-ShotPx {
    $local = Join-Path $tmpDir ("px_{0}.png" -f $script:SafeSerial)
    Remove-Item -LiteralPath $local -Force -ErrorAction SilentlyContinue
    [void](Invoke-Adb @('shell', 'screencap -p /sdcard/__px.png'))
    [void](Invoke-Adb @('pull', '/sdcard/__px.png', $local))
    if (-not (Test-Path -LiteralPath $local)) { return $null }
    $bytes = [System.IO.File]::ReadAllBytes($local)
    if ($bytes.Length -gt 15 -and [System.Text.Encoding]::ASCII.GetString($bytes, 0, 7) -eq 'RAWARGB') {
        # raw test image: "RAWARGB" + int32 width + int32 height + width*height int32 pixels
        $w = [BitConverter]::ToInt32($bytes, 7); $h = [BitConverter]::ToInt32($bytes, 11)
        $px = New-Object int[] ($w * $h)
        [Buffer]::BlockCopy($bytes, 15, $px, 0, $w * $h * 4)
        return (New-Object LinePxShot($w, $h, $px))
    }
    Add-Type -AssemblyName System.Drawing
    $ms = New-Object System.IO.MemoryStream(, $bytes)
    $bmp = New-Object System.Drawing.Bitmap($ms)
    try {
        $rect = New-Object System.Drawing.Rectangle(0, 0, $bmp.Width, $bmp.Height)
        $d = $bmp.LockBits($rect, 'ReadOnly', 'Format32bppArgb')
        $px = New-Object int[] ($bmp.Width * $bmp.Height)
        [System.Runtime.InteropServices.Marshal]::Copy($d.Scan0, $px, 0, $px.Length)
        $bmp.UnlockBits($d)
        return (New-Object LinePxShot($bmp.Width, $bmp.Height, $px))
    } finally { $bmp.Dispose(); $ms.Dispose() }
}
function Get-CircleList($shot, [int]$topY) {
    $W = [Math]::Max(300, $script:ScreenW); $H = [Math]::Max(500, $script:ScreenH)
    $sx = $shot.Width / [double]$W; $sy = $shot.Height / [double]$H
    $raw = $shot.FindCircles([int]($W * 0.72 * $sx), [int]($topY * $sy), $shot.Width - 1, $shot.Height - 1,
                             [int]([Math]::Max(8, $shot.Height * 0.012)), [int]($shot.Height * 0.07))
    $out = @()
    for ($i = 0; $i + 4 -lt $raw.Count; $i += 5) {
        $dd = [double]$raw[$i + 2]
        $green = ($raw[$i + 3] -ge [Math]::Max(30, 0.30 * $dd * $dd))
        $disabled = (-not $green) -and ($raw[$i + 4] -ge 0.35 * $dd * $dd)
        $out += [pscustomobject]@{ X = [int]($raw[$i] / $sx); Y = [int]($raw[$i + 1] / $sy); D = [int]($dd / $sy); State = $(if ($green) { 'green' } elseif ($disabled) { 'disabled' } else { 'white' }) }
    }
    return , $out
}
# name lines (text / content-desc) that contain the term, below the search box, top to bottom
function Get-TermLabels($nodes, [string]$term, [string[]]$exactTerms) {
    $W = [Math]::Max(300, $script:ScreenW)
    $edit = @($nodes | Where-Object { $_.Class -match 'EditText' -and (Test-Visible $_) } | Select-Object -First 1)
    $minY = if ($edit.Count) { $edit[0].Y2 } else { 0 }
    $want = $term.Trim().ToLowerInvariant()
    $labs = @()
    foreach ($h in @($nodes | Where-Object { $_.Class -notmatch 'EditText' -and (Test-Visible $_) -and ($_.Text -or $_.Desc) -and $_.Y1 -ge $minY -and $_.X1 -lt ($W * 0.7) } | Sort-Object Y1)) {
        $lab = if ($h.Text) { $h.Text.Trim() } else { $h.Desc.Trim() }
        $labL = $lab.ToLowerInvariant()
        $cut = $labL.TrimEnd('…', '.', ' ')
        if (-not ($labL.Contains($want) -or ($exactTerms -contains $term -and $lab -match '(…|\.\.\.)$' -and $cut.Length -ge 2 -and $want.StartsWith($cut)))) { continue }
        $cy = [int](($h.Y1 + $h.Y2) / 2)
        if (@($labs | Where-Object { [Math]::Abs($_.Y - $cy) -lt 12 }).Count) { continue }
        $labs += [pscustomobject]@{ Name = $lab; Y = $cy; Node = $h }
    }
    if ($exactTerms -contains $term) {
        # a full scanned name: the exact name; a cut-short name ("…") only when there is just one such line
        $ex = @($labs | Where-Object { $_.Name -eq $term.Trim() })
        if ($ex.Count) { return , $ex }
        $names = @($labs | ForEach-Object { $_.Name } | Select-Object -Unique)
        if ($names.Count -eq 1) { return , @($labs | Where-Object { $_.Name -eq $names[0] } | Select-Object -First 1) }
        return , @()
    }
    return , $labs
}
# keep only names that are list rows (have a circle on their line, or sit in a wide row) - not the "selected" chips
function Select-ListLabels($labels, $circles, $nodes) {
    $W = [Math]::Max(300, $script:ScreenW)
    if (@($circles).Count) { return , @($labels | Where-Object { Find-CircleForLabel $circles $_ }) }
    return , @($labels | Where-Object {
            $h = $_.Node
            @($nodes | Where-Object { $_.X1 -le $h.X1 -and $_.Y1 -le $h.Y1 -and $_.X2 -ge $h.X2 -and $_.Y2 -ge $h.Y2 -and ($_.X2 - $_.X1) -ge ($W * 0.6) -and $_ -ne $h }).Count -gt 0
        })
}
function Find-CircleForLabel($circles, $label) {
    $best = $null; $bd = 99999
    foreach ($c in @($circles)) {
        $dy = [Math]::Abs($c.Y - $label.Y)
        $tol = [Math]::Max(30, [int]($c.D * 1.1))
        if ($dy -le $tol -and $dy -lt $bd) { $best = $c; $bd = $dy }
    }
    return $best
}

# ---------- before ticking circles: search each name / first letters, tick every match, then tap X ----------
function Get-TermRows($nodes, [string]$term) {
    $W = [Math]::Max(300, $script:ScreenW)
    $edit = @($nodes | Where-Object { $_.Class -match 'EditText' -and (Test-Visible $_) } | Select-Object -First 1)
    $minY = if ($edit.Count) { $edit[0].Y2 } else { 0 }
    $want = $term.Trim().ToLowerInvariant()
    $out = @()
    foreach ($h in @($nodes | Where-Object { $_.Class -notmatch 'EditText' -and (Test-Visible $_) -and ($_.Text -or $_.Desc) -and $_.Y1 -ge $minY } | Sort-Object Y1)) {
        $lab = if ($h.Text) { $h.Text.Trim() } else { $h.Desc.Trim() }
        if (-not $lab.ToLowerInvariant().Contains($want)) { continue }
        # the wide list row that holds this name (the "selected" strip has narrow chips -> ignored)
        $row = @($nodes | Where-Object { $_.Click -and (Test-Visible $_) -and $_.X1 -le $h.X1 -and $_.Y1 -le $h.Y1 -and $_.X2 -ge $h.X2 -and $_.Y2 -ge $h.Y2 -and ($_.X2 - $_.X1) -ge ($W * 0.6) } |
            Sort-Object { ($_.X2 - $_.X1) * ($_.Y2 - $_.Y1) } | Select-Object -First 1)
        if ($row.Count -and -not @($out | Where-Object { Test-SameSpot $_.Row $row[0] }).Count) { $out += @{ Row = $row[0]; Name = $lab } }
    }
    return , $out
}
# a scanned full name: tick only the exact name when it is there (not "Mint 2" for "Mint")
function Select-TermRows($rows, [string]$term, [string[]]$exactTerms) {
    if ($exactTerms -notcontains $term) { return , @($rows) }
    $ex = @($rows | Where-Object { $_.Name -eq $term.Trim() })
    if ($ex.Count) { return , $ex }
    return , @($rows)
}
function Invoke-ClearSearchX {
    $nodes = Get-Ui
    $edit = @($nodes | Where-Object { $_.Class -match 'EditText' -and (Test-Visible $_) } | Select-Object -First 1)
    if (-not $edit.Count) { return 'nofield' }
    $e = $edit[0]
    $midY = ($e.Y1 + $e.Y2) / 2
    # the X (clear) button: on the search line, at the right end of the field
    $x = @($nodes | Where-Object { $_ -ne $e -and (Test-Visible $_) -and $_.Click -and $midY -ge $_.Y1 -and $midY -le $_.Y2 -and $_.X1 -ge ($e.X1 + ($e.X2 - $e.X1) * 0.6) -and ($_.X2 - $_.X1) -le 160 -and
            ($_.Desc -match '(?i)(clear|delete|close|cancel|ล้าง|ลบ|ยกเลิก|ปิด|クリア|削除|지우기|삭제)' -or $_.Id -match '(?i)(clear|delete|close|cancel)' -or $_.Class -match 'Image' -or -not $_.Text) } |
        Sort-Object X2 -Descending | Select-Object -First 1)
    if ($x.Count) {
        $c = Get-Center $x[0]; Invoke-Tap $c[0] $c[1]
        Start-Sleep -Milliseconds 500
        $now = Get-EditNodeQuick
        if (-not $now -or -not ([string]$now.Text).Trim()) { return 'x' }
    }
    # no X button: empty the field by keyboard
    $now = Get-EditNodeQuick
    if ($now) { Clear-EditField $now }
    return 'keys'
}
function Write-Prog([string]$state, [string]$term, $names = @()) {
    if (-not $ProgressFile) { return }
    try { [System.IO.File]::WriteAllText($ProgressFile, "$state`t$term`t$((@($names) | Where-Object { $_ }) -join '|')", (New-Object System.Text.UTF8Encoding($false))) } catch {}
}
function Invoke-PreTickByTerms([string[]]$terms, [string[]]$exactTerms = @()) {
    $res = [ordered]@{ items = @(); clear = '' }
    foreach ($term in $terms) {
        $e = [ordered]@{ term = $term; typed = $false; found = @(); ticked = @(); already = @(); failed = @(); excluded = @(); error = '' }
        Write-Prog 'search' $term
        $ty = Invoke-TypeAny $term
        $e.typed = [bool]$ty.found
        $e.typeMethod = $ty.method
        if (-not $ty.found) { $e.error = $ty.error; $e.dump = $ty.dump; $res.items += $e; continue }
        # wait for the result list to settle
        $rows = @(); $prev = ''
        $deadline = (Get-Date).AddSeconds(6)
        do {
            Start-Sleep -Milliseconds 500
            $nodes = Get-Ui
            $rows = Get-TermLabels $nodes $term $exactTerms
            $sig = (@($rows | ForEach-Object { "$($_.Name)@$($_.Y)" }) -join '|')
            if ($rows.Count -and $sig -eq $prev) { break }
            $prev = $sig
        } while ((Get-Date) -lt $deadline)
        if (-not $rows.Count) { $e.error = 'No result for this name'; Write-Prog 'none' $term; $res.items += $e; continue }
        $e.found = @($rows | ForEach-Object { $_.Name } | Select-Object -Unique)
        Write-Prog 'found' $term $e.found
        # tick each match by its circle (re-read after every tap: the list moves when the "selected" strip appears)
        $done = @{}
        for ($k = 0; $k -lt 40; $k++) {
            $nodes = Get-Ui
            $labels = Get-TermLabels $nodes $term $exactTerms
            $edit = @($nodes | Where-Object { $_.Class -match 'EditText' -and (Test-Visible $_) } | Select-Object -First 1)
            $topY = if ($edit.Count) { $edit[0].Y2 } else { [int]([Math]::Max(500, $script:ScreenH) * 0.15) }
            $shot = Get-ShotPx
            $circles = if ($shot) { Get-CircleList $shot $topY } else { @() }
            $labels = Select-ListLabels $labels $circles $nodes
            $next = $null
            $seen = @{}
            foreach ($l in $labels) {
                $seen[$l.Name] = 1 + [int]$seen[$l.Name]
                $key = "$($l.Name)#$($seen[$l.Name])"
                if ($done.ContainsKey($key)) { continue }
                if ($script:ExcludeTerms.Count) {
                    # on the "do not tick" list: skip it and take the next match
                    $lk = (($l.Name -replace '\s+', ' ').Trim().ToLowerInvariant())
                    if (@($script:ExcludeTerms | Where-Object { $lk.Contains($_) }).Count) { $done[$key] = 1; if ($e.excluded -notcontains $l.Name) { $e.excluded += $l.Name }; continue }
                }
                $next = @{ L = $l; Key = $key; Occ = $seen[$l.Name] }; break
            }
            if (-not $next) { break }
            $done[$next.Key] = 1
            $circ = Find-CircleForLabel $circles $next.L
            if ($circ -and $circ.State -in 'green', 'disabled') { $e.already += $next.L.Name; if ($circ.State -eq 'green') { break } else { continue } }
            # tap the circle (or the name line when no circle is drawn there), then check the circle turned green
            $taps = @()
            if ($circ) { $taps += , @($circ.X, $circ.Y) }
            $taps += , @([int](($next.L.Node.X1 + $next.L.Node.X2) / 2), $next.L.Y)
            $ok = $false
            $before = Get-TickSig $nodes
            foreach ($tp in $taps) {
                Invoke-Tap $tp[0] $tp[1]
                Start-Sleep -Milliseconds 450
                $nodes2 = Get-Ui
                $shot2 = Get-ShotPx
                $circ2 = if ($shot2) { Get-CircleList $shot2 $topY } else { @() }
                $labsAll2 = Get-TermLabels $nodes2 $term $exactTerms
                $labsAll2 = Select-ListLabels $labsAll2 $circ2 $nodes2
                $labels2 = @($labsAll2 | Where-Object { $_.Name -eq $next.L.Name })
                $l2 = if ($labels2.Count -ge $next.Occ) { $labels2[$next.Occ - 1] } elseif ($labels2.Count) { $labels2[0] } else { $null }
                $c2 = if ($l2 -and @($circ2).Count) { Find-CircleForLabel $circ2 $l2 } else { $null }
                if ($c2) {
                    if ($c2.State -eq 'green') { $ok = $true; break }
                    if ($c2.State -eq 'white') { continue }    # still empty: try the next way of tapping
                    break
                }
                # no circle to look at: checkbox state from the screen structure, else "something changed"
                $st = if ($l2) { Test-RowTicked $nodes2 ([pscustomobject]@{ X1 = 0; X2 = [Math]::Max(300, $script:ScreenW); Y1 = $l2.Node.Y1 - 30; Y2 = $l2.Node.Y2 + 30; Checkable = $false; Checked = $false }) } else { @{ Known = $false } }
                if ($st.Known) { if ($st.On) { $ok = $true; break } else { continue } }
                $ok = ((Get-TickSig $nodes2) -ne $before)
                break
            }
            if ($ok) { $e.ticked += $next.L.Name } else { $e.failed += $next.L.Name }
            Write-Prog 'tick' $term (@($e.ticked) + @($e.already))
            if ($ok) { break }    # found one and ticked it: 1 per search is enough
        }
        if (-not @($e.ticked).Count -and -not @($e.already).Count -and -not @($e.failed).Count) { $e.error = 'No result for this name' }
        $res.items += $e
    }
    # X: clear the search so the full list is back for the normal circle ticking
    $res.clear = Invoke-ClearSearchX
    Restore-Ime
    Start-Sleep -Milliseconds 600
    return $res
}
function Invoke-InviteByNames([string[]]$names) {
    # same as "search names then tick": exact name, circle checked in the screenshot
    $pt = Invoke-PreTickByTerms $names $names
    $out = @()
    foreach ($it in @($pt.items)) {
        $tk = @($it.ticked); $al = @($it.already); $fl = @($it.failed)
        $e = [ordered]@{ name = $it.term; typed = [bool]$it.typed; found = ($tk.Count + $al.Count + $fl.Count) -gt 0
                         ticked = ($tk.Count + $al.Count) -gt 0; already = ($al.Count -gt 0 -and $tk.Count -eq 0); verified = ($tk.Count + $al.Count) -gt 0 }
        $m = @($tk + $al) | Select-Object -First 1
        if ($m) { $e.matched = $m }
        $e.typeMethod = $it.typeMethod
        if ($it.dump) { $e.dump = $it.dump }
        if ($it.error) { $e.error = $(if ($it.error -match 'No result') { 'Name not found in the invite list' } else { $it.error }) }
        elseif ($fl.Count -and -not $e.ticked) { $e.error = 'Tapped the name but the circle did not turn on' }
        $out += $e
    }
    return , $out
}
# ---------- home -> search box -> type each OA name -> is it in this LINE? ----------
function ConvertTo-FindKey([string]$t) { return (($t -replace '\s+', ' ').Trim().ToLowerInvariant()) }
function Get-FindMatches($nodes, [string]$term) {
    $W = [Math]::Max(300, $script:ScreenW)
    $edit = @($nodes | Where-Object { $_.Class -match 'EditText' -and (Test-Visible $_) } | Select-Object -First 1)
    $minY = if ($edit.Count) { $edit[0].Y2 } else { 0 }
    $want = ConvertTo-FindKey $term
    $labs = @($nodes | Where-Object { $_.Class -notmatch 'EditText' -and (Test-Visible $_) -and ($_.Text -or $_.Desc) -and $_.Y1 -ge $minY } |
        ForEach-Object { [pscustomobject]@{ T = $(if ($_.Text) { $_.Text.Trim() } else { $_.Desc.Trim() }); N = $_ } } | Sort-Object { $_.N.Y1 })
    $heads = @($labs | Where-Object { $_.T -match $ResultSection })
    $out = @()
    foreach ($l in $labs) {
        if ($l.T -match $ResultSection) { continue }
        $k = ConvertTo-FindKey $l.T
        # "ค้นหา "xxx" บน LINE" / keyword suggestions are not results
        if ($k -match '^(ค้นหา|search|検索|검색)\b' -or $l.T -match '["“”「」]') { continue }
        $cut = $k.TrimEnd('…', '.', ' ')
        $hit = $k.Contains($want) -or ($k -ne $cut -and $cut.Length -ge 3 -and $want.StartsWith($cut))
        if (-not $hit) { continue }
        $h = @($heads | Where-Object { $_.N.Y2 -le ($l.N.Y1 + 5) } | Select-Object -Last 1)
        $sec = if ($h.Count) { ($h[0].T -replace '\s*\(?\s*[\d,]+\s*\)?\s*[>›]?\s*$', '').Trim() } elseif ($script:FindMethod -eq 'oa') { 'บัญชีทางการ' } else { '' }
        if ($sec -and $sec -match $SkipSection) { continue }
        if (@($out | Where-Object { $_.name -eq $l.T -and $_.section -eq $sec }).Count) { continue }
        $out += [ordered]@{ name = $l.T; section = $sec; exact = ($k -eq $want) }
    }
    return , $out
}
# home screen: tap the "ค้นหา" bar under the profile (left part: the right end is the QR scanner), wait for the search input
function Open-HomeSearch {
    $r = [ordered]@{ ok = $false; tapped = ''; x = 0; y = 0 }
    $bad = '(?i)(qr|scan|code_?reader|camera|สแกน|คิวอาร์|コード|스캔)'
    for ($k = 0; $k -lt 3; $k++) {
        $nodes = Get-Ui
        $W = [Math]::Max(300, $script:ScreenW); $H = [Math]::Max(500, $script:ScreenH)
        $top = @($nodes | Where-Object { (Test-Visible $_) -and $_.Y2 -le ($H * 0.6) -and $_.Id -notmatch $bad -and $_.Desc -notmatch $bad })
        # 1) the word "ค้นหา" anywhere up there (text / description / hint of the field)  2) a wide search bar by id  3) any EditText up there
        $word = '(?i)(ค้นหา|search|検索|검색)'
        $hint = @($top | Where-Object {
                $lab = @($_.Text, $_.Desc, $_.Hint) | Where-Object { $_ -and $_.Length -le 25 -and $_ -match $word } | Select-Object -First 1
                [bool]$lab } | Sort-Object @{ e = { -not (($_.Text -match $SearchName) -or ($_.Hint -match $SearchName) -or ($_.Desc -match $SearchName)) } }, Y1 | Select-Object -First 1)
        $bar = @($top | Where-Object { ($_.Id -match '(?i)search' -or $_.Class -match 'EditText') -and ($_.X2 - $_.X1) -ge ($W * 0.45) } | Sort-Object Y1 | Select-Object -First 1)
        if ($hint.Count -and ($hint[0].X2 - $hint[0].X1) -lt ($W * 0.45)) { $c = Get-Center $hint[0]; $x = $c[0]; $y = $c[1]; $r.tapped = 'hint' }
        elseif ($hint.Count) { $x = [int]($hint[0].X1 + ($hint[0].X2 - $hint[0].X1) * 0.3); $y = [int](($hint[0].Y1 + $hint[0].Y2) / 2); $r.tapped = 'hintbar' }
        elseif ($bar.Count) { $x = [int]($bar[0].X1 + ($bar[0].X2 - $bar[0].X1) * 0.3); $y = [int](($bar[0].Y1 + $bar[0].Y2) / 2); $r.tapped = 'bar' }
        else { $r.error = 'Search box not found on the home screen'; break }
        $r.x = $x; $r.y = $y
        if (-not $r.homeDump) { $r.homeDump = Save-UiDump 'findoa_home' }   # what the home screen looked like (for checking the tap spot)
        Invoke-Tap $x $y
        # opened = an input field that has focus, or the home screen (add-friend icon) is gone and an input field is there
        $deadline = (Get-Date).AddSeconds(4)
        do {
            Start-Sleep -Milliseconds 400
            $n2 = Get-Ui
            $ed = @($n2 | Where-Object { $_.Class -match 'EditText' -and (Test-Visible $_) })
            $homeGone = -not (Find-Node $n2 $AddName $AddId)
            if ($ed.Count -and (@($ed | Where-Object { $_.Focused }).Count -or $homeGone)) { $r.ok = $true; return $r }
        } while ((Get-Date) -lt $deadline)
    }
    if (-not $r.ok) { $r.dump = Save-UiDump 'findoa_nosearch' }
    return $r
}
# แชท -> เพื่อน -> บัญชีทางการ -> ค้นหาด้วยชื่อ  (each tap is checked by the next target appearing)
function Find-StepNode($nodes, [string]$pattern, [string]$where) {
    $H = [Math]::Max(500, $script:ScreenH)
    $c = @($nodes | Where-Object { (Test-Visible $_) -and $_.Class -notmatch 'EditText' -and ($_.Text -match $pattern -or $_.Desc -match $pattern) })
    if ($where -eq 'bottom') { $b = @($c | Where-Object { $_.Y1 -ge ($H * 0.8) }); if ($b.Count) { $c = $b } }
    elseif ($where -eq 'top') { $c = @($c | Where-Object { $_.Y2 -le ($H * 0.8) }) }
    $c = @($c | Sort-Object @{ e = { -not $_.Click } }, Y1)
    if ($c.Count) { return $c[0] } else { return $null }
}
function Test-SearchInput($nodes) { return [bool]@($nodes | Where-Object { $_.Class -match 'EditText' -and (Test-Visible $_) }).Count }
function Open-OaSearch {
    $r = [ordered]@{ ok = $false; tapped = 'oa'; x = 0; y = 0; path = @() }
    $steps = @(
        @{ Name = 'แชท'; Pat = $ChatName; Where = 'bottom' },
        @{ Name = 'เพื่อน'; Pat = $FriendsName; Where = 'top' },
        @{ Name = 'บัญชีทางการ'; Pat = $OaTabName; Where = 'top' },
        @{ Name = 'ค้นหาด้วยชื่อ'; Pat = $SearchByName; Where = 'top' })
    $r.homeDump = Save-UiDump 'findoa_home'
    for ($i = 0; $i -lt $steps.Count; $i++) {
        $st = $steps[$i]
        $done = $false
        for ($try = 1; $try -le 2 -and -not $done; $try++) {
            $nodes = Get-Ui
            $n = Find-StepNode $nodes $st.Pat $st.Where
            if (-not $n) {
                if ($i -eq 3 -and (Test-SearchInput $nodes)) { $r.path += "$($st.Name) (มีช่องพิมพ์อยู่แล้ว)"; $done = $true; break }
                Start-Sleep -Milliseconds 800
                continue
            }
            $sig0 = (@($nodes | Where-Object { $_.Text } | ForEach-Object { $_.Text }) -join '|')
            $c = Get-Center $n
            Invoke-Tap $c[0] $c[1]
            $r.x = $c[0]; $r.y = $c[1]
            # wait for the next target (or the input field after the last step)
            $deadline = (Get-Date).AddSeconds(5)
            do {
                Start-Sleep -Milliseconds 450
                $n2 = Get-Ui
                if ($i -eq $steps.Count - 1) { if (Test-SearchInput $n2) { $done = $true } }
                elseif ($i -eq 2) { $done = $true; Start-Sleep -Milliseconds 400 }   # tab switch: the search box was already there
                elseif ((Find-StepNode $n2 $steps[$i + 1].Pat $steps[$i + 1].Where) -and ((@($n2 | Where-Object { $_.Text } | ForEach-Object { $_.Text }) -join '|') -ne $sig0)) { $done = $true }
            } while (-not $done -and (Get-Date) -lt $deadline)
            $r.path += "$($st.Name)$(if ($done) { ' ✔' } else { " ✖(กด $try)" })"
        }
        if (-not $done -and -not @($r.path | Where-Object { $_ -like "$($st.Name)*" }).Count) { $r.path += "$($st.Name) ✖(ไม่เจอปุ่ม)" }
        if (-not $done) { $r.error = "Could not open: $($st.Name)"; $r.failStep = $st.Name; $r.dump = Save-UiDump 'findoa_path'; return $r }
    }
    $r.ok = Test-SearchInput (Get-Ui)
    if (-not $r.ok) { $r.error = 'Search input did not appear'; $r.dump = Save-UiDump 'findoa_nosearch' }
    return $r
}
function Get-ScreenSize {
    if ($script:ScreenW -gt 0 -and $script:ScreenH -gt 0) { return @($script:ScreenW, $script:ScreenH) }
    $o = Invoke-Adb @('shell', 'wm size')
    $m = [regex]::Matches([string]$o, '(\d{3,5})x(\d{3,5})')
    if ($m.Count) { $l = $m[$m.Count - 1]; return @([int]$l.Groups[1].Value, [int]$l.Groups[2].Value) }
    return @(0, 0)
}
function Test-KeyboardShown {
    $o = [string](Invoke-Adb @('shell', 'dumpsys input_method | grep -E "mInputShown|mIsInputViewShown"'))
    return ($o -match '(mInputShown|mIsInputViewShown)=true')
}
# no screen structure (uiautomator gives nothing on the home screen): find the light-gray search bar in a screenshot and tap its left part
function Open-HomeSearchPx {
    $r = [ordered]@{ ok = $false; tapped = 'pixel'; x = 0; y = 0 }
    $shot = Get-ShotPx
    if (-not $shot) { $r.error = 'screenshot failed'; return $r }
    $sz = Get-ScreenSize
    $sx = if ($sz[0] -gt 0) { $sz[0] / $shot.Width } else { 1.0 }
    $sy = if ($sz[1] -gt 0) { $sz[1] / $shot.Height } else { 1.0 }
    $H = $shot.Height; $W = $shot.Width
    $bar = $shot.FindGrayBar([int]($H * 0.06), [int]($H * 0.55), [int]($W * 0.55), [Math]::Max(3, [int]($H * 0.022)), [int]($H * 0.10))
    if (-not $bar -or $bar.Count -lt 4) { $r.error = 'no gray search bar in the screenshot'; return $r }
    $r.bar = "$($bar[0]),$($bar[2])-$($bar[1]),$($bar[3])"
    $x = [int](($bar[0] + ($bar[1] - $bar[0]) * 0.3) * $sx); $y = [int]((($bar[2] + $bar[3]) / 2) * $sy)
    $r.x = $x; $r.y = $y
    Invoke-Tap $x $y
    $deadline = (Get-Date).AddSeconds(4)
    do {
        Start-Sleep -Milliseconds 500
        if (Test-KeyboardShown) { $r.ok = $true; $r.how = 'keyboard'; break }
        $n2 = Get-Ui
        if (@($n2 | Where-Object { $_.Class -match 'EditText' -and (Test-Visible $_) -and ($_.Focused -or -not (Find-Node $n2 $AddName $AddId)) }).Count) { $r.ok = $true; $r.how = 'field'; break }
    } while ((Get-Date) -lt $deadline)
    return $r
}
# type into whatever field has focus, without reading the screen (ADBKeyboard)
function Invoke-BlindType([string]$Value) {
    if (-not (Enable-AdbKeyboard)) {
        if ($Value -notmatch '[^\x20-\x7E]') { [void](Invoke-Adb @('shell', "input text $(ConvertTo-AdbText $Value)")); return [ordered]@{ found = $true; text = $Value; method = 'adb-blind' } }
        return [ordered]@{ found = $false; text = $Value; error = "No way to type Thai/emoji: $($script:KbNote)" }
    }
    $b64 = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($Value))
    [void](Invoke-Adb @('shell', 'am broadcast -a ADB_CLEAR_TEXT'))
    Start-Sleep -Milliseconds 150
    [void](Invoke-Adb @('shell', "am broadcast -a ADB_INPUT_B64 --es msg $b64"))
    Start-Sleep -Milliseconds 700
    return [ordered]@{ found = $true; text = $Value; method = 'adbkeyboard-blind' }
}
function Invoke-FindOa([string[]]$names) {
    $res = [ordered]@{ home = $false; items = @(); opens = @() }
    $res.home = [bool](Invoke-GoHome)
    $script:HomeSearchOpen = $false
    foreach ($nm in $names) {
        $e = [ordered]@{ name = $nm; typed = $false; found = $false; exact = $false; matches = @(); error = '' }
        Write-Prog 'search' $nm
        if (-not $script:HomeSearchOpen) {
            # 1) the search box on the home screen (screen structure)  2) same box found in a screenshot  3) แชท > เพื่อน > บัญชีทางการ > ค้นหาด้วยชื่อ
            $hs = Open-HomeSearch
            $res.opens += $hs
            $script:FindMethod = 'home'
            if (-not $hs.ok) {
                [void](Invoke-GoHome)
                $hs = Open-HomeSearchPx
                $res.opens += $hs
                $script:FindMethod = 'px'
            }
            if (-not $hs.ok) {
                [void](Invoke-GoHome)
                $hs = Open-OaSearch
                $res.opens += $hs
                $script:FindMethod = 'oa'
            }
            $e.open = $hs
            if (-not $hs.ok) {
                $e.error = 'Search box not found on the home screen'; if ($hs.dump) { $e.dump = $hs.dump }
                Write-Prog 'none' $nm; $res.items += $e
                [void](Invoke-GoHome); continue
            }
            $script:HomeSearchOpen = $true
        }
        $ty = Invoke-TypeAny $nm
        if (-not $ty.found -and $script:FindMethod -eq 'px') { $ty = Invoke-BlindType $nm }   # field is open but the screen cannot be read
        $e.typed = [bool]$ty.found
        $e.typeMethod = $ty.method
        if (-not $ty.found) {
            $e.error = $(if ($ty.error -match 'Search field not found') { 'Search box not found on the home screen' } else { [string]$ty.error })
            if ($ty.dump) { $e.dump = $ty.dump }
            Write-Prog 'none' $nm
            $res.items += $e
            # maybe we left the home screen: go back once before the next name
            [void](Invoke-GoHome); $script:HomeSearchOpen = $false
            continue
        }
        # results appear while typing; if nothing shows, press Enter once
        $m = @(); $prev = ''; $entered = $false
        $deadline = (Get-Date).AddSeconds(7)
        $t0 = Get-Date
        do {
            Start-Sleep -Milliseconds 500
            $m = Get-FindMatches (Get-Ui) $nm
            $sig = (@($m | ForEach-Object { "$($_.name)@$($_.section)" }) -join '|')
            if ($m.Count -and $sig -eq $prev) { break }
            $prev = $sig
            if (-not $m.Count -and -not $entered -and ((Get-Date) - $t0).TotalSeconds -ge 2.5) { [void](Invoke-Adb @('shell', 'input keyevent 66')); $entered = $true }
        } while ((Get-Date) -lt $deadline)
        $e.matches = @($m)
        $e.found = ($m.Count -gt 0)
        $e.exact = [bool](@($m | Where-Object { $_.exact }).Count)
        if ($e.found) { Write-Prog 'found' $nm (@($m | ForEach-Object { $_.name })) }
        else { Write-Prog 'none' $nm; $e.dump = Save-UiDump 'findoa_none' }
        $res.items += $e
    }
    $res.uiFails = [int]$script:UiFailTotal
    $res.clear = Invoke-ClearSearchX
    Restore-Ime
    [void](Invoke-GoHome)
    return $res
}
# ---------- members list -> "แก้ไข" -> search each name -> "ลบ" -> "ตกลง" ----------
function Get-NameCount($nodes, [string]$name) {
    $edit = @($nodes | Where-Object { $_.Class -match 'EditText' -and (Test-Visible $_) } | Select-Object -First 1)
    $minY = if ($edit.Count) { $edit[0].Y2 } else { 0 }
    $W = [Math]::Max(300, $script:ScreenW)
    $want = $name.Trim()
    return @($nodes | Where-Object {
            $lab = if ($_.Text) { $_.Text.Trim() } else { ([string]$_.Desc).Trim() }
            $_.Class -notmatch 'EditText' -and (Test-Visible $_) -and $lab -eq $want -and $_.Y1 -ge $minY -and ($_.X2 - $_.X1) -lt ($W * 0.9)
        }).Count
}
# find the member line with this name (exact first; a partial match only when it is the only one)
function Find-MemberLabel($nodes, [string]$name) {
    $edit = @($nodes | Where-Object { $_.Class -match 'EditText' -and (Test-Visible $_) } | Select-Object -First 1)
    $minY = if ($edit.Count) { $edit[0].Y2 } else { [int]([Math]::Max(500, $script:ScreenH) * 0.12) }
    $W = [Math]::Max(300, $script:ScreenW)
    $want = $name.Trim()
    $labs = @($nodes | Where-Object { $_.Class -notmatch 'EditText' -and (Test-Visible $_) -and ($_.Text -or $_.Desc) -and $_.Y1 -ge $minY -and ($_.X2 - $_.X1) -lt ($W * 0.9) } |
        ForEach-Object { [pscustomobject]@{ T = $(if ($_.Text) { $_.Text.Trim() } else { $_.Desc.Trim() }); N = $_ } })
    $ex = @($labs | Where-Object { $_.T -eq $want } | Sort-Object { $_.N.Y1 })
    if ($ex.Count) { return @{ Node = $ex[0].N; Exact = $true; Count = $ex.Count } }
    $pa = @($labs | Where-Object { $_.T.Length -ge 2 -and $want.Length -ge 2 -and ($_.T.Contains($want) -or $want.Contains($_.T.TrimEnd('…', '.', ' '))) -and $_.T -notmatch $RemoveName -and $_.T -notmatch $EditName })
    if ($pa.Count -eq 1) { return @{ Node = $pa[0].N; Exact = $false; Count = 1 } }
    return $null
}
# the "ลบ" button on the same line as the name (text / id / right-most button of that line)
function Find-RemoveButton($nodes, $label) {
    $W = [Math]::Max(300, $script:ScreenW); $H = [Math]::Max(500, $script:ScreenH)
    $cont = @($nodes | Where-Object { $_.X1 -le $label.X1 -and $_.Y1 -le $label.Y1 -and $_.X2 -ge $label.X2 -and $_.Y2 -ge $label.Y2 -and ($_.X2 - $_.X1) -ge ($W * 0.6) -and ($_.Y2 - $_.Y1) -le ($H * 0.2) } |
        Sort-Object { ($_.X2 - $_.X1) * ($_.Y2 - $_.Y1) } | Select-Object -First 1)
    $y1 = if ($cont.Count) { $cont[0].Y1 } else { $label.Y1 - 25 }
    $y2 = if ($cont.Count) { $cont[0].Y2 } else { $label.Y2 + 25 }
    $line = @($nodes | Where-Object { (Test-Visible $_) -and $_ -ne $label -and ((($_.Y1 + $_.Y2) / 2) -ge $y1) -and ((($_.Y1 + $_.Y2) / 2) -le $y2) -and $_.X1 -ge ($label.X1 + 5) })
    $b = @($line | Where-Object { $_.Text -match $RemoveName -or $_.Desc -match $RemoveName -or $_.Id -match '(?i)(remove|delete|kick|ban|minus)' } | Sort-Object X2 -Descending | Select-Object -First 1)
    if ($b.Count) { return $b[0] }
    $b = @($line | Where-Object { $_.Click -and $_.X1 -ge ($W * 0.55) -and ($_.X2 - $_.X1) -lt ($W * 0.4) } | Sort-Object X2 -Descending | Select-Object -First 1)
    if ($b.Count) { return $b[0] }
    $b = @($line | Where-Object { $_.Class -match '(Button|Image)' -and $_.X1 -ge ($W * 0.6) } | Sort-Object X2 -Descending | Select-Object -First 1)
    if ($b.Count) { return $b[0] }
    return $null
}
# members list -> "แก้ไข" -> search each name -> "ลบ" -> "ตกลง"
function Invoke-RemoveMembers([string[]]$names) {
    $res = [ordered]@{ edit = $false; items = @() }
    $W = [Math]::Max(300, $script:ScreenW); $H = [Math]::Max(500, $script:ScreenH)
    $ed = $null
    for ($k = 0; $k -lt 6 -and -not $ed; $k++) {
        $nodes = Get-Ui
        $ed = Find-Node @($nodes | Where-Object { $_.Y2 -le ($H * 0.15) }) $EditName '(?i)(edit)'
        if (-not $ed) { Start-Sleep -Milliseconds 400 }
    }
    if (-not $ed) { $res.dump = Save-UiDump 'members_noedit'; return $res }
    $c = Get-Center $ed
    Invoke-Tap $c[0] $c[1]
    Start-Sleep -Milliseconds 800
    $res.edit = $true
    foreach ($nm in $names) {
        $e = [ordered]@{ name = $nm; typed = $false; found = $false; removed = 0; error = '' }
        $ty = Invoke-TypeAny $nm
        $e.typed = [bool]$ty.found
        if (-not $ty.found) { $e.typeError = $ty.error }   # no search box: look through the list instead
        for ($round = 0; $round -lt 5; $round++) {
            $hit = $null
            $deadline = (Get-Date).AddSeconds($(if ($round -eq 0) { 5 } else { 3 }))
            $pages = 0; $lastSig = ''
            do {
                Start-Sleep -Milliseconds 400
                $nodes = Get-Ui
                $hit = Find-MemberLabel $nodes $nm
                if (-not $hit -and -not $e.typed -and $pages -lt 15) {
                    # scroll the member list
                    $sig = (@($nodes | Where-Object { $_.Text } | ForEach-Object { "$($_.Text)@$($_.Y1)" }) -join '|')
                    if ($sig -eq $lastSig) { break }
                    $lastSig = $sig; $pages++
                    [void](Invoke-Adb @('shell', "input swipe $([int]($W/2)) $([int]($H*0.80)) $([int]($W/2)) $([int]($H*0.35)) 600"))
                    $deadline = (Get-Date).AddSeconds(3)
                }
            } while (-not $hit -and (Get-Date) -lt $deadline)
            if (-not $hit) { break }
            $e.found = $true
            $e.matched = if ($hit.Node.Text) { $hit.Node.Text } else { $hit.Node.Desc }
            $btn = Find-RemoveButton $nodes $hit.Node
            if (-not $btn) { $e.error = 'Remove button not found next to the name'; $e.dump = Save-UiDump 'members_nobtn'; break }
            $beforeBtns = @($nodes | Where-Object { $_.Click -or $_.Class -match 'Button' })
            $beforeCount = [int]$hit.Count
            $c = Get-Center $btn
            Invoke-Tap $c[0] $c[1]
            # confirm dialog: "ตกลง" / "ลบ" (a new button that was not on screen before)
            $ok = $null
            $deadline = (Get-Date).AddSeconds(5)
            do {
                Start-Sleep -Milliseconds 350
                $nodes2 = Get-Ui
                $dlgB = @($nodes2 | Where-Object {
                        $nb = $_
                        ($nb.Id -match '(?i)(button1|positive|confirm|ok)' -or $nb.Class -match 'Button' -or $nb.Click) -and
                        -not @($beforeBtns | Where-Object { Test-SameSpot $_ $nb }).Count
                    })
                $ok = Find-Node $dlgB $RemoveOkName '(?i)(button1|positive)'
                # no dialog at all and the name is already gone -> removed directly
                if (-not $ok) { $nowHit = Find-MemberLabel $nodes2 $nm; if (-not $nowHit -or [int]$nowHit.Count -lt $beforeCount) { break } }
            } while (-not $ok -and (Get-Date) -lt $deadline)
            if ($ok) {
                $c = Get-Center $ok
                Invoke-Tap $c[0] $c[1]
                Start-Sleep -Milliseconds 900
            }
            # verify: one fewer line with this name
            $afterHit = Find-MemberLabel (Get-Ui) $nm
            $afterCount = if ($afterHit) { [int]$afterHit.Count } else { 0 }
            if ($afterCount -ge $beforeCount) { Start-Sleep -Milliseconds 900; $afterHit = Find-MemberLabel (Get-Ui) $nm; $afterCount = if ($afterHit) { [int]$afterHit.Count } else { 0 } }
            if ($afterCount -ge $beforeCount) { $e.error = $(if ($ok) { 'Still in the list after removing' } else { 'Confirm dialog did not appear' }); $e.dump = Save-UiDump 'members_notremoved'; break }
            $e.removed++
        }
        if (-not $e.found -and -not $e.error) { $e.error = 'Not a member of this group'; if (-not $e.typed) { $e.error += " (search box: $($e.typeError))" } }
        $res.items += $e
    }
    $edit = Get-EditNodeQuick
    if ($edit -and -not $NoTap) { Clear-EditField $edit }
    return $res
}
# step 1-2: every group with more than MinMembers members -> แชท -> ≡ -> สมาชิก -> แก้ไข -> remove the broken OA(s)
function Invoke-ReplaceOaRemove([string[]]$names) {
    $rep = [ordered]@{ scanned = $false; groups = @(); skipped = @() }
    $sg = Invoke-ScanGroups
    $rep.scanned = [bool]$sg.groupsOpened
    $rep.allGroups = @($sg.groups)
    foreach ($g in @($sg.groups)) {
        if ($null -eq $g.members -or "$($g.members)" -eq '') { $rep.skipped += [ordered]@{ name = $g.name; why = 'member count unknown' }; continue }
        if ([int]$g.members -le $MinMembers) { continue }
        $gr = [ordered]@{ name = [string]$g.name; members = [int]$g.members; opened = $false; edit = $false; removed = 0; items = @(); invite = $null; invited = @() }
        $o = Invoke-InviteToGroup ([string]$g.name) 'members'
        $gr.opened = [bool]$o.opened
        if (-not $o.opened) { $gr.error = $(if ($o.wantedMissing) { 'group not found' } elseif ($o.enterFailed) { 'tapped the group but it did not open' } elseif (-not $o.chat) { 'chat not opened' } elseif (-not $o.menu) { 'menu (≡) not found' } else { 'members not opened' }); $rep.groups += $gr; continue }
        $rm = Invoke-RemoveMembers $names
        $gr.edit = [bool]$rm.edit
        $gr.items = @($rm.items)
        $gr.removed = [int](@($rm.items | ForEach-Object { [int]$_.removed }) | Measure-Object -Sum).Sum
        $gr.hadOa = [bool](@($rm.items | Where-Object { $_.found }).Count)
        if ($rm.dump) { $gr.dump = $rm.dump }
        if (-not $rm.edit) { $gr.error = 'edit (แก้ไข) not found' }
        $rep.groups += $gr
    }
    Restore-Ime
    [void](Invoke-GoHome)
    return $rep
}

# ---------- Make sure we are on the search page with the input field before each ID ----------
function Confirm-SearchPage([string]$TabPattern) {
    for ($k = 0; $k -lt 5; $k++) {
        $nodes = Get-Ui
        if (@($nodes | Where-Object { $_.Class -match 'EditText' -and (Test-Visible $_) }).Count) { return $true }
        # on the LINE home screen: go through the add-friend button first (home has its own search bar)
        $a = Find-Node $nodes $AddName $AddId
        if ($a -and $a.Click) {
            $c = Get-Center $a; Invoke-Tap $c[0] $c[1]
            [void](Wait-StableNode $SearchName $SearchId 6)
            continue
        }
        # on the add-friend page: open search, then the ID / phone tab
        $s = Find-Node $nodes $SearchName $SearchId
        if ($s -and $s.Class -notmatch 'EditText') {
            $c = Get-Center $s; Invoke-Tap $c[0] $c[1]
            $tab = Wait-StableNode $TabPattern '(?!)' 3
            if ($tab) { $c = Get-Center $tab; Invoke-Tap $c[0] $c[1] }
            continue
        }
        # somewhere else (profile / chat): go back one screen
        if (-not $NoTap) { [void](Invoke-Adb @('shell', 'input keyevent 4')) }
        Start-Sleep -Milliseconds 900
    }
    return $false
}

try {
    # ---------- Load config ----------
    $list = @()
    if ($Texts) { $list += $Texts }
    if ($Text)  { $list += $Text }
    if ((-not $list -or -not $SearchBy) -and (Test-Path $ConfigPath)) {
        $cfg = Get-Content $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if (-not $list) {
            if ($cfg.texts) { $list += @($cfg.texts) }
            if ($cfg.text)  { $list += [string]$cfg.text }
        }
        if (-not $SearchBy -and $cfg.searchBy) { $SearchBy = [string]$cfg.searchBy }
    }
    if (-not $SearchBy) { $SearchBy = 'ID' }

    # remove blanks and duplicates (case-insensitive), keep order
    $seen = @{}
    $list = @($list | ForEach-Object { "$_".Trim() } | Where-Object {
        $_ -and -not $seen.ContainsKey($_.ToLower()) -and ($seen[$_.ToLower()] = $true)
    })

    # ---------- Check device ----------
    if (-not $Serial) {
        $dev = (Invoke-Adb @('devices')) -split "`r?`n" | Where-Object { $_ -match '^\S+\s+device$' } | Select-Object -First 1
        if (-not $dev) { Out-Result @{ ok = $false; error = 'No ADB device found (is LDPlayer open with ADB enabled?)' } 2 }
        $Serial = ($dev -split '\s+')[0]
    }
    $script:SafeSerial = ($Serial -replace '[^\w\-\.]', '_')

    # ---------- Name only: look at the screen as it is (never open / close LINE, never tap) ----------
    if ($NameOnly) {
        $focus = Invoke-Adb @('shell', 'dumpsys window | grep -E "mCurrentFocus"')
        if ($focus -notmatch [regex]::Escape($Package)) { Out-Result @{ ok = $false; serial = $Serial; reason = 'notline'; error = 'LINE is not on screen' } 1 }
        Read-OwnName (Get-Ui)
        if ($script:OwnName) { Out-Result @{ ok = $true; serial = $Serial } 0 }
        Out-Result @{ ok = $false; serial = $Serial; reason = 'nothome'; error = 'Not on the LINE home screen (or the name is not visible)' } 1
    }

    # ---------- Make sure LINE is in front and ready ----------
    $focus = Invoke-Adb @('shell', 'dumpsys window | grep -E "mCurrentFocus|mFocusedApp"')
    if ($focus -notmatch [regex]::Escape($Package)) {
        if (-not $LaunchLine) { Out-Result @{ ok = $false; serial = $Serial; error = 'LINE is not on screen (add -LaunchLine to open it)' } 1 }
        [void](Invoke-Adb @('shell', "monkey -p $Package -c android.intent.category.LAUNCHER 1"))
        $deadline = (Get-Date).AddSeconds(20)
        do {
            Start-Sleep -Milliseconds 700
            $focus = Invoke-Adb @('shell', 'dumpsys window | grep -E "mCurrentFocus"')
        } while ($focus -notmatch [regex]::Escape($Package) -and (Get-Date) -lt $deadline)
        if ($focus -notmatch [regex]::Escape($Package)) { Out-Result @{ ok = $false; serial = $Serial; error = 'LINE did not open within 20 seconds' } 1 }
        Start-Sleep -Milliseconds 1500   # let the home screen finish loading
    }
    # read our own LINE name right away (one screen read; if this is not the home screen it is read when we get there)
    if ($NameFile -or $NameOnly) { Read-OwnName (Get-Ui) }

    $steps = @()

    $script:PreTickTerms = @()
    $script:PreTickExact = @()
    $script:ExcludeTerms = @()
    if ($ExcludeB64) { $script:ExcludeTerms = @(([System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($ExcludeB64)) | ConvertFrom-Json) | ForEach-Object { (([string]$_) -replace '\s+', ' ').Trim().ToLowerInvariant() } | Where-Object { $_ }) }
    if ($PreTickB64) { $script:PreTickTerms = @(([System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($PreTickB64)) | ConvertFrom-Json) | ForEach-Object { ([string]$_).Trim() } | Where-Object { $_ }) }
    $joinGroup = if ($JoinGroupB64) { [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($JoinGroupB64)) } else { '' }
    $inviteNames = @()
    if ($InviteNamesB64) { $inviteNames = @(([System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($InviteNamesB64)) | ConvertFrom-Json) | ForEach-Object { [string]$_ } | Where-Object { $_.Trim() }) }
    if ($FindOaB64) {
        $foNames = @(([System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($FindOaB64)) | ConvertFrom-Json) | ForEach-Object { ([string]$_).Trim() } | Where-Object { $_ })
        $fo = Invoke-FindOa $foNames
        $okF = -not @($fo.items | Where-Object { -not $_.typed }).Count
        Out-Result @{ ok = $okF; serial = $Serial; steps = @(); rounds = @(); findOa = $fo } ([int](-not $okF))
    }
    if ($GroupOnly -and $joinGroup) {
        # chosen group -> แชท -> ≡ -> เชิญ -> search each name -> tick
        $grp = Invoke-InviteToGroup $joinGroup
        $byName = @()
        # "ค้นหาชื่อก่อนติ๊กวงกลม" names first (1 per name), then the scanned names
        if ($grp.opened -and $script:PreTickTerms.Count) { $grp.preTick = Invoke-PreTickByTerms $script:PreTickTerms }
        if ($grp.opened -and $inviteNames.Count) { $byName = Invoke-InviteByNames $inviteNames }
        $okAll = [bool]$grp.opened -and $inviteNames.Count -gt 0 -and -not @($byName | Where-Object { -not $_.ticked }).Count
        Out-Result @{ ok = $okAll; serial = $Serial; steps = @(); rounds = @(); createGroup = $grp; inviteNames = @($byName) } ([int](-not $okAll))
    }
    if ($GroupOnly -and $ScanGroups) {
        $sg = Invoke-ScanGroups
        Out-Result @{ ok = ($sg.groups.Count -gt 0); serial = $Serial; steps = @(); rounds = @(); groupList = $sg } 0
    }
    if ($GroupOnly) {
        $grp = Invoke-GroupStep
        Out-Result @{ ok = [bool]$grp.opened; serial = $Serial; steps = @(); rounds = @(); createGroup = $grp } ([int](-not $grp.opened))
    }

    $replaceNames = @()
    if ($ReplaceOaB64) { $replaceNames = @(([System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($ReplaceOaB64)) | ConvertFrom-Json) | ForEach-Object { ([string]$_).Trim() } | Where-Object { $_ }) }
    $replace = $null
    if ($replaceNames.Count) { $replace = Invoke-ReplaceOaRemove $replaceNames }

    # Step 1: add friend  (verified by the search entry appearing)
    $r1 = Invoke-TapStep 'addfriend' $AddName $AddId $AddTemplate $SearchName $SearchId 15
    $steps += $r1
    if (-not $r1.found) { Out-Result @{ ok = $false; serial = $Serial; steps = $steps; error = 'Add friend button not found' } 1 }

    # Step 2: search  (verified by the input field / ID tab appearing)
    $r2 = Invoke-TapStep 'search' $SearchName $SearchId $SearchTemplate '(?i)^\s*(ID|phone\s*number|หมายเลขโทรศัพท์|เบอร์โทรศัพท์|電話番号|전화번호)\s*$' '(?i)(edit|input|search_?text|query)'
    $steps += $r2
    if (-not $r2.found) { Out-Result @{ ok = $false; serial = $Serial; steps = $steps; error = 'Search button not found' } 1 }

    if (-not $list) { Out-Result @{ ok = $true; serial = $Serial; steps = $steps; note = 'No text set, stopped at the search page' } 0 }

    # Step 3: choose ID / phone number (once; if no tab is found, continue)
    $tabPattern = if ($SearchBy -eq 'Phone') { $PhoneTabName } else { $IdTabName }
    $tabNode = Wait-StableNode $tabPattern '(?!)' 3
    if ($tabNode) {
        $c = Get-Center $tabNode
        Invoke-Tap $c[0] $c[1]
        $steps += [ordered]@{ step = 'searchby'; found = $true; method = 'uiautomator'; x = $c[0]; y = $c[1] }
    } else {
        $steps += [ordered]@{ step = 'searchby'; found = $false }
    }

    # Steps 4-6: one round per entry
    $rounds = @()
    $round  = 0
    foreach ($t in $list) {
        $round++
        $rs = @()

        # make sure the search page is open (LINE may have moved to a profile after the last add)
        if (-not $NoTap -and -not (Confirm-SearchPage $tabPattern)) {
            $rounds += [ordered]@{ round = $round; text = $t; ok = $false; steps = $rs; error = 'Could not return to the search page' }
            continue
        }

        # type and verify
        $r4 = Invoke-TypeStep $t
        $rs += $r4
        if (-not $r4.found) { $rounds += [ordered]@{ round = $round; text = $t; ok = $false; steps = $rs; error = $r4.error }; continue }

        # search (Enter) and wait for a NEW, clear result; if nothing happens, tap the search icon once
        $beforeSig = Get-ResultSig (Get-Ui)
        if (-not $NoTap) { [void](Invoke-Adb @('shell', 'input keyevent 66')) }
        Start-Sleep -Milliseconds $StepDelayMs
        $res = Wait-SearchResult $beforeSig
        if ($res.Kind -eq 'timeout') {
            $icon = Find-Node (Get-Ui) $SearchName '(?!)'
            if ($icon) { $c = Get-Center $icon; Invoke-Tap $c[0] $c[1]; $rs += [ordered]@{ step = 'submit_icon'; found = $true; x = $c[0]; y = $c[1] } }
            $res = Wait-SearchResult $beforeSig
        }

        $item = [ordered]@{ round = $round; text = $t; ok = $false; steps = $rs }
        $nameNodes = Get-Ui
        $anchor = if ($res.Kind -eq 'add') { $res.Node } else { @($nameNodes | Where-Object { $_.Class -notmatch 'EditText' -and (Test-Visible $_) -and ($_.Text -match $AddedText -or $_.Desc -match $AddedText) } | Select-Object -First 1) | Select-Object -First 1 }
        if ($res.Kind -in 'add', 'already') { $item.name = Get-ResultName $nameNodes $anchor $t }
        $item.status = switch ($res.Kind) { 'add' { 'found' } 'already' { 'friend' } 'notfound' { 'notfound' } default { 'timeout' } }
        if ($CheckOnly) {
            # check only: never add, just record what this ID is
            $item.ok = ($res.Kind -in 'add', 'already')
            $item.note = switch ($res.Kind) { 'add' { 'Found (not added, check only)' } 'already' { 'Already a friend' } 'notfound' { 'User not found' } default { 'No search result (timeout)' } }
            if (-not $item.ok) { $item.error = $item.note }
            $rs += [ordered]@{ step = 'check'; found = [bool]$item.ok; kind = $res.Kind }
            $item.steps = $rs
            $rounds += $item
            continue
        }
        switch ($res.Kind) {
            'add' {
                $c = Get-Center $res.Node
                Invoke-Tap $c[0] $c[1]
                $added = if ($NoTap) { $true } else { Test-Added $res.Node }
                if (-not $added) {
                    # one more careful try
                    $again = Find-AddButton (Get-Ui)
                    if ($again) { $c2 = Get-Center $again; Invoke-Tap $c2[0] $c2[1]; $added = Test-Added $again }
                }
                $rs += [ordered]@{ step = 'add'; found = $true; method = 'uiautomator'; x = $c[0]; y = $c[1]; verified = [bool]$added }
                $item.ok = [bool]$added
                $item.status = if ($added) { 'added' } else { 'found' }
                if (-not $added) { $item.error = 'Tapped add but it did not take effect' }
            }
            'already' {
                $rs += [ordered]@{ step = 'add'; found = $false; note = 'already a friend' }
                $item.ok = $true
                $item.note = 'Already a friend'
            }
            'notfound' {
                $rs += [ordered]@{ step = 'add'; found = $false }
                $item.error = 'User not found'
            }
            default {
                # last resort: image of the add button
                $hit = Find-ByImage $AddBtnTemplate
                if ($hit) {
                    Invoke-Tap $hit.X $hit.Y
                    $rs += [ordered]@{ step = 'add'; found = $true; method = 'image'; x = $hit.X; y = $hit.Y; score = $hit.Score }
                    $item.ok = $true
                } else {
                    $rs += [ordered]@{ step = 'add'; found = $false }
                    $item.error = 'No search result appeared (timeout)'
                }
            }
        }
        Start-Sleep -Milliseconds $StepDelayMs
        # back to the LINE home screen after each ID
        if ($GoHomeEachId) {
            $wentHome = Invoke-GoHome
            $rs += [ordered]@{ step = 'home'; found = [bool]$wentHome }
        }
        $item.steps = $rs
        $rounds += $item
    }

    $allOk = -not ($rounds | Where-Object { -not $_.ok })
    $grp = $null
    $sg = $null
    $byName = $null
    if ($CheckOnly) {
        Out-Result @{ ok = $true; serial = $Serial; steps = $steps; rounds = $rounds; checkOnly = $true } 0
    }
    if ($replace) {
        # step 4: the groups we just removed the broken OA from -> แชท -> ≡ -> เชิญ -> the new OA's name
        $newNames = @()
        foreach ($rd in $rounds) { $nm = ([string]$rd.name).Trim(); if ($rd.ok -and $nm -and $newNames -notcontains $nm) { $newNames += $nm } }
        $replace.newNames = $newNames
        if ($newNames.Count) {
            foreach ($gr in @($replace.groups | Where-Object { $_.removed -gt 0 -or $_.hadOa })) {
                $g2 = $null
                for ($try = 1; $try -le 2; $try++) {
                    $wentHome = Invoke-GoHome
                    $g2 = Invoke-InviteToGroup ([string]$gr.name) 'invite' -FromHome
                    $g2.try = $try
                    $g2.failStep = if ($g2.opened) { '' } elseif (-not $wentHome) { 'home' } elseif (-not $g2.groupsOpened) { 'groups' } elseif ($g2.wantedMissing -or -not $g2.groupFound) { 'group' } elseif ($g2.enterFailed) { 'enter' } elseif (-not $g2.chat) { 'chat' } elseif (-not $g2.menu) { 'menu' } elseif (-not $g2.inviteFound) { 'invite' } else { 'inviteScreen' }
                    if ($g2.opened) { break }
                    $g2.dump = Save-UiDump "invite_fail_$($g2.failStep)"
                }
                $gr.invite = $g2
                if ($g2.opened) { $gr.invited = Invoke-InviteByNames $newNames }
                [void](Invoke-GoHome)
            }
        }
        $okR = [bool]$allOk -and $newNames.Count -gt 0
        Out-Result @{ ok = $okR; serial = $Serial; steps = $steps; rounds = $rounds; replace = $replace } ([int](-not $okR))
    }
    if ($joinGroup) {
        # group chosen before the run: go straight in and invite the scanned names (one run, no waiting)
        Start-Sleep -Milliseconds $StepDelayMs
        $scanned = @()
        foreach ($rd in $rounds) { $nm = ([string]$rd.name).Trim(); if ($rd.ok -and $nm -and $scanned -notcontains $nm) { $scanned += $nm } }
        if ($scanned.Count) {
            $grp = Invoke-InviteToGroup $joinGroup
            if ($grp.opened -and $script:PreTickTerms.Count) { $grp.preTick = Invoke-PreTickByTerms $script:PreTickTerms }
            if ($grp.opened) { $byName = Invoke-InviteByNames $scanned }
            elseif ($grp.wantedMissing) { $sg = Invoke-ScanGroups }   # chosen group is gone / renamed: list the groups so the user can choose again
        }
    } elseif ($ScanGroups) {
        Start-Sleep -Milliseconds $StepDelayMs
        $sg = Invoke-ScanGroups
    } elseif ($CreateGroup) {
        Start-Sleep -Milliseconds $StepDelayMs
        if ($CreateWithNames) {
            # สร้างกลุ่ม -> ค้นหาด้วยชื่อที่สแกนจาก ID ทุกตัว -> ติ๊ก -> ลบช่องค้นหา -> (ติ๊กวงกลมต่อ)
            $scanned = @()
            foreach ($rd in $rounds) { $nm = ([string]$rd.name).Trim(); if ($rd.ok -and $nm -and $scanned -notcontains $nm) { $scanned += $nm } }
            $script:PreTickExact = @($scanned)
            $script:PreTickTerms = @($scanned) + @($script:PreTickTerms | Where-Object { $scanned -notcontains $_ })
        }
        $grp = Invoke-GroupStep
    }
    Out-Result @{ ok = [bool]$allOk; serial = $Serial; steps = $steps; rounds = $rounds; createGroup = $grp; groupList = $sg; inviteNames = $byName } ([int](-not $allOk))
}
catch {
    $where = (([string]$_.ScriptStackTrace) -split "`r?`n" | Select-Object -First 1)
    Out-Result @{ ok = $false; serial = $Serial; error = "$($_.Exception.Message) [$where]" } 2
}
