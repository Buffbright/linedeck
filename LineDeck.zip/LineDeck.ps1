﻿<#
================================================================
 LDPlayer9 ADB Auto Connector  (PowerShell + WinForms)
 - ค้นหา LDPlayer9 ทุกเครื่อง แล้วเชื่อม ADB ให้อัตโนมัติ
 - หลุด / รีบูต / เปิดเครื่องใหม่ -> ต่อให้เองทุกรอบเวลา
 - งาน adb ทั้งหมดรันใน background thread -> หน้าต่างไม่ค้าง
 - ใช้ adb.exe ของ LDPlayer เอง (ไม่ชนเวอร์ชันกับ LD)

 วิธีรัน : คลิกขวาไฟล์ > Run with PowerShell
 หรือ    : powershell -NoProfile -ExecutionPolicy Bypass -File .\LDAdbConnector.ps1
================================================================
#>

# ---------- รันแบบ Admin + STA เสมอ ----------
$__admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $__admin -or [System.Threading.Thread]::CurrentThread.GetApartmentState() -ne 'STA') {
    $__args = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-STA', '-WindowStyle', 'Hidden', '-File', "`"$PSCommandPath`"")
    try {
        if ($__admin) { Start-Process -FilePath 'powershell.exe' -ArgumentList $__args }
        else { Start-Process -FilePath 'powershell.exe' -ArgumentList $__args -Verb RunAs -ErrorAction Stop }
    } catch {}
    return
}

$script:SelfPath = $PSCommandPath
$script:IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
try { [System.Windows.Forms.Application]::EnableVisualStyles() } catch {}

# ---------- ซ่อนหน้าต่าง console ดำ ๆ ----------
try {
    Add-Type -Name ConWin -Namespace LdAdb -MemberDefinition @'
[DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow();
[DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
'@ -ErrorAction Stop
    $script:ConsoleHandle = [LdAdb.ConWin]::GetConsoleWindow()
    if ($script:ConsoleHandle -ne [IntPtr]::Zero) { [void][LdAdb.ConWin]::ShowWindow($script:ConsoleHandle, 0) }
} catch {}

# ---------- บันทึกไฟล์แบบปลอดภัย: เขียนไฟล์ชั่วคราวก่อนแล้วสลับ + เก็บสำรอง .bak (ไฟลไม่พังแม้ปิดกลางคัน) ----------
function Write-SafeText([string]$path, [string]$text) {
    $dir = Split-Path -Parent $path
    if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $tmp = "$path.tmp"
    [System.IO.File]::WriteAllText($tmp, $text, (New-Object System.Text.UTF8Encoding($false)))
    if (Test-Path -LiteralPath $path) {
        try { [System.IO.File]::Replace($tmp, $path, "$path.bak") }
        catch { Copy-Item -LiteralPath $path -Destination "$path.bak" -Force -ErrorAction SilentlyContinue; Move-Item -LiteralPath $tmp -Destination $path -Force }
    } else { Move-Item -LiteralPath $tmp -Destination $path -Force }
}
function Read-JsonSafe([string]$path) {
    foreach ($cand in @($path, "$path.bak")) {
        try {
            if (Test-Path -LiteralPath $cand) {
                $raw = [System.IO.File]::ReadAllText($cand, [System.Text.Encoding]::UTF8)
                if ($raw.Trim()) { $j = $raw | ConvertFrom-Json; if ($null -ne $j) { return $j } }
            }
        } catch {}
    }
    return $null
}

# ---------- ตั้งค่า (บันทึกไว้ใน %APPDATA%) ----------
$CfgDir  = Join-Path $env:APPDATA 'LDAdbConnector'
$CfgFile = Join-Path $CfgDir 'config.json'
$cfg = [pscustomobject]@{ LdDir = ''; Interval = 3; Auto = $true; LineInfo = @{}; SearchNext = @{}; SerialMap = @{}; SelectCount = 5; SelectAll = $true; UseIdCol = 0; MaxGroupMembers = 50; IdOnly = $false; IdCols = 2; AutoInfo = $true; LastSet = @{}; Today = @{ date = ''; data = @{} }; AfterIdMode = -1; Presets = @(); GroupCache = @{}; GroupPick = @{}; LastPreset = ''; LastJob = 'line'; ReplaceOaNames = ''; FindOaNames = ''; FindOaAuto = $false; FindOaAutoClose = $false; StartGap = 0; StartWaitDone = $false; ExcludeNames = ''; ReplaceMinMembers = 50; PreTickNames = ''; LdSort = 0; ShowSettings = $true; LayoutVer = 0; Checked = @(); UidDir = ''; WinX = -99999; WinY = -99999; WinW = 0; WinH = 0; Theme = 'dark'; UpdateUrl = ''; AutoUpdate = $false; LastSeenVersion = ''; Counters = @{ date = '' } }
$j = Read-JsonSafe $CfgFile
if ($null -ne $j) {
    try {
        if ($j.Checked) { $cfg.Checked = @($j.Checked | ForEach-Object { [int]$_ }) }
        if ($j.GroupCache) {
            foreach ($pr in $j.GroupCache.PSObject.Properties) {
                $cfg.GroupCache[$pr.Name] = @{ Time = [string]$pr.Value.Time; Groups = @($pr.Value.Groups | Where-Object { $_ -and $_.name } | ForEach-Object { @{ name = [string]$_.name; members = $_.members } }) }
            }
        }
        if ($j.LastSet) { foreach ($pr in $j.LastSet.PSObject.Properties) { $cfg.LastSet[$pr.Name] = [string]$pr.Value } }
        if ($j.Today -and $j.Today.date) {
            $cfg.Today = @{ date = [string]$j.Today.date; data = @{} }
            if ($j.Today.data) { foreach ($pr in $j.Today.data.PSObject.Properties) { $cfg.Today.data[$pr.Name] = @{ added = [int]$pr.Value.added; invite = [int]$pr.Value.invite; line = [int]$pr.Value.line; select = [int]$pr.Value.select } } }
        }
        if ($j.Counters) { foreach ($pr in $j.Counters.PSObject.Properties) { $cfg.Counters[$pr.Name] = $(if ($pr.Name -eq 'date') { [string]$pr.Value } else { [int]$pr.Value }) } }
        if ($j.GroupPick) { foreach ($pr in $j.GroupPick.PSObject.Properties) { $cfg.GroupPick[$pr.Name] = [string]$pr.Value } }
        if ($j.Presets) {
            # keep every saved field (ExcludeNames, StartGap, FindOaNames ... too)
            $cfg.Presets = @($j.Presets | Where-Object { $_ -and $_.Name } | ForEach-Object {
                    if ($null -eq $_.MinMembers) { $_ | Add-Member -NotePropertyName MinMembers -NotePropertyValue 50 -Force }
                    $_ })
        }
        foreach ($p in 'LdDir', 'Interval', 'Auto', 'SelectCount', 'SelectAll', 'UseIdCol', 'MaxGroupMembers', 'IdOnly', 'IdCols', 'AutoInfo', 'AfterIdMode', 'LastPreset', 'LastJob', 'ReplaceOaNames', 'FindOaNames', 'FindOaAuto', 'FindOaAutoClose', 'StartGap', 'StartWaitDone', 'ExcludeNames', 'ReplaceMinMembers', 'PreTickNames', 'LdSort', 'ShowSettings', 'LayoutVer', 'UidDir', 'WinX', 'WinY', 'WinW', 'WinH', 'Theme', 'UpdateUrl', 'AutoUpdate', 'LastSeenVersion') { if ($null -ne $j.$p) { $cfg.$p = $j.$p } }
        if ($j.SerialMap) { foreach ($pr in $j.SerialMap.PSObject.Properties) { $cfg.SerialMap[$pr.Name] = [string]$pr.Value } }
        if ($j.SearchNext) { foreach ($pr in $j.SearchNext.PSObject.Properties) { $cfg.SearchNext[$pr.Name] = [string]$pr.Value } }
        # ข้อมูล LINE ต่อเครื่อง (index -> ชื่อ LINE / เพื่อน / กลุ่ม)
        if ($j.LineInfo) {
            foreach ($pr in $j.LineInfo.PSObject.Properties) {
                $cfg.LineInfo[$pr.Name] = @{ Name = [string]$pr.Value.Name; Friends = [string]$pr.Value.Friends; Groups = [string]$pr.Value.Groups; LastOpen = [string]$pr.Value.LastOpen }
            }
        }
    } catch {}
}
function Save-Config {
    try {
        if (-not (Test-Path $CfgDir)) { New-Item -ItemType Directory -Path $CfgDir -Force | Out-Null }
        Write-SafeText $CfgFile ($cfg | ConvertTo-Json -Depth 8)
    } catch {}
}

# ---------- เปลี่ยนคำในโปรแกรม (คำเดิม -> คำใหม่) เก็บใน %APPDATA%\LDAdbConnector\texts.json ----------
$script:TextsPath = Join-Path $CfgDir 'texts.json'
$script:TextMap = [ordered]@{}
$script:TextKeys = @()
$script:TxtOrig = @{}
function Update-TextKeys { $script:TextKeys = @($script:TextMap.Keys | Sort-Object { $_.Length } -Descending) }
function Load-TextMap {
    $script:TextMap = [ordered]@{}
    $j = Read-JsonSafe $script:TextsPath
    if ($j) { foreach ($pr in $j.PSObject.Properties) { if ($pr.Name -and [string]$pr.Value -ne '') { $script:TextMap[$pr.Name] = [string]$pr.Value } } }
    Update-TextKeys
}
function Save-TextMap { try { Write-SafeText $script:TextsPath (ConvertTo-Json -InputObject $script:TextMap -Depth 3) } catch {} }
# translate one piece of text (longest words first)
function T([string]$s) {
    if (-not $s -or -not $script:TextKeys.Count) { return $s }
    foreach ($k in $script:TextKeys) { if ($s.Contains($k)) { $s = $s.Replace($k, [string]$script:TextMap[$k]) } }
    return $s
}
# set a translated text, remembering the original so the change can be undone / re-done
function Set-TextTr($obj, [string]$prop) {
    $cur = [string]$obj.$prop
    $st = $script:TxtOrig[$obj]
    $orig = if ($st -and $cur -eq $st.Applied) { $st.Orig } else { $cur }
    $new = T $orig
    $script:TxtOrig[$obj] = @{ Orig = $orig; Applied = $new }
    if ($new -ne $cur) { $obj.$prop = $new }
}
function Apply-MenuTexts($items) {
    foreach ($it in @($items)) {
        if ($it -is [System.Windows.Forms.ToolStripSeparator]) { continue }
        if ($it.Text) { Set-TextTr $it 'Text' }
        if ($it -is [System.Windows.Forms.ToolStripDropDownItem] -and $it.DropDownItems.Count) { Apply-MenuTexts $it.DropDownItems }
    }
}
$script:TxtSkipCombo = @()
function Apply-Texts($root) {
    if (-not $root -or (-not $script:TextKeys.Count -and -not $script:TxtOrig.Count)) { return }
    $stack = New-Object System.Collections.Stack
    $stack.Push($root)
    while ($stack.Count) {
        $c = $stack.Pop()
        if ($c -is [System.Windows.Forms.TextBoxBase] -or $c -is [System.Windows.Forms.NumericUpDown]) { continue }
        if ($c -is [System.Windows.Forms.DataGridView]) {
            foreach ($col in $c.Columns) { Set-TextTr $col 'HeaderText' }
            continue
        }
        if ($c -is [System.Windows.Forms.ComboBox]) {
            # list choices (not the editable / value combos)
            if ($c.DropDownStyle -eq 'DropDownList' -and $script:TxtSkipCombo -notcontains $c) {
                $cur = @($c.Items | ForEach-Object { [string]$_ })
                $st = $script:TxtOrig[$c]
                $orig = if ($st -and (($cur -join "`n") -eq ($st.Applied -join "`n"))) { $st.Orig } else { $cur }
                $new = @($orig | ForEach-Object { T $_ })
                $script:TxtOrig[$c] = @{ Orig = $orig; Applied = $new }
                for ($i = 0; $i -lt $new.Count -and $i -lt $c.Items.Count; $i++) { if ([string]$c.Items[$i] -ne $new[$i]) { $c.Items[$i] = $new[$i] } }
            }
            continue
        }
        if (-not ($c -is [System.Windows.Forms.Form]) -or $c.Text) { if ($c.Text) { Set-TextTr $c 'Text' } }
        if ($c.ContextMenuStrip) { Apply-MenuTexts $c.ContextMenuStrip.Items }
        foreach ($ch in $c.Controls) { $stack.Push($ch) }
    }
}
Load-TextMap

# หลังเพิ่ม ID: 0 = หากลุ่มเอง+ติ๊กทั้งหมด, 1 = จบเลย, 2 = เลือกกลุ่มเอง (pop up) แล้วเชิญตามชื่อที่สแกนได้
if ([int]$cfg.AfterIdMode -lt 0 -or [int]$cfg.AfterIdMode -gt 3) { $cfg.AfterIdMode = $(if ([bool]$cfg.IdOnly) { 1 } else { 0 }) }

# ---------- ค้นหาโฟลเดอร์ LDPlayer9 ----------
function Find-LdDir {
    $c = New-Object System.Collections.Generic.List[string]
    foreach ($n in 'dnplayer', 'ldconsole', 'dnmultiplayer') {
        Get-Process -Name $n -ErrorAction SilentlyContinue | ForEach-Object {
            try { if ($_.Path) { $c.Add((Split-Path $_.Path)) } } catch {}
        }
    }
    foreach ($k in 'HKCU:\Software\XuanZhi\LDPlayer9', 'HKLM:\SOFTWARE\XuanZhi\LDPlayer9', 'HKLM:\SOFTWARE\WOW6432Node\XuanZhi\LDPlayer9') {
        try {
            $v = Get-ItemProperty -Path $k -ErrorAction Stop
            foreach ($n in 'InstallDir', 'InstallPath') { if ($v.$n) { $c.Add([string]$v.$n) } }
        } catch {}
    }
    foreach ($root in 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
                      'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
                      'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*') {
        try {
            Get-ItemProperty $root -ErrorAction SilentlyContinue |
                Where-Object { $_.DisplayName -like '*LDPlayer*' } |
                ForEach-Object {
                    if ($_.InstallLocation) { $c.Add([string]$_.InstallLocation) }
                    if ($_.DisplayIcon) { try { $c.Add((Split-Path (($_.DisplayIcon -replace '"', '') -replace ',\d+$', ''))) } catch {} }
                }
        } catch {}
    }
    foreach ($d in [System.IO.DriveInfo]::GetDrives()) {
        if ($d.DriveType -ne 'Fixed' -or -not $d.IsReady) { continue }
        foreach ($sub in 'LDPlayer\LDPlayer9', 'LDPlayer9', 'Program Files\LDPlayer\LDPlayer9', 'Program Files (x86)\LDPlayer\LDPlayer9', 'XuanZhi\LDPlayer9') {
            $c.Add((Join-Path $d.RootDirectory.FullName $sub))
        }
    }
    foreach ($dir in $c) {
        if ($dir -and (Test-Path (Join-Path $dir 'ldconsole.exe'))) { return $dir.TrimEnd('\') }
    }
    return ''
}

# ---------- สถานะที่แชร์ระหว่าง UI กับ Worker ----------
$Sync = [hashtable]::Synchronized(@{
    TemplateDir = (Split-Path -Parent $PSCommandPath)
    LdDir       = ''
    Adb         = ''
    LdConsole   = ''
    PathOk      = $false
    PathChanged = $true
    AdbStopped  = $false
    Paused      = $false
    Busy        = [hashtable]::Synchronized(@{})
    IsAdmin     = $script:IsAdmin
    Interval    = [int]$cfg.Interval
    Auto        = [bool]$cfg.Auto
    Stop        = $false
    Snapshot    = $null
    Version     = 0
    Summary     = 'กำลังเริ่ม...'
    DiagReport  = ''
    DiagVersion = 0
    Log         = New-Object 'System.Collections.Concurrent.ConcurrentQueue[string]'
    Commands    = New-Object 'System.Collections.Concurrent.ConcurrentQueue[object]'
})

# ================================================================
#  WORKER (รันใน background runspace)
# ================================================================
$WorkerScript = {
    param($Sync)

    $env:NO_PROXY = '127.0.0.1,localhost'
    $script:st = @{}            # index -> สถานะต่อเครื่อง
    $script:serverReady = $false
    $script:globalFail = 0
    $script:force = $false
    $script:lastMismatchLog = [datetime]::MinValue
    $script:lastInst = @()

    # encoding สำหรับ ldconsole (ภาษาของระบบ)
    $script:AnsiEnc = [System.Text.Encoding]::Default
    try {
        try { [System.Text.Encoding]::RegisterProvider([System.Text.CodePagesEncodingProvider]::Instance) } catch {}
        $script:AnsiEnc = [System.Text.Encoding]::GetEncoding([System.Globalization.CultureInfo]::CurrentCulture.TextInfo.ANSICodePage)
    } catch {}

    function Write-Log([string]$m) {
        $Sync.Log.Enqueue(('[{0}] {1}' -f (Get-Date).ToString('HH:mm:ss'), $m))
    }

    # รันโปรแกรมแบบมี timeout (กันค้าง)
    function Invoke-Exe {
        param([string]$File, [string]$Arguments, [int]$TimeoutMs = 8000, [System.Text.Encoding]$Encoding = [System.Text.Encoding]::UTF8)
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $File
        $psi.Arguments = $Arguments
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true
        $psi.StandardOutputEncoding = $Encoding
        $psi.StandardErrorEncoding = $Encoding
        try { $psi.WorkingDirectory = Split-Path $File } catch {}
        $p = New-Object System.Diagnostics.Process
        $p.StartInfo = $psi
        try { [void]$p.Start() } catch {
            return [pscustomobject]@{ Code = -1; Out = ''; Err = $_.Exception.Message; TimedOut = $false }
        }
        $o = $p.StandardOutput.ReadToEndAsync()
        $e = $p.StandardError.ReadToEndAsync()
        if (-not $p.WaitForExit($TimeoutMs)) {
            try { $p.Kill() } catch {}
            return [pscustomobject]@{ Code = -2; Out = ''; Err = 'timeout'; TimedOut = $true }
        }
        $out = ''; $err = ''
        try { if ($o.Wait(1500)) { $out = $o.Result } } catch {}
        try { if ($e.Wait(500)) { $err = $e.Result } } catch {}
        $code = $p.ExitCode
        $p.Dispose()
        return [pscustomobject]@{ Code = $code; Out = [string]$out; Err = [string]$err; TimedOut = $false }
    }

    # start-server แบบไม่ redirect output (กันปัญหา daemon ถือ pipe แล้วค้าง)
    function Start-AdbServer {
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $Sync.Adb
        $psi.Arguments = 'start-server'
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true
        $psi.WorkingDirectory = $Sync.LdDir
        try {
            $p = [System.Diagnostics.Process]::Start($psi)
            if (-not $p.WaitForExit(15000)) { try { $p.Kill() } catch {} }
        } catch { Write-Log "start-server ล้มเหลว: $($_.Exception.Message)" }
    }

    function Restart-AdbServer {
        [void](Invoke-Exe $Sync.Adb 'kill-server' 5000)
        Get-Process -Name adb -ErrorAction SilentlyContinue | Where-Object {
            try { $_.Path -eq $Sync.Adb } catch { $false }
        } | Stop-Process -Force -ErrorAction SilentlyContinue
        Start-Sleep -Milliseconds 600
        Start-AdbServer
        $script:serverReady = $true
    }

    function Get-AdbDevices {
        $r = Invoke-Exe $Sync.Adb 'devices' 6000
        if ($r.TimedOut) { return $null }
        if (("$($r.Out)$($r.Err)") -match "doesn't match this client|version") {
            if (((Get-Date) - $script:lastMismatchLog).TotalSeconds -gt 60) {
                $script:lastMismatchLog = Get-Date
                Write-Log 'เตือน: มี adb เวอร์ชันอื่นแย่ง server (เช่น Android SDK / โปรแกรมบอทอื่น) ถ้าหลุดบ่อยให้ปิดโปรแกรมนั้น หรือให้มันใช้ adb.exe ของ LD'
            }
        }
        $map = @{}
        foreach ($line in ($r.Out -split "`r?`n")) {
            if ($line -match '^(\S+)\s+(device|offline|unauthorized|authorizing|connecting|no permissions)') {
                $map[$Matches[1]] = $Matches[2]
            }
        }
        return $map
    }

    function Get-SerialState([string]$serial) {
        $r = Invoke-Exe $Sync.Adb "-s $serial get-state" 4000
        $t = ($r.Out + '').Trim()
        if ($t -in 'device', 'offline', 'unauthorized', 'bootloader', 'recovery') { return $t }
        return ''
    }

    function Get-LdInstances {
        $r = Invoke-Exe $Sync.LdConsole 'list2' 8000 $script:AnsiEnc
        $list = New-Object System.Collections.Generic.List[object]
        foreach ($line in ($r.Out -split "`r?`n")) {
            $f = $line.Split(',')
            if ($f.Count -lt 7) { continue }
            $idx = 0
            if (-not [int]::TryParse($f[0], [ref]$idx)) { continue }
            # index,title,top-hwnd,bind-hwnd,android-started,pid,vbox-pid,width,height,dpi
            $name = $f[1]; $started = $f[4]; $procId = $f[5]; $vbox = $f[6]
            $pi = 0; [void][int]::TryParse($procId, [ref]$pi)
            $vi = 0; [void][int]::TryParse($vbox, [ref]$vi)
            $list.Add([pscustomobject]@{ Index = $idx; Name = $name; Started = ($started -eq '1'); ProcId = $pi; VboxPid = $vi })
        }
        return $list.ToArray()
    }

    # พอร์ตที่ VM แต่ละตัวเปิด listen อยู่ (หา adb port จริง)
    function Get-ListenPorts {
        $m = @{}
        try {
            Get-NetTCPConnection -State Listen -ErrorAction Stop |
                ForEach-Object {
                    $k = [int]$_.OwningProcess
                    if (-not $m.ContainsKey($k)) { $m[$k] = @() }
                    $m[$k] += [int]$_.LocalPort
                }
        } catch {
            try {
                $r = Invoke-Exe "$env:SystemRoot\System32\netstat.exe" '-ano -p TCP' 8000
                foreach ($line in ($r.Out -split "`r?`n")) {
                    if ($line -match '^\s*TCP\s+\S+:(\d+)\s+\S+\s+LISTENING\s+(\d+)') {
                        $port = [int]$Matches[1]; $k = [int]$Matches[2]
                        if (-not $m.ContainsKey($k)) { $m[$k] = @() }
                        $m[$k] += $port
                    }
                }
            } catch {}
        }
        return $m
    }

    # อ่านโปรเซส LD จริงจาก Windows (dnplayer.exe = หน้าต่าง LD, *BoxHeadless.exe = VM)
    function Get-LdProcInfo {
        $info = @{ Dn = @{}; Vbox = @{}; Procs = @(); Error = '' }
        try {
            $procs = @(Get-CimInstance Win32_Process -Filter "Name='dnplayer.exe' OR Name LIKE '%BoxHeadless%'" -ErrorAction Stop)
            $info.Procs = $procs
            foreach ($p in $procs) {
                $cl = [string]$p.CommandLine
                if ($p.Name -ieq 'dnplayer.exe') {
                    if ($cl -match 'index=(\d+)') { $info.Dn[[int]$Matches[1]] = [int]$p.ProcessId }
                } elseif ($cl -match 'leidian(\d+)') {
                    $info.Vbox[[int]$Matches[1]] = [int]$p.ProcessId
                }
            }
        } catch { $info.Error = $_.Exception.Message }
        return $info
    }

    function Get-RunningNames {
        $set = New-Object 'System.Collections.Generic.HashSet[string]'
        $r = Invoke-Exe $Sync.LdConsole 'runninglist' 8000 $script:AnsiEnc
        foreach ($l in ($r.Out -split "`r?`n")) { $n = $l.Trim(); if ($n) { [void]$set.Add($n) } }
        return , $set
    }

    function Test-Tcp([int]$port) {
        $c = New-Object System.Net.Sockets.TcpClient
        try {
            $ar = $c.BeginConnect('127.0.0.1', $port, $null, $null)
            if ($ar.AsyncWaitHandle.WaitOne(1000) -and $c.Connected) { return $true }
            return $false
        } catch { return $false } finally { $c.Close() }
    }

    function Get-LdSerialPort([int]$index) {
        $r = Invoke-Exe $Sync.LdConsole "adb --index $index --command `"get-serialno`"" 10000 $script:AnsiEnc
        $txt = "$($r.Out) $($r.Err)"
        if ($txt -match '(?:127\.0\.0\.1|localhost):(\d+)') { return [int]$Matches[1] }
        if ($txt -match 'emulator-(\d+)') { return ([int]$Matches[1] + 1) }
        return 0
    }

    function Test-Root([string]$serial) {
        $r = Invoke-Exe $Sync.Adb "-s $serial shell id" 4000
        if ($r.Out -match 'uid=0') { return 'มี (adbd)' }
        $r = Invoke-Exe $Sync.Adb "-s $serial shell `"su -c id`"" 6000
        if ($r.Out -match 'uid=0') { return 'มี' }
        return 'ไม่มี'
    }

    function Invoke-Diagnose {
        $sb = New-Object System.Text.StringBuilder
        function A([string]$x) { [void]$sb.AppendLine($x) }
        $hints = New-Object System.Collections.Generic.List[string]

        A "===== รายงานตรวจสอบ  $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss')) ====="
        A "รันแบบ Admin : $($Sync.IsAdmin)"
        A "โฟลเดอร์ LD   : $($Sync.LdDir)"
        A "adb.exe      : $($Sync.Adb)   [มีไฟล์: $(Test-Path $Sync.Adb)]"
        A "ldconsole    : $($Sync.LdConsole)   [มีไฟล์: $(Test-Path $Sync.LdConsole)]"
        $v = Invoke-Exe $Sync.Adb 'version' 5000
        A "adb version  : $((($v.Out -split "`r?`n") | Select-Object -First 1))"
        A ''

        A '--- [1] ldconsole list2 (index,ชื่อ,top,bind,android-started,pid,vbox-pid,...) ---'
        $r = Invoke-Exe $Sync.LdConsole 'list2' 8000 $script:AnsiEnc
        $list2Txt = ($r.Out + '').Trim()
        if ($list2Txt) { A $list2Txt } else { A "(ว่าง) code=$($r.Code) err=$($r.Err)" }
        A ''

        A '--- [2] ldconsole runninglist ---'
        $r = Invoke-Exe $Sync.LdConsole 'runninglist' 8000 $script:AnsiEnc
        $rlTxt = ($r.Out + '').Trim()
        if ($rlTxt) { A $rlTxt } else { A '(ว่าง)' }
        A ''

        A '--- [3] โปรเซส LDPlayer ที่ Windows เห็น ---'
        $pinfo = Get-LdProcInfo
        if ($pinfo.Error) { A "อ่านโปรเซสไม่ได้: $($pinfo.Error)" }
        $noCmd = $false; $otherDirs = @{}
        foreach ($p in $pinfo.Procs) {
            A "PID $($p.ProcessId)  $($p.Name)"
            A "   path: $($p.ExecutablePath)"
            A "   cmd : $($p.CommandLine)"
            if (-not $p.CommandLine) { $noCmd = $true }
            if ($p.Name -ieq 'dnplayer.exe' -and $p.ExecutablePath) {
                $d = (Split-Path $p.ExecutablePath).TrimEnd('\')
                if ($Sync.LdDir -and $d -ne $Sync.LdDir.TrimEnd('\')) { $otherDirs[$d] = $true }
            }
        }
        if ($pinfo.Procs.Count -eq 0) { A '(ไม่พบ dnplayer.exe / *BoxHeadless.exe)' }
        A ''

        A '--- [4] พอร์ตที่โปรเซส VM เปิดรอ (LISTEN) ---'
        $ports = Get-ListenPorts
        foreach ($p in ($pinfo.Procs | Where-Object { $_.Name -notlike 'dnplayer*' })) {
            $pp = @($ports[[int]$p.ProcessId] | Sort-Object -Unique)
            A "PID $($p.ProcessId): $(if ($pp.Count) { $pp -join ', ' } else { '(ไม่มีพอร์ต)' })"
        }
        A ''

        A '--- [5] adb devices -l ---'
        $r = Invoke-Exe $Sync.Adb 'devices -l' 6000
        A (($r.Out + ' ' + $r.Err).Trim())
        A ''

        A '--- [6] ทดสอบทีละเครื่องที่เปิดอยู่ ---'
        $insts = @(Get-AllInstances $pinfo)
        $runNames = Get-RunningNames
        $anyRunning = $false
        foreach ($inst in $insts) {
            $idx = [int]$inst.Index
            $vbox = $inst.VboxPid
            if ($pinfo.Vbox.ContainsKey($idx)) { $vbox = $pinfo.Vbox[$idx] }
            $running = ($inst.ProcId -gt 0) -or ($vbox -gt 0) -or $pinfo.Dn.ContainsKey($idx) -or ($inst.Name -and $runNames.Contains($inst.Name.Trim()))
            if (-not $running) { continue }
            $anyRunning = $true
            A "# index $idx  ชื่อ '$($inst.Name)'  pid(list2)=$($inst.ProcId)  vbox(list2)=$($inst.VboxPid)  vbox(จริง)=$vbox"
            $cands = New-Object System.Collections.Generic.List[int]
            $cands.Add(5555 + 2 * $idx)
            if ($vbox -gt 0 -and $ports.ContainsKey($vbox)) { foreach ($x in $ports[$vbox]) { if (($x % 2) -eq 1 -and $x -ge 5555 -and -not $cands.Contains($x)) { $cands.Add($x) } } }
            $r = Invoke-Exe $Sync.LdConsole "adb --index $idx --command `"get-serialno`"" 10000 $script:AnsiEnc
            $sn = (($r.Out + ' ' + $r.Err) -replace '\s+', ' ').Trim()
            A "   ldconsole adb get-serialno : $sn"
            if ($sn -match ':(\d+)') { $x = [int]$Matches[1]; if (-not $cands.Contains($x)) { $cands.Add($x) } }
            elseif ($sn -match 'emulator-(\d+)') { $x = [int]$Matches[1] + 1; if (-not $cands.Contains($x)) { $cands.Add($x) } }
            $anyOpen = $false
            foreach ($port in $cands) {
                $open = Test-Tcp $port
                if ($open) { $anyOpen = $true }
                $cr = Invoke-Exe $Sync.Adb "connect 127.0.0.1:$port" 7000
                $st = Get-SerialState "127.0.0.1:$port"
                A ("   พอร์ต {0,-5}  TCP={1,-6}  adb connect: {2}  -> state: {3}" -f $port, $(if ($open) { 'เปิด' } else { 'ปิด' }), ((($cr.Out + ' ' + $cr.Err) -replace '\s+', ' ').Trim()), $(if ($st) { $st } else { '-' }))
            }
            if (-not $anyOpen) { $hints.Add("index $idx : ไม่มีพอร์ต ADB เปิดเลย -> ใน LD ไปที่ ตั้งค่า > อื่นๆ > ADB debugging เลือก 'เปิดการเชื่อมต่อในเครื่อง (Open local connection)' แล้วรีบูต LD") }
        }
        if (-not $anyRunning) { A '(ไม่พบเครื่องที่เปิดอยู่)' }
        A ''

        if ($pinfo.Procs.Count -eq 0) { $hints.Add('Windows ไม่เห็นโปรเซส LD เลย -> LD อาจไม่ได้เปิด หรือสคริปต์ไม่มีสิทธิ์ ลองกด "รันแบบ Admin"') }
        if ($noCmd -and -not $Sync.IsAdmin) { $hints.Add('อ่านรายละเอียดโปรเซส LD ไม่ได้ (LD น่าจะรันแบบ Admin) -> กดปุ่ม "รันแบบ Admin"') }
        if (-not $list2Txt) { $hints.Add('ldconsole list2 ไม่คืนข้อมูล -> โฟลเดอร์ที่เลือกอาจผิด หรือ LD รันแบบ Admin แต่โปรแกรมนี้ไม่ได้รันแบบ Admin') }
        foreach ($d in $otherDirs.Keys) { $hints.Add("LD ที่เปิดอยู่มาจากโฟลเดอร์อื่น: $d -> ให้เลือกโฟลเดอร์นี้แทน") }
        if ($pinfo.Procs.Count -gt 0 -and -not $anyRunning) { $hints.Add('มีโปรเซส LD แต่จับคู่กับ index ไม่ได้ -> ส่งรายงานนี้มาตรวจต่อ') }

        A '--- [7] สรุป / วิธีแก้ ---'
        if ($hints.Count -eq 0) { A 'ไม่พบปัญหาที่ชัดเจน' } else { foreach ($h in $hints) { A "* $h" } }

        $Sync.DiagReport = $sb.ToString()
        $Sync.DiagVersion = $Sync.DiagVersion + 1
        Write-Log 'ตรวจสอบเสร็จ (เปิดหน้าต่างรายงานแล้ว)'
    }

    # รวมเครื่องจาก list2 + โปรเซสจริง (กรณี list2 ไม่ครบ)
    function Get-AllInstances($pinfo) {
        $insts = New-Object System.Collections.Generic.List[object]
        $have = @{}
        foreach ($i in @(Get-LdInstances)) { $insts.Add($i); $have[[int]$i.Index] = $true }
        $extra = @($pinfo.Dn.Keys) + @($pinfo.Vbox.Keys) | Sort-Object -Unique
        foreach ($k in $extra) {
            if ($have.ContainsKey([int]$k)) { continue }
            $have[[int]$k] = $true
            $dp = 0; if ($pinfo.Dn.ContainsKey($k)) { $dp = $pinfo.Dn[$k] }
            $vp = 0; if ($pinfo.Vbox.ContainsKey($k)) { $vp = $pinfo.Vbox[$k] }
            $insts.Add([pscustomobject]@{ Index = [int]$k; Name = "leidian$k"; Started = $true; ProcId = $dp; VboxPid = $vp })
        }
        return $insts.ToArray()
    }

    function Set-Busy([int]$i, [string]$txt) { $Sync.Busy[$i] = $txt }
    function Clear-Busy([int]$i) { $Sync.Busy.Remove($i) }
    function Get-St([int]$i) { if ($script:st.ContainsKey($i)) { return $script:st[$i] } return $null }
    function Now { (Get-Date).ToString('HH:mm:ss') }

    function Get-LineNodes([string]$serial) {
        $r = Invoke-Exe $Sync.Adb "-s $serial shell uiautomator dump /sdcard/ld_line_ui.xml" 12000
        if ($r.Code -ne 0) { Write-Log "LINE UI dump failed: $($r.Err)" }
        $r = Invoke-Exe $Sync.Adb "-s $serial shell cat /sdcard/ld_line_ui.xml" 7000
        try {
            [xml]$doc = $r.Out
            return ,@($doc.SelectNodes('//node'))
        } catch { Write-Log "LINE UI XML: $($_.Exception.Message)"; return ,@() }
    }
    function Invoke-LineTap([string]$serial, [int]$x, [int]$y) {
        $r = Invoke-Exe $Sync.Adb "-s $serial shell input tap $x $y" 6000
        if ($r.Code -ne 0) { throw "ADB tap ($x,$y) failed: $($r.Err)" }
        Write-Log "LINE tap $serial ($x,$y)"
    }
    function Tap-LineNode([string]$serial, [string]$pattern) {
        $nodes = @(Get-LineNodes $serial)
        foreach ($n in $nodes) {
            $label = [string]$n.GetAttribute('text') + ' ' + [string]$n.GetAttribute('content-desc')
            if ($label -match $pattern -and $n.GetAttribute('bounds') -match '\[(\d+),(\d+)\]\[(\d+),(\d+)\]') {
                $x = [int](([int]$Matches[1]+[int]$Matches[3])/2)
                $y = [int](([int]$Matches[2]+[int]$Matches[4])/2)
                Invoke-LineTap $serial $x $y
                return $true
            }
        }
        return $false
    }
    function Get-LineScreen([string]$serial) {
        $r = Invoke-Exe $Sync.Adb "-s $serial shell wm size" 5000
        if ($r.Out -match '(\d+)x(\d+)') { return @([int]$Matches[1],[int]$Matches[2]) }
        return @(534,956)
    }
    # Match icon against an Android screenshot, not a Windows LINE process.
    function Find-LineIcon([string]$serial, [string]$templateName) {
        $tpl = Join-Path $Sync.TemplateDir $templateName
        if (-not (Test-Path $tpl)) { return $null }
        $remote = '/sdcard/ld_match_screen.png'
        $shot = Join-Path $env:TEMP ("ld_screen_{0}.png" -f ([guid]::NewGuid().ToString('N')))
        try {
            $a = Invoke-Exe $Sync.Adb "-s $serial shell screencap -p $remote" 10000
            if ($a.Code -ne 0) { return $null }
            $a = Invoke-Exe $Sync.Adb "-s $serial pull $remote `"$shot`"" 12000
            if ($a.Code -ne 0 -or -not (Test-Path $shot)) { return $null }
            Add-Type -AssemblyName System.Drawing
            $hay = [System.Drawing.Bitmap]::FromFile($shot)
            $src = [System.Drawing.Bitmap]::FromFile($tpl)
            try {
                $bestScore = 0.0; $best = $null
                foreach ($scale in @(0.75,1.0,1.25,1.5,2.0)) {
                    $tw = [int][math]::Round($src.Width*$scale)
                    $th = [int][math]::Round($src.Height*$scale)
                    if ($tw -gt $hay.Width -or $th -gt $hay.Height -or $tw -lt 8 -or $th -lt 8) { continue }
                    $t = New-Object System.Drawing.Bitmap($src,$tw,$th)
                    try {
                        # Sample opaque pixels only; use sparse samples for speed.
                        $samples = New-Object System.Collections.ArrayList
                        for ($yy=0;$yy -lt $th;$yy += [math]::Max(2,[int]($th/12))) {
                            for ($xx=0;$xx -lt $tw;$xx += [math]::Max(2,[int]($tw/12))) {
                                $c=$t.GetPixel($xx,$yy)
                                if ($c.A -ge 128) { [void]$samples.Add(@($xx,$yy,$c.R,$c.G,$c.B)) }
                            }
                        }
                        if ($samples.Count -lt 8) { continue }
                        $step=2
                        for ($y=0;$y -le [math]::Min($hay.Height-$th,[int]($hay.Height*$(if ($templateName -eq 'addfriend.png') {0.22} else {0.85})));$y+=$step) {
                            for ($x=0;$x -le $hay.Width-$tw;$x+=$step) {
                                $matches=0
                                foreach ($pt in $samples) {
                                    $hc=$hay.GetPixel($x+[int]$pt[0],$y+[int]$pt[1])
                                    if ([math]::Abs($hc.R-$pt[2]) -le 40 -and [math]::Abs($hc.G-$pt[3]) -le 40 -and [math]::Abs($hc.B-$pt[4]) -le 40) { $matches++ }
                                }
                                $score=$matches/[double]$samples.Count
                                if ($score -gt $bestScore) { $bestScore=$score; $best=@([int]($x+$tw/2),[int]($y+$th/2)) }
                            }
                        }
                    } finally { $t.Dispose() }
                }
                if ($bestScore -ge 0.97) { Write-Log "LINE image match $templateName score=$([math]::Round($bestScore,3))"; return ,$best }
                Write-Log "LINE image match $templateName not found; best=$([math]::Round($bestScore,3))"
                return $null
            } finally { $src.Dispose(); $hay.Dispose() }
        } catch { Write-Log "LINE image match error: $($_.Exception.Message)"; return $null }
        finally { Remove-Item $shot -Force -ErrorAction SilentlyContinue }
    }
    function Save-LineDiagnostic([string]$serial, [int]$i, [string]$stage) {
        $folder = Join-Path $env:APPDATA 'LDAdbConnector\Diagnostics'
        if (-not (Test-Path $folder)) { [void](New-Item -ItemType Directory -Force -Path $folder) }
        $file = Join-Path $folder ("LD_{0}_{1}_{2}.png" -f $i,$stage,(Get-Date -Format 'yyyyMMdd_HHmmss'))
        $remote = '/sdcard/ld_line_diagnostic.png'
        $a = Invoke-Exe $Sync.Adb "-s $serial shell screencap -p $remote" 12000
        if ($a.Code -eq 0) {
            $a = Invoke-Exe $Sync.Adb "-s $serial pull $remote `"$file`"" 12000
            if ($a.Code -eq 0 -and (Test-Path $file)) { Write-Log "#$i [$stage] บันทึกภาพ: $file"; return $file }
        }
        Write-Log "#$i [$stage] จับภาพหน้าจอไม่สำเร็จ: $($a.Err)"
        return ''
    }
    function Write-LineStage([int]$i, [int]$step, [string]$description) {
        $msg = "LINE ขั้นตอน $step/7 : $description"
        Set-Busy $i $msg
        Write-Log "#$i $msg"
    }
    function Invoke-LineSearch($c) {
        $i = [int]$c.Index; $serial = [string]$c.Serial
        # Resolve the live ADB transport in the worker rather than trusting a stale UI snapshot.
        $candidateSerials = New-Object System.Collections.Generic.List[string]
        if ($script:st.ContainsKey($i) -and $script:st[$i].Serial) { $candidateSerials.Add([string]$script:st[$i].Serial) }
        if ($serial -and -not $candidateSerials.Contains($serial)) { $candidateSerials.Add($serial) }
        # The selected serial is checked first; LDPlayer ports need not be 5555+2*index.
        $defaultPort = 5555 + 2 * $i
        foreach ($v in @("127.0.0.1:$defaultPort", "emulator-$($defaultPort - 1)")) {
            if (-not $candidateSerials.Contains($v)) { $candidateSerials.Add($v) }
        }
        # Verify through adb devices AND shell; never trust only the UI snapshot.
        $serial = ''
        $live = Get-AdbDevices
        if ($null -eq $live) { $live = @{} }
        foreach ($candidate in $candidateSerials) {
            $state = [string]$live[$candidate]
            if ($state -ne 'device' -and $candidate -match '^127\.0\.0\.1:(\d+)$' -and (Test-Tcp ([int]$Matches[1]))) {
                [void](Invoke-Exe $Sync.Adb "connect $candidate" 8000)
                $live = Get-AdbDevices
                if ($null -eq $live) { $live = @{} }
                $state = [string]$live[$candidate]
            }
            if ($state -eq 'device' -or (Get-SerialState $candidate) -eq 'device') {
                $probe = Invoke-Exe $Sync.Adb "-s $candidate shell echo LD_READY" 6000
                if ($probe.Code -eq 0 -and $probe.Out -match 'LD_READY') { $serial = $candidate; break }
            }
        }
        if (-not $serial) {
            # Some LD builds report the emulator serial instead of the TCP serial.
            $live = Get-AdbDevices
            if ($null -eq $live) { $live = @{} }
            $expected = @("127.0.0.1:$defaultPort", "emulator-$($defaultPort - 1)")
            foreach ($candidate in $expected) {
                if ([string]$live[$candidate] -ne 'device') { continue }
                $probe = Invoke-Exe $Sync.Adb "-s $candidate shell echo LD_READY" 6000
                if ($probe.Code -eq 0 -and $probe.Out -match 'LD_READY') { $serial = $candidate; break }
            }
        }
        if (-not $serial) {
            $r = Invoke-Exe $Sync.Adb 'devices -l' 7000
            Write-Log "#$i LINE: ไม่พบ ADB transport ที่ใช้งานได้; candidates=$($candidateSerials -join ', ')"
            Write-Log "ADB devices: $(($r.Out -replace '[\r\n]+',' | ').Trim())"
            Write-Log "ADB executable: $($Sync.Adb)"
            return
        }
        Write-Log "#$i LINE: verified ADB serial=$serial"
        try {
            Write-LineStage $i 1 'ยืนยัน ADB และเครื่องที่เลือก'
            Write-LineStage $i 2 'ตรวจสอบหน้า LINE ปัจจุบันและบันทึกภาพ'
            $null = Save-LineDiagnostic $serial $i 'before_scan'
            $nodes = @(Get-LineNodes $serial)
            $isHome = @($nodes | Where-Object { ([string]$_.GetAttribute('text') + ' ' + [string]$_.GetAttribute('content-desc')) -match 'หน้าหลัก|Home|เพิ่มเพื่อน|Add friends|友だち' }).Count -gt 0
            if (-not $isHome) { Write-Log "#$i ไม่พบป้าย Home ใน UI; จะใช้การจับภาพไอคอนแทน" }
            Write-LineStage $i 3 'สแกนหาปุ่มเพิ่มเพื่อนในบริเวณด้านบน'
            $hit = Find-LineIcon $serial 'addfriend.png'
            if (-not $hit) {
                $null = Save-LineDiagnostic $serial $i 'addfriend_not_found'
                throw 'ไม่พบไอคอนเพิ่มเพื่อนที่ตรงกับภาพต้นแบบ (ไม่คลิกพิกัดเดา)'
            }
            $sz = Get-LineScreen $serial
            if ($hit[1] -gt [int]($sz[1] * 0.24)) { throw 'ตำแหน่งปุ่มที่ตรวจพบอยู่นอกแถบด้านบน จึงไม่คลิก' }
            Write-Log "#$i พบปุ่มเพิ่มเพื่อนที่ ($($hit[0]),$($hit[1])) ขนาดหน้าจอ $($sz[0])x$($sz[1])"
            Write-LineStage $i 4 'คลิกปุ่มเพิ่มเพื่อนที่ตรวจพบ'
            Invoke-LineTap $serial $hit[0] $hit[1]
            Start-Sleep -Milliseconds 1400
            $null = Save-LineDiagnostic $serial $i 'after_addfriend'
            Write-LineStage $i 5 'สแกนหาปุ่มค้นหาในหน้าเพิ่มเพื่อน'
            if (-not (Tap-LineNode $serial 'Search|ค้นหา|検索|搜尋|ID/Phone|ID หรือหมายเลขโทรศัพท์')) {
                $hit = Find-LineIcon $serial 'line_search.png'
                if ($hit) { Invoke-LineTap $serial $hit[0] $hit[1] }
                else {
                    $null = Save-LineDiagnostic $serial $i 'search_button_not_found'
                    throw 'ไม่พบปุ่มค้นหา กรุณาตรวจภาพวินิจฉัยและเตรียม line_search.png (ไม่คลิกพิกัดเดา)'
                }
            }
            Start-Sleep -Milliseconds 900
            Write-LineStage $i 6 'รอช่องกรอกข้อความค้นหา'
            # LINE may render the search screen asynchronously. Wait for the actual input.
            $edit = @()
            for ($attempt = 0; $attempt -lt 8; $attempt++) {
                Start-Sleep -Milliseconds 550
                $nodes = @(Get-LineNodes $serial)
                $edit = @($nodes | Where-Object {
                    $_.GetAttribute('class') -match 'EditText|AutoCompleteTextView' -or
                    $_.GetAttribute('resource-id') -match '(search|query|keyword|input)' -and
                    $_.GetAttribute('clickable') -eq 'true'
                } | Select-Object -First 1)
                if ($edit.Count -gt 0) { break }
            }
            if (-not $edit.Count) {
                $labels = @($nodes | ForEach-Object {
                    $t = [string]$_.GetAttribute('text')
                    $d = [string]$_.GetAttribute('content-desc')
                    if ($t -or $d) { ($t + ' ' + $d).Trim() }
                } | Select-Object -First 20)
                Write-Log "#$i LINE search UI labels: $($labels -join ' | ')"
                throw 'ไม่พบช่องค้นหาใน UI หลังรอ 4 วินาที กรุณาส่งภาพหน้าจอ LINE หลังเข้าหน้าค้นหา'
            }
            $bounds = [string]$edit[0].GetAttribute('bounds')
            if ($bounds -notmatch '\[(\d+),(\d+)\]\[(\d+),(\d+)\]') { throw 'ช่องค้นหาไม่มีพิกัด bounds' }
            $x = [int](([int]$Matches[1]+[int]$Matches[3])/2)
            $y = [int](([int]$Matches[2]+[int]$Matches[4])/2)
            Invoke-LineTap $serial $x $y
            Start-Sleep -Milliseconds 250
            $value = [string]$c.Value
            if ($value -notmatch '^[\x20-\x7e]+$') { throw 'ADB input text รองรับข้อความ ASCII เท่านั้น (ไม่รองรับอักษรไทย/จีนโดยตรง)' }
            $encoded = $value.Replace('%','%25').Replace(' ','%s')
            if ($encoded -match '["''`\\]') { throw 'ข้อความมีอักขระพิเศษที่ ADB input text ไม่รองรับอย่างปลอดภัย' }
            [void](Invoke-Exe $Sync.Adb "-s $serial shell input keyevent KEYCODE_MOVE_END" 4000)
            [void](Invoke-Exe $Sync.Adb "-s $serial shell input keyevent KEYCODE_MOVE_HOME" 4000)
            $result = Invoke-Exe $Sync.Adb "-s $serial shell input text `"$encoded`"" 7000
            if ($result.Code -ne 0) { throw "ใส่ข้อความไม่สำเร็จ: $($result.Err)" }
            Write-LineStage $i 7 "กรอกข้อความจากช่อง $($c.Source) สำเร็จ (หยุดก่อนเพิ่มเพื่อน)"
        } catch { Write-Log "#$i LINE Search หยุด: $($_.Exception.Message)"; $null = Save-LineDiagnostic $serial $i 'error' }
        finally { Clear-Busy $i }
    }

    function Invoke-UiCommand($c) {
        $lc = $Sync.LdConsole
        switch ($c.Type) {
            'LineSearch' { Write-Log 'Legacy LINE search is disabled. Use the LINE config context menu.' }
            'ConnectAll' { $script:force = $true; Write-Log 'สั่งเชื่อมต่อทุกเครื่องตอนนี้' }
            'RestartServer' {
                Write-Log 'กำลังรีสตาร์ท ADB server...'
                Restart-AdbServer
                Write-Log 'รีสตาร์ท ADB server เรียบร้อย กำลังเชื่อมใหม่'
                $script:force = $true
            }
            'EnableRoot' {
                foreach ($i in $c.Idx) {
                    Set-Busy $i 'กำลังตั้งค่า Root...'
                    [void](Invoke-Exe $lc "modify --index $i --root 1" 15000 $script:AnsiEnc)
                    $s = Get-St $i; if ($s) { $s.Last = "$(Now) เปิด Root แล้ว (ต้องรีบูต)" }
                    Write-Log "ตั้งค่า Root = เปิด ให้ LD #$i (มีผลหลังรีบูต LD เครื่องนั้น)"
                    Clear-Busy $i
                }
            }
            'Reconnect' {
                foreach ($i in $c.Idx) {
                    $s = Get-St $i; if (-not $s -or -not $s.Serial) { continue }
                    Set-Busy $i 'กำลังเชื่อม ADB ใหม่...'
                    $s.Hold = $false
                    [void](Invoke-Exe $Sync.Adb "disconnect $($s.Serial)" 4000)
                    [void](Invoke-Exe $Sync.Adb "connect $($s.Serial)" 7000)
                    $st = Get-SerialState $s.Serial
                    $s.Last = "$(Now) " + $(if ($st -eq 'device') { 'เชื่อมใหม่สำเร็จ' } else { 'เชื่อมใหม่ไม่สำเร็จ' })
                    Write-Log "#$i เชื่อม ADB ใหม่ -> $($s.Last)"
                    Clear-Busy $i
                }
            }
            'Disconnect' {
                foreach ($i in $c.Idx) {
                    $s = Get-St $i; if (-not $s -or -not $s.Serial) { continue }
                    Set-Busy $i 'กำลังตัดการเชื่อม...'
                    $s.Hold = $true
                    [void](Invoke-Exe $Sync.Adb "disconnect $($s.Serial)" 4000)
                    Write-Log "#$i ตัดการเชื่อม ADB แล้ว (จะไม่เชื่อมอัตโนมัติจนกว่าจะกด Start ADB)"
                    Clear-Busy $i
                }
            }
            'QuitLd' {
                # ldconsole quit -> check it really closed -> quit by name -> end the LD's own processes
                foreach ($i in $c.Idx) {
                    $i = [int]$i
                    Set-Busy $i 'กำลังปิด LD...'
                    $lc = $Sync.LdConsole
                    $inst = @(Get-LdInstances | Where-Object { $_.Index -eq $i } | Select-Object -First 1)
                    $nm = if ($inst.Count) { [string]$inst[0].Name } else { '' }
                    $s = Get-St $i
                    if ($s -and $s.Serial) { [void](Invoke-Exe $Sync.Adb "disconnect $($s.Serial)" 4000) }
                    $how = ''
                    $tests = @(
                        @{ How = 'ldconsole quit --index'; Args = "quit --index $i" },
                        @{ How = 'ldconsole quit --name'; Args = $(if ($nm) { "quit --name `"$nm`"" } else { '' }) })
                    foreach ($t in $tests) {
                        if (-not $t.Args) { continue }
                        $rq = Invoke-Exe $lc $t.Args 15000 $script:AnsiEnc
                        $until = (Get-Date).AddSeconds(12)
                        do {
                            Start-Sleep -Milliseconds 800
                            $pi = Get-LdProcInfo
                            $li = @(Get-LdInstances | Where-Object { $_.Index -eq $i } | Select-Object -First 1)
                            $alive = $pi.Dn.ContainsKey($i) -or $pi.Vbox.ContainsKey($i) -or ($li.Count -and ($li[0].ProcId -gt 0 -or $li[0].VboxPid -gt 0))
                        } while ($alive -and (Get-Date) -lt $until)
                        if (-not $alive) { $how = $t.How; break }
                        Write-Log "#$i สั่ง '$($t.Args)' แล้ว LD ยังไม่ปิด ($((($rq.Out + ' ' + $rq.Err) -replace '\s+', ' ').Trim()))"
                    }
                    if (-not $how) {
                        # last way: end this LD's window + VM processes
                        $pi = Get-LdProcInfo
                        $pids = @()
                        if ($pi.Dn.ContainsKey($i)) { $pids += $pi.Dn[$i] }
                        if ($pi.Vbox.ContainsKey($i)) { $pids += $pi.Vbox[$i] }
                        $li = @(Get-LdInstances | Where-Object { $_.Index -eq $i } | Select-Object -First 1)
                        if ($li.Count) { if ($li[0].ProcId -gt 0) { $pids += $li[0].ProcId }; if ($li[0].VboxPid -gt 0) { $pids += $li[0].VboxPid } }
                        foreach ($pp in @($pids | Select-Object -Unique)) { try { [void](Invoke-Exe "$env:SystemRoot\System32\taskkill.exe" "/PID $pp /T /F" 8000) } catch {} }
                        Start-Sleep -Seconds 2
                        $pi = Get-LdProcInfo
                        if (-not ($pi.Dn.ContainsKey($i) -or $pi.Vbox.ContainsKey($i))) { $how = 'ปิดโปรเซสของ LD' }
                    }
                    if ($how) { Write-Log "#$i ปิด LD แล้ว ($how)"; if ($s) { $s.Last = "$(Now) ปิด LD แล้ว" } }
                    else { Write-Log "#$i ปิด LD ไม่สำเร็จ (ลองทุกวิธีแล้ว)" }
                    Clear-Busy $i
                }
                $script:force = $true
            }
            'CheckRoot' {
                foreach ($i in $c.Idx) {
                    $s = Get-St $i; if (-not $s -or -not $s.Serial) { continue }
                    Set-Busy $i 'กำลังตรวจ Root...'
                    $s.Root = Test-Root $s.Serial
                    $s.Last = "$(Now) Root: $($s.Root)"
                    Write-Log "#$i Root: $($s.Root)"
                    Clear-Busy $i
                }
            }
            'StartAdb' {
                $Sync.AdbStopped = $false
                foreach ($k in @($script:st.Keys)) { $script:st[$k].Hold = $false }
                $Sync.Auto = $true
                Write-Log 'Start ADB'
                Start-AdbServer
                $script:serverReady = $true
                $script:force = $true
            }
            'StopAdb' {
                $Sync.AdbStopped = $true
                Write-Log 'Stop ADB: ตัดการเชื่อมต่อทั้งหมด และปิด ADB server'
                [void](Invoke-Exe $Sync.Adb 'disconnect' 5000)
                [void](Invoke-Exe $Sync.Adb 'kill-server' 5000)
                Get-Process -Name adb -ErrorAction SilentlyContinue | Where-Object {
                    try { $_.Path -eq $Sync.Adb } catch { $false }
                } | Stop-Process -Force -ErrorAction SilentlyContinue
                $script:serverReady = $false
                foreach ($k in @($script:st.Keys)) { $script:st[$k].WasOk = $false; $script:st[$k].InfoSerial = '' }
            }
            'Diagnose' { Write-Log 'กำลังตรวจสอบปัญหา...'; Invoke-Diagnose }
            'Recheck' {
                foreach ($i in $c.Idx) { if ($script:st.ContainsKey([int]$i)) { $script:st[[int]$i].InfoSerial = '' } }
                Write-Log 'จะตรวจ Root / ข้อมูลเครื่องใหม่ในรอบถัดไป'
            }
        }
        foreach ($i in @($c.Idx)) { if ($null -ne $i) { Clear-Busy ([int]$i) } }
    }

    function Invoke-Cycle {
        $adb = $Sync.Adb
        if ($Sync.PathChanged) { $Sync.PathChanged = $false; $script:serverReady = $false }
        if (-not $script:serverReady) { Start-AdbServer; $script:serverReady = $true }

        $devs = Get-AdbDevices
        if ($null -eq $devs) {
            Write-Log 'adb devices ไม่ตอบสนอง -> รีสตาร์ท ADB server'
            Restart-AdbServer
            $devs = Get-AdbDevices
            if ($null -eq $devs) { $devs = @{} }
        }
        $ports = Get-ListenPorts
        $pinfo = Get-LdProcInfo
        $runNames = Get-RunningNames
        $insts = @(Get-AllInstances $pinfo)
        $script:lastInst = $insts
        $doConnect = $Sync.Auto -or $script:force
        $script:force = $false

        $rows = New-Object System.Collections.Generic.List[object]
        $runningCount = 0; $okCount = 0

        foreach ($inst in $insts) {
            $key = [int]$inst.Index
            if (-not $script:st.ContainsKey($key)) {
                $script:st[$key] = @{ Fail = 0; Root = '-'; Info = ''; InfoSerial = ''; Last = ''; WasOk = $false; LdPort = 0; Probe = [datetime]::MinValue; Serial = ''; Hold = $false }
            }
            $s = $script:st[$key]

            $vbox = $inst.VboxPid
            if ($pinfo.Vbox.ContainsKey($key)) { $vbox = $pinfo.Vbox[$key] }
            $running = ($inst.ProcId -gt 0) -or ($vbox -gt 0) -or $pinfo.Dn.ContainsKey($key) -or ($inst.Name -and $runNames.Contains($inst.Name.Trim()))

            # หาพอร์ต adb: ปกติ 5555 + index*2 แต่ตรวจกับพอร์ตที่ VM listen จริงด้วย
            $port = 5555 + 2 * $inst.Index
            if ($s.LdPort -gt 0) { $port = $s.LdPort }
            elseif ($vbox -gt 0 -and $ports.ContainsKey($vbox)) {
                $pp = @($ports[$vbox] | Where-Object { ($_ % 2) -eq 1 -and $_ -ge 5555 } | Sort-Object -Unique)
                if ($pp.Count -gt 0 -and $pp -notcontains $port) { $port = $pp[0] }
            }
            $serial = "127.0.0.1:$port"
            $emu = "emulator-$($port - 1)"
            if (-not $running) {
                if ($s.WasOk) { Write-Log "#$($inst.Index) $($inst.Name) -> LD ถูกปิด" }
                $s.WasOk = $false; $s.Fail = 0
                $s.InfoSerial = ''; $s.Info = ''; $s.Root = '-'; $s.LdPort = 0; $s.Probe = [datetime]::MinValue
                if ($devs.ContainsKey($serial)) { [void](Invoke-Exe $adb "disconnect $serial" 4000) }
                $rows.Add([pscustomobject]@{
                    Index = $inst.Index; Name = $inst.Name; Port = $port; Serial = ''; Adb = 'ปิดอยู่'; AdbOk = $false
                    Status = 'ปิดอยู่'; Running = $false; Root = '-'; Info = ''; Last = $s.Last
                })
                continue
            }
            $canTry = $true

            $adbState = [string]$devs[$serial]
            $emuState = [string]$devs[$emu]
            $useSerial = $serial

            if ($canTry) {
                $runningCount++
                if ($doConnect -and -not $s.Hold -and $adbState -ne 'device') {
                    Set-Busy $key 'กำลังเชื่อม ADB...'
                    if ($adbState -eq 'offline') { [void](Invoke-Exe $adb "disconnect $serial" 4000) }
                    $r = Invoke-Exe $adb "connect $serial" 7000
                    $adbState = Get-SerialState $serial
                    if ($adbState -ne 'device' -and $emuState -ne 'device' -and ((Get-Date) - $s.Probe).TotalSeconds -ge 20) {
                        $s.Probe = Get-Date
                        $lp = Get-LdSerialPort $inst.Index
                        if ($lp -gt 0 -and $lp -ne $port) {
                            Write-Log "#$($inst.Index) $($inst.Name) -> พอร์ตจริงคือ $lp (ไม่ใช่ $port)"
                            $s.LdPort = $lp
                            $port = $lp
                            $serial = "127.0.0.1:$port"
                            $emu = "emulator-$($port - 1)"
                            $useSerial = $serial
                            $emuState = [string]$devs[$emu]
                            $r = Invoke-Exe $adb "connect $serial" 7000
                            $adbState = Get-SerialState $serial
                        } elseif ($lp -eq $port) { $s.LdPort = $lp }
                    }
                    if ($adbState -eq 'device') {
                        $s.Last = "$((Get-Date).ToString('HH:mm:ss')) เชื่อมสำเร็จ"
                        Write-Log "#$($inst.Index) $($inst.Name) -> เชื่อม $serial สำเร็จ"
                    } elseif ($emuState -ne 'device') {
                        $s.Fail++
                        $s.Last = "$((Get-Date).ToString('HH:mm:ss')) ล้มเหลว x$($s.Fail)"
                        if ($s.Fail -le 3 -or ($s.Fail % 20) -eq 0) {
                            $msg = (($r.Out + ' ' + $r.Err) -replace '\s+', ' ').Trim()
                            Write-Log "#$($inst.Index) $($inst.Name) -> เชื่อม $serial ไม่สำเร็จ ($msg)"
                        }
                    }
                }
                Clear-Busy $key
                if ($adbState -ne 'device' -and $emuState -eq 'device') { $useSerial = $emu; $adbState = 'device' }

                if ($adbState -eq 'device') {
                    $okCount++
                    $s.Fail = 0
                    if (-not $s.WasOk) { $s.WasOk = $true }
                    $s.Serial = $useSerial
                    if ($s.InfoSerial -ne $useSerial) {
                        Set-Busy $key 'กำลังตรวจข้อมูลเครื่อง...'
                        $v = Invoke-Exe $adb "-s $useSerial shell getprop ro.build.version.release" 5000
                        $ver = ($v.Out + '').Trim()
                        $s.Info = if ($ver) { "Android $ver" } else { '' }
                        $s.Root = Test-Root $useSerial
                        $s.InfoSerial = $useSerial
                        Clear-Busy $key
                    }
                } elseif ($s.WasOk) {
                    $s.WasOk = $false
                    Write-Log "#$($inst.Index) $($inst.Name) -> การเชื่อมต่อหลุด จะต่อใหม่อัตโนมัติ"
                }
            }

            $adbText = switch ($adbState) {
                'device'       { 'เชื่อมแล้ว ✔' }
                'offline'      { 'offline' }
                'unauthorized' { 'unauthorized' }
                default        { 'ยังไม่เชื่อม' }
            }

            $rows.Add([pscustomobject]@{
                Index   = $inst.Index
                Name    = $inst.Name
                Port    = $port
                Serial  = $useSerial
                Adb     = $adbText
                AdbOk   = ($adbState -eq 'device')
                Status  = $(if ($s.Hold) { 'พักการเชื่อม' } else { 'พร้อมใช้งาน' })
                Running = $running
                Root    = $s.Root
                Info    = $s.Info
                Last    = $s.Last
            })
        }

        # ถ้าเปิดอยู่แต่ต่อไม่ได้เลยสักเครื่อง 3 รอบติด -> รีสตาร์ท server
        if ($Sync.Auto -and $runningCount -gt 0 -and $okCount -eq 0) { $script:globalFail++ } else { $script:globalFail = 0 }
        if ($script:globalFail -ge 3) {
            Write-Log 'เชื่อมไม่ได้เลยสักเครื่อง 3 รอบติดกัน -> รีสตาร์ท ADB server'
            Restart-AdbServer
            $script:globalFail = 0
        }

        $Sync.Snapshot = $rows.ToArray()
        $Sync.Summary = "LD เปิดอยู่ $runningCount เครื่อง  ·  เชื่อม ADB แล้ว $okCount"
        $Sync.Version = $Sync.Version + 1
    }

    Write-Log 'เริ่มทำงาน'
    while (-not $Sync.Stop) {
        try {
            if (-not $Sync.PathOk) {
                $Sync.Summary = 'ไม่พบ ldconsole.exe / adb.exe — กรุณาเลือกโฟลเดอร์ LDPlayer9'
                $Sync.Version = $Sync.Version + 1
            } else {
                $c = $null
                while ($Sync.Commands.TryDequeue([ref]$c)) {
                    try { Invoke-UiCommand $c } catch { Write-Log "คำสั่งผิดพลาด: $($_.Exception.Message)" }
                }
                if ($Sync.AdbStopped) {
                    $Sync.Snapshot = @()
                    $Sync.Summary = 'ADB หยุดอยู่ (กด Start ADB เพื่อเริ่ม)'
                    $Sync.Version = $Sync.Version + 1
                } elseif ($Sync.Paused) {
                    $Sync.Summary = 'ปิดการสแกน ADB อยู่ (เครื่องในตารางยังสั่งงานได้) · กดปุ่ม "ADB" บนหัวโปรแกรมเพื่อเปิดสแกน'
                } else {
                    Invoke-Cycle
                }
            }
        } catch {
            Write-Log "ผิดพลาด: $($_.Exception.Message)"
        }
        $until = (Get-Date).AddSeconds([Math]::Max(1, [int]$Sync.Interval))
        while (-not $Sync.Stop -and (Get-Date) -lt $until -and $Sync.Commands.IsEmpty) {
            Start-Sleep -Milliseconds 200
        }
    }
}

# ================================================================
#  UI
# ================================================================
# --- Design tokens ---
# ---- ธีม: dark (เดิม) / light ----
# light = แปลงสีชุด dark ทุกสีเป็นสีสว่างอัตโนมัติ (พื้นมืด -> พื้นสว่าง, ตัวหนังสือสว่าง -> ตัวเข้ม, สีเน้นคงไว้)
$script:LightTheme = ([string]$cfg.Theme -eq 'light')
$script:RgbCache = @{}
function Convert-ToLight([int]$r, [int]$g, [int]$b) {
    # (PowerShell names ignore case: use fr/fg/fb, not R/G/B)
    $fr = $r / 255.0; $fg = $g / 255.0; $fb = $b / 255.0
    $mx = [Math]::Max($fr, [Math]::Max($fg, $fb)); $mn = [Math]::Min($fr, [Math]::Min($fg, $fb))
    $L = ($mx + $mn) / 2; $d = $mx - $mn
    $S = if ($d -eq 0) { 0 } else { $d / (1 - [Math]::Abs(2 * $L - 1)) }
    $hue = 0
    if ($d -ne 0) {
        if ($mx -eq $fr) { $hue = (($fg - $fb) / $d) % 6 } elseif ($mx -eq $fg) { $hue = ($fb - $fr) / $d + 2 } else { $hue = ($fr - $fg) / $d + 4 }
        $hue = $hue * 60; if ($hue -lt 0) { $hue += 360 }
    }
    if ($d -lt 0.12) { $L2 = if ($L -lt 0.3) { 1 - $L * 0.62 } elseif ($L -lt 0.5) { 0.62 } else { [Math]::Max(0.1, (1 - $L) * 0.9 + 0.05) } }   # greys: flip (mid greys = hint text -> readable grey)
    elseif ($L -lt 0.25) { $L2 = 0.93 - $L * 0.3; $S = [Math]::Min($S, 0.65) }                                           # dark tinted fills -> light tint
    elseif ($L -gt 0.55) { $L2 = $L * 0.72 }                                                                                 # bright text colours -> darker
    else { $L2 = $L }                                                                                                        # mid accents stay
    $C = (1 - [Math]::Abs(2 * $L2 - 1)) * $S; $xx = $C * (1 - [Math]::Abs((($hue / 60) % 2) - 1)); $m = $L2 - $C / 2
    $rr = 0; $gg = 0; $bb = 0
    switch ([int][Math]::Floor($hue / 60)) { 0 { $rr = $C; $gg = $xx } 1 { $rr = $xx; $gg = $C } 2 { $gg = $C; $bb = $xx } 3 { $gg = $xx; $bb = $C } 4 { $rr = $xx; $bb = $C } default { $rr = $C; $bb = $xx } }
    return @([int][Math]::Round(($rr + $m) * 255), [int][Math]::Round(($gg + $m) * 255), [int][Math]::Round(($bb + $m) * 255))
}
$script:DarkSet = @{}     # dark colour (argb) -> r,g,b   (every colour made by New-Rgb)
$script:LightBack = @{}   # light colour (argb) -> original dark r,g,b
function New-RgbDark([int]$r, [int]$g, [int]$b) { return [System.Drawing.Color]::FromArgb($r, $g, $b) }
function New-Rgb([int]$r, [int]$g, [int]$b) {
    $dk = [System.Drawing.Color]::FromArgb($r, $g, $b)
    $ak = $dk.ToArgb()
    if (-not $script:DarkSet.ContainsKey($ak)) { $script:DarkSet[$ak] = @($r, $g, $b) }
    if (-not $script:LightTheme) { return $dk }
    $k = ($r * 65536) + ($g * 256) + $b
    $c = $script:RgbCache[$k]
    if ($null -eq $c) {
        $t = Convert-ToLight $r $g $b
        $c = [System.Drawing.Color]::FromArgb([Math]::Max(0, [Math]::Min(255, $t[0])), [Math]::Max(0, [Math]::Min(255, $t[1])), [Math]::Max(0, [Math]::Min(255, $t[2])))
        $script:RgbCache[$k] = $c
        $script:LightBack[$c.ToArgb()] = @($r, $g, $b)
    }
    return $c
}
$uiBg         = New-Rgb 13 17 23
$uiSurface    = New-Rgb 22 27 34
$uiSurface2   = New-Rgb 31 37 46
$uiInput      = New-Rgb 15 19 25
$uiInputBad   = New-Rgb 58 26 30
$uiLogBg      = New-Rgb 11 14 19
$uiBorder     = New-Rgb 48 54 64
$uiGrid       = New-Rgb 36 42 51
$uiHover      = New-Rgb 28 34 43
$uiSel        = New-Rgb 31 48 71
$uiInk        = New-Rgb 230 237 243
$uiMuted      = New-Rgb 139 148 158
$uiFaint      = New-Rgb 98 106 117
$uiAccent     = New-Rgb 47 129 247
$uiAccentText = New-Rgb 121 192 255
$uiLine       = New-Rgb 0 185 84
$uiOk         = New-Rgb 63 185 80
$uiWarn       = New-Rgb 227 179 65
$uiBad        = New-Rgb 248 81 73
$uiWhite      = [System.Drawing.Color]::White
$uiOnSel      = if ($script:LightTheme) { $uiInk } else { $uiWhite }   # text on a selected / highlighted fill

$font          = New-Object System.Drawing.Font('Tahoma', 9.75)
$fontBold      = New-Object System.Drawing.Font('Tahoma', 9.75, [System.Drawing.FontStyle]::Bold)
$fontSmall     = New-Object System.Drawing.Font('Tahoma', 8.75)
$fontSmallBold = New-Object System.Drawing.Font('Tahoma', 8.75, [System.Drawing.FontStyle]::Bold)
$fontTitle     = New-Object System.Drawing.Font('Tahoma', 14, [System.Drawing.FontStyle]::Bold)
$fontLogo      = New-Object System.Drawing.Font('Tahoma', 11, [System.Drawing.FontStyle]::Bold)
$tfCenter = [System.Windows.Forms.TextFormatFlags]'HorizontalCenter, VerticalCenter, SingleLine, NoPrefix'
$tfLeft   = [System.Windows.Forms.TextFormatFlags]'Left, VerticalCenter, SingleLine, EndEllipsis, NoPrefix'
$tfMulti  = [System.Windows.Forms.TextFormatFlags]'HorizontalCenter, VerticalCenter, WordBreak, NoPrefix'

# --- Native helpers: dark title bar + dark menus (fallback silently if unavailable) ---
try {
    Add-Type -Name DwmUi -Namespace LdAdb -MemberDefinition @'
[DllImport("dwmapi.dll")] private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int size);
[DllImport("user32.dll")] private static extern bool SetWindowPos(IntPtr h, IntPtr a, int x, int y, int cx, int cy, uint f);
public static void Dark(IntPtr hwnd, int caption) {
    int on = 1;
    if (DwmSetWindowAttribute(hwnd, 20, ref on, 4) != 0) { DwmSetWindowAttribute(hwnd, 19, ref on, 4); }
    DwmSetWindowAttribute(hwnd, 35, ref caption, 4);
    SetWindowPos(hwnd, IntPtr.Zero, 0, 0, 0, 0, 0x0027);
}
[DllImport("user32.dll")] private static extern IntPtr SendMessage(IntPtr h, int msg, IntPtr w, IntPtr l);
public static void Redraw(IntPtr hwnd, bool on) { SendMessage(hwnd, 0x000B, (IntPtr)(on ? 1 : 0), IntPtr.Zero); }
public static void Light(IntPtr hwnd) {
    int off = 0; int def = unchecked((int)0xFFFFFFFF);
    if (DwmSetWindowAttribute(hwnd, 20, ref off, 4) != 0) { DwmSetWindowAttribute(hwnd, 19, ref off, 4); }
    DwmSetWindowAttribute(hwnd, 35, ref def, 4);
    SetWindowPos(hwnd, IntPtr.Zero, 0, 0, 0, 0, 0x0027);
}
'@ -ErrorAction Stop
} catch {}
try {
    Add-Type -ReferencedAssemblies System.Windows.Forms, System.Drawing -ErrorAction Stop -TypeDefinition @'
using System.Drawing;
using System.Windows.Forms;
namespace LdAdb {
    public class DarkMenuColors : ProfessionalColorTable {
        public static Color Bg = Color.FromArgb(22, 27, 34);
        public static Color Hi = Color.FromArgb(33, 50, 74);
        public static Color Bd = Color.FromArgb(48, 54, 64);
        public static Color Off = Color.FromArgb(98, 106, 117);
        public override Color ToolStripDropDownBackground { get { return Bg; } }
        public override Color ImageMarginGradientBegin { get { return Bg; } }
        public override Color ImageMarginGradientMiddle { get { return Bg; } }
        public override Color ImageMarginGradientEnd { get { return Bg; } }
        public override Color MenuBorder { get { return Bd; } }
        public override Color MenuItemBorder { get { return Hi; } }
        public override Color MenuItemSelected { get { return Hi; } }
        public override Color MenuItemSelectedGradientBegin { get { return Hi; } }
        public override Color MenuItemSelectedGradientEnd { get { return Hi; } }
        public override Color SeparatorDark { get { return Bd; } }
        public override Color SeparatorLight { get { return Bd; } }
    }
    public class DarkMenuRenderer : ToolStripProfessionalRenderer {
        public DarkMenuRenderer() : base(new DarkMenuColors()) { RoundedEdges = false; }
        protected override void OnRenderItemText(ToolStripItemTextRenderEventArgs e) {
            e.TextColor = e.Item.Enabled ? e.Item.ForeColor : DarkMenuColors.Off;
            base.OnRenderItemText(e);
        }
    }
}
'@
} catch {}

# --- Drawing helpers ---
# คำอธิบายเวลาเอาเมาส์ชี้ (บอกว่าแต่ละอย่างใช้ทำอะไร / ต้องกรอกอะไร)
$script:Tip = New-Object System.Windows.Forms.ToolTip
$script:Tip.AutoPopDelay = 20000; $script:Tip.InitialDelay = 350; $script:Tip.ReshowDelay = 100; $script:Tip.ShowAlways = $true
function Set-Tip($ctl, [string]$text) { if ($ctl -and $text) { try { $script:Tip.SetToolTip($ctl, $text) } catch {} } }
$script:DlgTips = @{
    'ชื่อรายการ'                 = "ตั้งชื่อชุดคำสั่งที่ใช้บ่อย แล้วกด 'บันทึกรายการ'`r`nครั้งหน้าเลือกชื่อจากรายการ ค่าทั้งหมดจะถูกใส่ให้เอง"
    'ใช้ ID ของแต่ละชุด'          = "เลือกว่าจะเพิ่ม ID ช่องไหนของแต่ละชุด (หน้า 'ชุด ID')`r`nทุกช่อง = ใช้ทุกช่องที่กรอก · เฉพาะ Line@ / เฉพาะ Line = ใช้ช่องเดียว`r`nชุดที่ช่องนั้นว่างจะถูกข้าม"
    'หลังเพิ่ม ID แล้ว'           = "เพิ่ม ID เสร็จแล้วให้ทำอะไรต่อ`r`nเช่น สร้างกลุ่มแล้วใส่ชื่อ ID ที่สแกนได้ หรือจบแค่เพิ่ม ID"
    'เริ่มทีละเครื่อง ห่างกัน'     = "กันการแอดพร้อมกันหลายจอ: ใส่จำนวนวินาทีที่ให้เว้นก่อนเริ่มเครื่องถัดไป (0 = เริ่มพร้อมกัน)`r`nติ๊ก 'รอเครื่องก่อนหน้าทำเสร็จก่อน' = ทำทีละจอจริงๆ"
    'ติ๊กวงกลม'                  = "ถึงล่างสุด = ติ๊กทุกคนในรายการ · ตามจำนวน = ติ๊กเท่าจำนวนที่ใส่`r`nคนที่เป็นสีเขียวอยู่แล้วจะไม่ติ๊กซ้ำ"
    'ค้นหาชื่อก่อนติ๊กวงกลม'       = "ใส่ชื่อ (หรือ 3 ตัวแรกของชื่อ) ที่อยากให้ติ๊กก่อน`r`nระบบพิมพ์ในช่องค้นหาแล้วติ๊กคนแรกที่เจอ ชื่อละ 1 คน จากนั้นค่อยติ๊กวงกลมตามปกติ"
    'ไม่ติ๊กวงกลมชื่อเหล่านี้'      = "ใส่ชื่อที่ห้ามติ๊ก (ได้ 2 ชื่อ) ถ้าชื่อในรายการมีคำนี้อยู่จะถูกข้าม`r`nใช้ทั้งตอนค้นหาชื่อและตอนติ๊กวงกลม"
    'เลือกกลุ่มที่สมาชิกไม่เกิน'    = "งานเชิญเข้ากลุ่ม: จะเลือกกลุ่มที่จำนวนสมาชิกไม่เกินเลขนี้"
}
function Set-DoubleBuffered($c) {
    try { $c.GetType().GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]'NonPublic, Instance').SetValue($c, $true, $null) } catch {}
}
function Set-DarkTitle($f) {
    if ($script:LightTheme) { return }   # light theme: normal Windows title bar
    $f.Add_HandleCreated({ try { [LdAdb.DwmUi]::Dark($this.Handle, 0x0017110D) } catch {} })
}
if ($script:LightTheme) {
    try { [LdAdb.DarkMenuColors]::Bg = (New-Rgb 22 27 34); [LdAdb.DarkMenuColors]::Hi = (New-Rgb 33 50 74); [LdAdb.DarkMenuColors]::Bd = (New-Rgb 48 54 64); [LdAdb.DarkMenuColors]::Off = (New-Rgb 98 106 117) } catch {}
}
function Set-DarkMenu($menu) {
    try { $menu.Renderer = New-Object LdAdb.DarkMenuRenderer } catch {}
    $menu.BackColor = $uiSurface
    $menu.ForeColor = $uiInk
    $menu.Font = $font
    try { $menu.ShowImageMargin = $false } catch {}
}
function New-RoundPath([float]$x, [float]$y, [float]$w, [float]$h, [float]$rad) {
    $p = New-Object System.Drawing.Drawing2D.GraphicsPath
    [float]$d = [Math]::Min([double]($rad * 2), [Math]::Min([double]$w, [double]$h))
    if ($d -le 1) { $p.AddRectangle((New-Object System.Drawing.RectangleF($x, $y, $w, $h))); return $p }
    [float]$r = $x + $w - $d
    [float]$b = $y + $h - $d
    $p.AddArc($x, $y, $d, $d, 180, 90)
    $p.AddArc($r, $y, $d, $d, 270, 90)
    $p.AddArc($r, $b, $d, $d, 0, 90)
    $p.AddArc($x, $b, $d, $d, 90, 90)
    $p.CloseFigure()
    return $p
}
function Fill-Round($g, $fill, [float]$x, [float]$y, [float]$w, [float]$h, [float]$rad, $border = $null) {
    if ($w -lt 2 -or $h -lt 2) { return }   # window minimized / too small: nothing to draw
    $path = New-RoundPath $x $y $w $h $rad
    if ($null -ne $fill) { $br = New-Object System.Drawing.SolidBrush($fill); $g.FillPath($br, $path); $br.Dispose() }
    if ($null -ne $border) { $pen = New-Object System.Drawing.Pen($border, 1); $g.DrawPath($pen, $path); $pen.Dispose() }
    $path.Dispose()
}
function New-AppIcon {
    try {
        $bmp = New-Object System.Drawing.Bitmap(32, 32)
        $g = [System.Drawing.Graphics]::FromImage($bmp)
        $g.SmoothingMode = 'AntiAlias'
        $g.TextRenderingHint = 'AntiAliasGridFit'
        $rect = New-Object System.Drawing.Rectangle(0, 0, 32, 32)
        $lg = New-Object System.Drawing.Drawing2D.LinearGradientBrush($rect, $uiAccent, $uiLine, [float]45)
        $path = New-RoundPath 0 0 31 31 8
        $g.FillPath($lg, $path)
        $sf = New-Object System.Drawing.StringFormat
        $sf.Alignment = 'Center'; $sf.LineAlignment = 'Center'
        $f = New-Object System.Drawing.Font('Tahoma', 11, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
        $g.DrawString('LD', $f, [System.Drawing.Brushes]::White, (New-Object System.Drawing.RectangleF(0, 1, 32, 32)), $sf)
        $g.Dispose(); $lg.Dispose(); $path.Dispose()
        return [System.Drawing.Icon]::FromHandle($bmp.GetHicon())
    } catch { return [System.Drawing.SystemIcons]::Application }
}
$script:AppIcon = New-AppIcon

# --- Button styles (custom painted, rounded) ---
$script:BtnKinds = @{
    primary = @{ Bg = $uiAccent; Hover = (New-Rgb 66 145 255); Press = (New-Rgb 31 111 235); Fg = $uiWhite; Border = $null }
    line    = @{ Bg = (New-Rgb 0 160 75); Hover = (New-Rgb 0 180 85); Press = (New-Rgb 0 140 65); Fg = $uiWhite; Border = $null }
    danger  = @{ Bg = (New-Rgb 52 27 31); Hover = (New-Rgb 70 32 37); Press = (New-Rgb 86 36 42); Fg = (New-Rgb 255 123 114); Border = (New-Rgb 92 43 48) }
    ghost   = @{ Bg = $uiSurface2; Hover = (New-Rgb 40 47 58); Press = (New-Rgb 48 56 68); Fg = $uiInk; Border = $uiBorder }
    tab     = @{ Bg = $uiSurface; Hover = $uiSurface2; Press = $uiSurface2; Fg = $uiMuted; Border = $null }
    stop    = @{ Bg = $uiSurface; Hover = (New-Rgb 52 27 31); Press = (New-Rgb 70 32 37); Fg = (New-Rgb 255 123 114); Border = (New-Rgb 92 43 48) }
    scanOn  = @{ Bg = (New-Rgb 22 44 32); Hover = (New-Rgb 26 54 38); Press = (New-Rgb 30 62 44); Fg = (New-Rgb 86 211 130); Border = (New-Rgb 40 92 60) }
    scanOff = @{ Bg = (New-Rgb 28 33 41); Hover = (New-Rgb 36 42 52); Press = (New-Rgb 44 50 62); Fg = $uiMuted; Border = (New-Rgb 48 54 64) }
    tabOn   = @{ Bg = (New-Rgb 33 50 74); Hover = (New-Rgb 36 56 84); Press = (New-Rgb 36 56 84); Fg = $uiOnSel; Border = (New-Rgb 48 82 128) }
}
function Draw-Btn($b, $g) {
    $k = $script:BtnKinds[[string]$b.Tag.Kind]
    $parentBg = if ($b.Parent) { $b.Parent.BackColor } else { $uiBg }
    $g.Clear($parentBg)
    $g.SmoothingMode = 'AntiAlias'
    if (-not $b.Enabled) { $bg = New-Rgb 26 31 38; $fg = $uiFaint; $bd = $uiGrid }
    else {
        $bg = if ($b.Tag.Down) { $k.Press } elseif ($b.Tag.Hot) { $k.Hover } else { $k.Bg }
        $fg = $k.Fg; $bd = $k.Border
    }
    Fill-Round $g $bg 0.5 0.5 ($b.Width - 1.5) ($b.Height - 1.5) 8 $bd
    [System.Windows.Forms.TextRenderer]::DrawText($g, $b.Text, $b.Font, $b.ClientRectangle, $fg, $tfCenter)
}
function Set-BtnKind($b, [string]$kind) { $b.Tag.Kind = $kind; $b.Invalidate() }

function New-Flow {
    $f = New-Object System.Windows.Forms.FlowLayoutPanel
    $f.AutoSize = $true
    $f.AutoSizeMode = 'GrowAndShrink'
    $f.WrapContents = $false
    $f.Margin = New-Object System.Windows.Forms.Padding(0)
    $f.Padding = New-Object System.Windows.Forms.Padding(0)
    return $f
}
function New-Table([string[]]$cols) {
    $t = New-Object System.Windows.Forms.TableLayoutPanel
    $t.AutoSize = $true
    $t.AutoSizeMode = 'GrowAndShrink'
    $t.Dock = 'Fill'
    $t.Margin = New-Object System.Windows.Forms.Padding(0)
    $t.Padding = New-Object System.Windows.Forms.Padding(0)
    $t.RowCount = 1
    $t.ColumnCount = $cols.Count
    [void]$t.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))
    foreach ($c in $cols) {
        if ($c -eq 'Fill') { [void]$t.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) }
        else { [void]$t.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize))) }
    }
    return $t
}
function New-Card([int]$rows) {
    $p = New-Object System.Windows.Forms.TableLayoutPanel
    $p.Dock = 'Fill'
    $p.ColumnCount = 1
    $p.RowCount = $rows
    $p.BackColor = $uiSurface
    $p.Padding = New-Object System.Windows.Forms.Padding(16, 14, 16, 14)
    $p.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 10)
    [void]$p.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100)))
    Set-DoubleBuffered $p
    $p.Add_Paint({
        param($s, $e)
        $g = $e.Graphics
        $g.Clear($s.Parent.BackColor)
        $g.SmoothingMode = 'AntiAlias'
        Fill-Round $g $uiSurface 0.5 0.5 ($s.Width - 1.5) ($s.Height - 1.5) 12 $uiBorder
    })
    $p.Add_Resize({ $this.Invalidate() })
    return $p
}
function New-Label([string]$t) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $t
    $l.AutoSize = $true
    $l.Anchor = 'Left'
    $l.ForeColor = $uiMuted
    $l.Margin = New-Object System.Windows.Forms.Padding(0, 0, 10, 0)
    return $l
}
function New-Btn([string]$t, [scriptblock]$onClick, [string]$kind = 'ghost') {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $t
    $b.AutoSize = $true
    $b.AutoSizeMode = 'GrowOnly'
    $b.MinimumSize = New-Object System.Drawing.Size(0, 34)
    $b.Padding = New-Object System.Windows.Forms.Padding(14, 0, 14, 0)
    $b.Margin = New-Object System.Windows.Forms.Padding(8, 0, 0, 0)
    $b.Anchor = 'Left'
    $b.FlatStyle = 'Flat'
    $b.FlatAppearance.BorderSize = 0
    $b.UseVisualStyleBackColor = $false
    $b.Font = $fontBold
    $b.Cursor = [System.Windows.Forms.Cursors]::Hand
    $b.Tag = @{ Kind = $kind; Hot = $false; Down = $false }
    Set-DoubleBuffered $b
    $b.Add_Paint({ param($s, $e) Draw-Btn $s $e.Graphics })
    $b.Add_MouseEnter({ $this.Tag.Hot = $true; $this.Invalidate() })
    $b.Add_MouseLeave({ $this.Tag.Hot = $false; $this.Tag.Down = $false; $this.Invalidate() })
    $b.Add_MouseDown({ $this.Tag.Down = $true; $this.Invalidate() })
    $b.Add_MouseUp({ $this.Tag.Down = $false; $this.Invalidate() })
    if ($onClick) { $b.Add_Click($onClick) }
    return $b
}
function New-InputWrap($ctrl, [int]$width = 0) {
    $w = New-Object System.Windows.Forms.Panel
    $w.Height = 34
    if ($width -gt 0) { $w.Width = $width }
    $w.BackColor = $ctrl.BackColor
    $w.Padding = New-Object System.Windows.Forms.Padding(10, 7, 8, 5)
    $w.Margin = New-Object System.Windows.Forms.Padding(0)
    $w.Tag = @{ Ctrl = $ctrl; Focus = $false }
    $ctrl.BorderStyle = 'None'
    $ctrl.Dock = 'Fill'
    $w.Controls.Add($ctrl)
    Set-DoubleBuffered $w
    $w.Add_Paint({
        param($s, $e)
        $g = $e.Graphics
        $g.Clear($s.Parent.BackColor)
        $g.SmoothingMode = 'AntiAlias'
        $bd = if ($s.Tag.Focus) { $uiAccent } elseif ($s.Tag.Ctrl.BackColor -eq $uiInputBad) { $uiBad } else { $uiBorder }
        Fill-Round $g $s.Tag.Ctrl.BackColor 0.5 0.5 ($s.Width - 1.5) ($s.Height - 1.5) 8 $bd
    })
    $w.Add_Resize({ $this.Invalidate() })
    $ctrl.Add_Enter({ $this.Parent.Tag.Focus = $true; $this.Parent.Invalidate() })
    $ctrl.Add_Leave({ $this.Parent.Tag.Focus = $false; $this.Parent.Invalidate() })
    $ctrl.Add_BackColorChanged({ if ($this.Parent) { $this.Parent.BackColor = $this.BackColor; $this.Parent.Invalidate() } })
    return $w
}

# --- Form ---
$form = New-Object System.Windows.Forms.Form
# ---- เวอร์ชันโปรแกรม (เปลี่ยนทุกครั้งที่ส่งไฟล์ใหม่) ----
$script:AppVersion = 'v2026.10.26 #4'
$form.Text = "LineDeck  |  ADB Manager  |  $($script:AppVersion)"
# wide + short layout: default 1400 x 600 (shrinks to fit the screen)
$wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$defW = [Math]::Max(760, [Math]::Min(900, $wa.Width - 40))
$defH = [Math]::Max(440, [Math]::Min(600, $wa.Height - 40))
$form.MinimumSize = New-Object System.Drawing.Size(720, 420)
$form.Size = New-Object System.Drawing.Size($defW, $defH)
$form.StartPosition = 'CenterScreen'
# old tall layout -> ignore the old saved size once, hide the ADB settings card if the folder is already set
if ([int]$cfg.LayoutVer -lt 2) {
    $cfg.WinW = 0; $cfg.WinH = 0
    if ([string]$cfg.LdDir) { $cfg.ShowSettings = $false }
    $cfg.LayoutVer = 2
}
if ([int]$cfg.LayoutVer -lt 4) { $cfg.WinW = 0; $cfg.WinH = 0; $cfg.LayoutVer = 4 }   # narrower default width
# restore last window size / position (only if still on a connected screen)
try {
    if ([int]$cfg.WinW -ge 720 -and [int]$cfg.WinH -ge 420) {
        $form.Size = New-Object System.Drawing.Size([int]$cfg.WinW, [int]$cfg.WinH)
        $savedRect = New-Object System.Drawing.Rectangle([int]$cfg.WinX, [int]$cfg.WinY, [int]$cfg.WinW, [int]$cfg.WinH)
        $onScreen = $false
        foreach ($scr in [System.Windows.Forms.Screen]::AllScreens) { if ($scr.WorkingArea.IntersectsWith($savedRect)) { $onScreen = $true } }
        if ($onScreen) {
            $form.StartPosition = 'Manual'
            $form.Location = New-Object System.Drawing.Point([int]$cfg.WinX, [int]$cfg.WinY)
        }
    }
} catch {}
$form.Font = $font
$form.BackColor = $uiBg
$form.ForeColor = $uiInk
$form.Icon = $script:AppIcon
$form.AutoScaleMode = 'Dpi'
Set-DarkTitle $form
Set-DoubleBuffered $form

$layout = New-Object System.Windows.Forms.TableLayoutPanel
$layout.Dock = 'Fill'
$layout.ColumnCount = 1
$layout.RowCount = 4
$layout.BackColor = $uiBg
$layout.Padding = New-Object System.Windows.Forms.Padding(12, 4, 12, 2)
[void]$layout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100)))
[void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100)))
[void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))
$form.Controls.Add($layout)

# --- Header: logo, title, live stat chips ---
$script:hdrSig = ''
$header = New-Object System.Windows.Forms.Panel
$header.Dock = 'Fill'
$header.Height = 42
$header.BackColor = $uiBg
$header.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 4)
$header.Padding = New-Object System.Windows.Forms.Padding(0, 5, 0, 5)
Set-DoubleBuffered $header
$header.Add_Paint({
    param($s, $e)
    $g = $e.Graphics
    $g.SmoothingMode = 'AntiAlias'
    $h = $s.Height
    $sz = 32
    $y = [int](($h - $sz) / 2)
    $rect = New-Object System.Drawing.Rectangle(0, $y, $sz, $sz)
    $lg = New-Object System.Drawing.Drawing2D.LinearGradientBrush($rect, $uiAccent, $uiLine, [float]45)
    $path = New-RoundPath 0 $y $sz $sz 10
    $g.FillPath($lg, $path); $lg.Dispose(); $path.Dispose()
    [System.Windows.Forms.TextRenderer]::DrawText($g, 'LD', $fontLogo, $rect, $uiWhite, $tfCenter)
    $tx = $sz + 12
    [System.Windows.Forms.TextRenderer]::DrawText($g, (T 'LineDeck'), $fontTitle, (New-Object System.Drawing.Rectangle($tx, ($y - 5), 400, 26)), $uiInk, $tfLeft)
    [System.Windows.Forms.TextRenderer]::DrawText($g, (T 'ADB Manager  ·  LINE Automation'), $fontSmall, (New-Object System.Drawing.Rectangle($tx + 1, ($y + 18), 400, 20)), $uiMuted, $tfLeft)
})
$header.Add_Resize({ $this.Invalidate() })
$btnToggleSettings = New-Btn '⚙  ตั้งค่า' {
    Show-Page 'settings'
    Save-Config
} 'ghost'
$btnToggleSettings.Dock = 'Right'
# ---- สลับธีม (มีผลหลังเปิดโปรแกรมใหม่ ระบบเปิดใหม่ให้เอง) ----
# ---- สลับธีมทันที (ไม่ต้องเปิดโปรแกรมใหม่): แปลงสีของทุกหน้าจอที่เปิดอยู่ ----
$script:ThemeMemo = @{}
function Convert-ThemeColor($c, [bool]$toLight) {
    if ($null -eq $c -or $c.IsEmpty -or $c.A -eq 0) { return $c }
    $mk = "$([int]$toLight):$($c.ToArgb())"
    $hit = $script:ThemeMemo[$mk]
    if ($null -ne $hit) { return $hit }
    $res = Convert-ThemeColorCore $c $toLight
    $script:ThemeMemo[$mk] = $res
    return $res
}
function Convert-ThemeColorCore($c, [bool]$toLight) {
    $a = $c.A
    $k = [System.Drawing.Color]::FromArgb(255, $c.R, $c.G, $c.B).ToArgb()
    if ($toLight) {
        if (-not $script:DarkSet.ContainsKey($k)) { return $c }          # not one of our dark colours (e.g. white text)
        $rgb = $script:DarkSet[$k]
        $t = Convert-ToLight $rgb[0] $rgb[1] $rgb[2]
        $n = [System.Drawing.Color]::FromArgb($a, [Math]::Max(0, [Math]::Min(255, $t[0])), [Math]::Max(0, [Math]::Min(255, $t[1])), [Math]::Max(0, [Math]::Min(255, $t[2])))
        $script:LightBack[[System.Drawing.Color]::FromArgb(255, $n.R, $n.G, $n.B).ToArgb()] = $rgb
        return $n
    }
    if (-not $script:LightBack.ContainsKey($k)) { return $c }
    $rgb = $script:LightBack[$k]
    return [System.Drawing.Color]::FromArgb($a, $rgb[0], $rgb[1], $rgb[2])
}
function Convert-GridTheme($g, [bool]$toLight) {
    foreach ($st in @($g.DefaultCellStyle, $g.ColumnHeadersDefaultCellStyle, $g.RowHeadersDefaultCellStyle, $g.AlternatingRowsDefaultCellStyle, $g.RowsDefaultCellStyle)) {
        if ($null -eq $st) { continue }
        $st.BackColor = Convert-ThemeColor $st.BackColor $toLight; $st.ForeColor = Convert-ThemeColor $st.ForeColor $toLight
        $st.SelectionBackColor = Convert-ThemeColor $st.SelectionBackColor $toLight
        $st.SelectionForeColor = $(if ($st.SelectionForeColor.ToArgb() -eq $uiOnSel.ToArgb()) { $(if ($toLight) { Convert-ThemeColor (New-RgbDark 230 237 243) $true } else { [System.Drawing.Color]::White }) } else { Convert-ThemeColor $st.SelectionForeColor $toLight })
    }
    $g.GridColor = Convert-ThemeColor $g.GridColor $toLight
    $g.BackgroundColor = Convert-ThemeColor $g.BackgroundColor $toLight
    foreach ($col in $g.Columns) { $cs = $col.DefaultCellStyle; if ($cs) { $cs.BackColor = Convert-ThemeColor $cs.BackColor $toLight; $cs.ForeColor = Convert-ThemeColor $cs.ForeColor $toLight } }
    if ($g.Rows.Count -le 300) {
        foreach ($row in $g.Rows) {
            foreach ($cell in $row.Cells) {
                if (-not $cell.HasStyle) { continue }
                $nb = Convert-ThemeColor $cell.Style.BackColor $toLight; if ($nb -ne $cell.Style.BackColor) { $cell.Style.BackColor = $nb }
                $nf = Convert-ThemeColor $cell.Style.ForeColor $toLight; if ($nf -ne $cell.Style.ForeColor) { $cell.Style.ForeColor = $nf }
            }
        }
    }
}
function Convert-ControlTheme($root, [bool]$toLight) {
    $stack = New-Object System.Collections.Stack
    $stack.Push($root)
    while ($stack.Count) {
        $c = $stack.Pop()
        try { $nb = Convert-ThemeColor $c.BackColor $toLight; if ($nb -ne $c.BackColor) { $c.BackColor = $nb } } catch {}
        try { $nf = Convert-ThemeColor $c.ForeColor $toLight; if ($nf -ne $c.ForeColor) { $c.ForeColor = $nf } } catch {}
        if ($c -is [System.Windows.Forms.DataGridView]) { try { Convert-GridTheme $c $toLight } catch {} }
        if ($c.ContextMenuStrip) { try { Convert-MenuTheme $c.ContextMenuStrip $toLight } catch {} }
        foreach ($ch in $c.Controls) { $stack.Push($ch) }
    }
}
function Convert-MenuTheme($menu, [bool]$toLight) {
    $menu.BackColor = Convert-ThemeColor $menu.BackColor $toLight; $menu.ForeColor = Convert-ThemeColor $menu.ForeColor $toLight
    foreach ($it in $menu.Items) { try { $it.BackColor = Convert-ThemeColor $it.BackColor $toLight; $it.ForeColor = Convert-ThemeColor $it.ForeColor $toLight } catch {} }
}
function Set-WindowTheme($f, [bool]$light) {
    try { if ($light) { [LdAdb.DwmUi]::Light($f.Handle) } else { [LdAdb.DwmUi]::Dark($f.Handle, 0x0017110D) } } catch {}
}
function Set-ThemeLive([bool]$toLight) {
    if ($toLight -eq [bool]$script:LightTheme) { return }
    if ($script:ThemeBusy) { return }
    $script:ThemeBusy = $true
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor
    $forms = @([System.Windows.Forms.Application]::OpenForms)
    foreach ($f in $forms) { try { [LdAdb.DwmUi]::Redraw($f.Handle, $false) } catch {} }
    $form.SuspendLayout()
    try {
        # 1) colours of every open window / menu
        foreach ($f in $forms) { Convert-ControlTheme $f $toLight }
        try { Convert-MenuTheme $ctx $toLight } catch {}
        # 2) palette variables + button styles (read at paint time)
        foreach ($n in 'uiBg', 'uiSurface', 'uiSurface2', 'uiInput', 'uiInputBad', 'uiLogBg', 'uiBorder', 'uiGrid', 'uiHover', 'uiSel', 'uiInk', 'uiMuted', 'uiFaint', 'uiAccent', 'uiAccentText', 'uiLine', 'uiOk', 'uiWarn', 'uiBad') {
            $v = Get-Variable -Name $n -Scope Script -ValueOnly
            Set-Variable -Name $n -Scope Script -Value (Convert-ThemeColor $v $toLight)
        }
        $script:SysCardBg = Convert-ThemeColor $script:SysCardBg $toLight
        foreach ($k in @($script:BtnKinds.Keys)) {
            $kd = $script:BtnKinds[$k]
            foreach ($p in @('Bg', 'Hover', 'Press', 'Fg', 'Border')) { if ($null -ne $kd[$p]) { $kd[$p] = Convert-ThemeColor $kd[$p] $toLight } }
        }
        $script:LightTheme = $toLight
        $script:uiOnSel = if ($toLight) { $script:uiInk } else { [System.Drawing.Color]::White }
        $script:BtnKinds['tabOn'].Fg = $script:uiOnSel
        try {
            [LdAdb.DarkMenuColors]::Bg = (New-Rgb 22 27 34); [LdAdb.DarkMenuColors]::Hi = (New-Rgb 33 50 74)
            [LdAdb.DarkMenuColors]::Bd = (New-Rgb 48 54 64); [LdAdb.DarkMenuColors]::Off = (New-Rgb 98 106 117)
        } catch {}
    } finally {
        $form.ResumeLayout()
        foreach ($f in $forms) { try { [LdAdb.DwmUi]::Redraw($f.Handle, $true) } catch {}; Set-WindowTheme $f $toLight; $f.Invalidate($true) }
        $form.Cursor = [System.Windows.Forms.Cursors]::Default
        $script:ThemeBusy = $false
    }
    try { Write-LineJobLog "เปลี่ยนธีมเป็น$(if ($toLight) { 'สว่าง' } else { 'มืด' })แล้ว ($([Math]::Round($sw.Elapsed.TotalSeconds, 1)) วิ)" } catch {}
}
function Switch-Theme([string]$to) {
    if ($to -eq [string]$cfg.Theme -and (($to -eq 'light') -eq [bool]$script:LightTheme)) { return $true }
    try { Set-ThemeLive ($to -eq 'light') } catch { Write-LineJobLog "เปลี่ยนธีมไม่สำเร็จ: $($_.Exception.Message)"; return $false }
    $cfg.Theme = $to
    Save-Config
    try { $btnTheme.Text = $(if ($script:LightTheme) { '☾' } else { '☀' }); $tipTheme.SetToolTip($btnTheme, $(if ($script:LightTheme) { 'เปลี่ยนเป็นธีมมืด (Dark)' } else { 'เปลี่ยนเป็นธีมสว่าง (Light)' })) } catch {}
    try { if ($comboTheme.SelectedIndex -ne $(if ($script:LightTheme) { 1 } else { 0 })) { $comboTheme.SelectedIndex = $(if ($script:LightTheme) { 1 } else { 0 }) } } catch {}
    return $true
}
$btnTheme = New-Btn $(if ($script:LightTheme) { '☾' } else { '☀' }) { [void](Switch-Theme $(if ($script:LightTheme) { 'dark' } else { 'light' })) } 'ghost'
$btnTheme.Dock = 'Right'; $btnTheme.AutoSize = $false; $btnTheme.MinimumSize = New-Object System.Drawing.Size(0, 0)
$btnTheme.Width = 40; $btnTheme.Padding = New-Object System.Windows.Forms.Padding(0)
$tipTheme = New-Object System.Windows.Forms.ToolTip
$tipTheme.SetToolTip($btnTheme, $(if ($script:LightTheme) { 'เปลี่ยนเป็นธีมมืด (Dark)' } else { 'เปลี่ยนเป็นธีมสว่าง (Light)' }))
$btnToggleSettings.Margin = New-Object System.Windows.Forms.Padding(0)
$header.Controls.Add($btnToggleSettings)
$themeGap = New-Object System.Windows.Forms.Panel; $themeGap.Width = 8; $themeGap.Dock = 'Right'; $themeGap.BackColor = $uiBg
$header.Controls.Add($themeGap); $themeGap.BringToFront()
$header.Controls.Add($btnTheme); $btnTheme.BringToFront()
# version badge next to the title (a real label, always visible)
$lblVersion = New-Object System.Windows.Forms.Label
$lblVersion.AutoSize = $true
$lblVersion.Text = $script:AppVersion
$lblVersion.Font = $fontBold
$lblVersion.ForeColor = $uiAccentText
$lblVersion.BackColor = $uiBg
$lblVersion.Location = New-Object System.Drawing.Point((44 + [System.Windows.Forms.TextRenderer]::MeasureText('LineDeck', $fontTitle).Width + 6), 10)
$header.Controls.Add($lblVersion)
$layout.Controls.Add($header, 0, 0)

# --- Settings card ---
$settingsCard = New-Card 2
$settingsCard.AutoSize = $true
$settingsCard.AutoSizeMode = 'GrowAndShrink'
[void]$settingsCard.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$settingsCard.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))

# แถว 1: โฟลเดอร์
$row1 = New-Table @('Auto', 'Fill', 'Auto', 'Auto')
$row1.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 6)
$txtDir = New-Object System.Windows.Forms.TextBox
$txtDir.BackColor = $uiInput
$txtDir.ForeColor = $uiInk
$txtDir.Font = $font
$txtDirWrap = New-InputWrap $txtDir
$txtDirWrap.Anchor = 'Left, Right'
$lblDir = New-Label 'โฟลเดอร์ LD'
$row1.Controls.Add($lblDir, 0, 0)
$row1.Controls.Add($txtDirWrap, 1, 0)
$row1.Controls.Add((New-Btn 'เลือก...' {
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = 'เลือกโฟลเดอร์ที่มี ldconsole.exe และ adb.exe (เช่น C:\LDPlayer\LDPlayer9)'
    if ($txtDir.Text -and (Test-Path $txtDir.Text)) { $dlg.SelectedPath = $txtDir.Text }
    if ($dlg.ShowDialog($form) -eq 'OK') { $txtDir.Text = $dlg.SelectedPath; Apply-Dir }
}), 2, 0)
$row1.Controls.Add((New-Btn 'หาอัตโนมัติ' {
    $d = Find-LdDir
    if ($d) { $txtDir.Text = $d; Apply-Dir }
    else { [void][System.Windows.Forms.MessageBox]::Show($form, 'หาโฟลเดอร์ LDPlayer9 ไม่เจอ กรุณากด "เลือก..." เอง', 'ไม่พบ') }
}), 3, 0)
$settingsCard.Controls.Add($row1, 0, 0)

# แถว 2: ตัวเลือก + ปุ่ม ADB
$row2 = New-Object System.Windows.Forms.FlowLayoutPanel
$row2.Dock = 'Fill'
$row2.AutoSize = $true
$row2.AutoSizeMode = 'GrowAndShrink'
$row2.WrapContents = $true
$row2.Margin = New-Object System.Windows.Forms.Padding(0)
$row2.Padding = New-Object System.Windows.Forms.Padding(0)
$row2Opts = New-Flow
$row2Opts.Margin = New-Object System.Windows.Forms.Padding(0, 0, 18, 0)
$chkAuto = New-Object System.Windows.Forms.CheckBox
$chkAuto.Text = 'เชื่อมต่ออัตโนมัติ'
$chkAuto.AutoSize = $false
$chkAuto.Height = 30
$chkAuto.Width = [System.Windows.Forms.TextRenderer]::MeasureText($chkAuto.Text, $font).Width + 56
$chkAuto.Anchor = 'Left'
$chkAuto.Font = $font
$chkAuto.ForeColor = $uiInk
$chkAuto.Cursor = [System.Windows.Forms.Cursors]::Hand
$chkAuto.Margin = New-Object System.Windows.Forms.Padding(0, 2, 14, 0)
$chkAuto.Checked = [bool]$cfg.Auto
Set-DoubleBuffered $chkAuto
$chkAuto.Add_Paint({
    param($s, $e)
    $g = $e.Graphics
    $g.Clear($s.Parent.BackColor)
    $g.SmoothingMode = 'AntiAlias'
    $tw = 38; $th = 22
    [float]$y = ($s.Height - $th) / 2
    $track = if ($s.Checked) { $uiAccent } else { $uiSurface2 }
    $bd = if ($s.Checked) { $uiAccent } else { $uiBorder }
    Fill-Round $g $track 0.5 $y $tw $th 11 $bd
    [float]$kx = if ($s.Checked) { $tw - 17 } else { 4 }
    $kb = New-Object System.Drawing.SolidBrush($(if ($s.Checked) { $uiWhite } else { $uiMuted }))
    $g.FillEllipse($kb, $kx, [float]($y + 4), [float]14, [float]14); $kb.Dispose()
    [System.Windows.Forms.TextRenderer]::DrawText($g, $s.Text, $s.Font, (New-Object System.Drawing.Rectangle(($tw + 10), 0, ($s.Width - $tw - 10), $s.Height)), $uiInk, $tfLeft)
})
$chkAuto.Add_CheckedChanged({ $Sync.Auto = $chkAuto.Checked; $cfg.Auto = $chkAuto.Checked; Save-Config })
$numInt = New-Object System.Windows.Forms.NumericUpDown
$numInt.Minimum = 1; $numInt.Maximum = 60
$numInt.Value = [Math]::Min(60, [Math]::Max(1, [int]$cfg.Interval))
$numInt.BackColor = $uiInput
$numInt.ForeColor = $uiInk
$numInt.Font = $font
$numInt.TextAlign = 'Center'
$numInt.Add_ValueChanged({ $Sync.Interval = [int]$numInt.Value; $cfg.Interval = [int]$numInt.Value; Save-Config })
$numWrap = New-InputWrap $numInt 78
$numWrap.Anchor = 'Left'
$numWrap.Padding = New-Object System.Windows.Forms.Padding(8, 6, 4, 4)
$lblEvery = New-Label 'ตรวจทุก'
$lblSec = New-Label 'วินาที'
$lblSec.Margin = New-Object System.Windows.Forms.Padding(10, 0, 0, 0)
$lblEvery.Margin = New-Object System.Windows.Forms.Padding(0, 9, 8, 0)
$lblSec.Margin = New-Object System.Windows.Forms.Padding(8, 9, 0, 0)
$numWrap.Width = 70
$row2Opts.Controls.AddRange(@($chkAuto, $lblEvery, $numWrap, $lblSec))
$row2.Controls.Add($row2Opts)

function Get-SelectedIdx { return @($grid.SelectedRows | ForEach-Object { [int]$_.Tag } | Sort-Object) }
function Send-Cmd([string]$type, $idx) {
    $Sync.Commands.Enqueue([pscustomobject]@{ Type = $type; Idx = @($idx) })
}
function Need-Selection {
    $s = Get-SelectedIdx
    if ($s.Count -eq 0) { [void][System.Windows.Forms.MessageBox]::Show($form, 'กรุณาเลือกเครื่องในตารางก่อน (กด Ctrl/Shift เพื่อเลือกหลายเครื่อง)', 'ยังไม่ได้เลือก') }
    return , $s
}

$settingsCard.Controls.Add($row2, 0, 1)
$settingsCard.Padding = New-Object System.Windows.Forms.Padding(12, 8, 12, 8)
$settingsCard.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 6)
$settingsCard.Visible = $false

# --- ตาราง ---
function Set-GridTheme($g) {
    $g.BackgroundColor = $uiSurface
    $g.BorderStyle = 'None'
    $g.GridColor = $uiGrid
    $g.CellBorderStyle = 'SingleHorizontal'
    $g.RowHeadersVisible = $false
    $g.AllowUserToResizeRows = $false
    $g.EnableHeadersVisualStyles = $false
    $g.ColumnHeadersBorderStyle = 'None'
    $g.ColumnHeadersHeightSizeMode = 'DisableResizing'
    $g.ColumnHeadersHeight = 34
    $g.ColumnHeadersDefaultCellStyle.BackColor = $uiSurface
    $g.ColumnHeadersDefaultCellStyle.ForeColor = $uiMuted
    $g.ColumnHeadersDefaultCellStyle.SelectionBackColor = $uiSurface
    $g.ColumnHeadersDefaultCellStyle.SelectionForeColor = $uiMuted
    $g.ColumnHeadersDefaultCellStyle.Font = $fontSmallBold
    $g.ColumnHeadersDefaultCellStyle.Padding = New-Object System.Windows.Forms.Padding(6, 0, 6, 0)
    $g.DefaultCellStyle.BackColor = $uiSurface
    $g.DefaultCellStyle.ForeColor = $uiInk
    $g.DefaultCellStyle.SelectionBackColor = $uiSel
    $g.DefaultCellStyle.SelectionForeColor = $uiOnSel
    $g.DefaultCellStyle.Font = $font
    $g.DefaultCellStyle.Padding = New-Object System.Windows.Forms.Padding(6, 0, 6, 0)
    $g.RowsDefaultCellStyle.BackColor = $uiSurface
    $g.AlternatingRowsDefaultCellStyle.BackColor = $uiSurface
    $g.RowTemplate.Height = 34
    Set-DoubleBuffered $g
    $g.Add_EditingControlShowing({
        param($s, $e)
        $e.Control.BackColor = $uiInput
        $e.Control.ForeColor = $uiInk
    })
    $g.Add_CellMouseEnter({
        param($s, $e)
        if ($e.RowIndex -ge 0 -and $e.RowIndex -lt $s.Rows.Count) { $s.Rows[$e.RowIndex].DefaultCellStyle.BackColor = $uiHover }
    })
    $g.Add_CellMouseLeave({
        param($s, $e)
        if ($e.RowIndex -ge 0 -and $e.RowIndex -lt $s.Rows.Count) { $s.Rows[$e.RowIndex].DefaultCellStyle.BackColor = [System.Drawing.Color]::Empty }
    })
}

$grid = New-Object System.Windows.Forms.DataGridView
$grid.Dock = 'Fill'
$grid.ReadOnly = $false
$grid.EditMode = 'EditOnEnter'
$grid.AllowUserToAddRows = $false
$grid.AllowUserToDeleteRows = $false
$grid.SelectionMode = 'FullRowSelect'
$grid.MultiSelect = $true
Set-GridTheme $grid
$colChk = New-Object System.Windows.Forms.DataGridViewCheckBoxColumn
$colChk.Name = 'Chk'
$colChk.HeaderText = '✔'
$colChk.Width = 40
$colChk.SortMode = 'NotSortable'
$colChk.HeaderCell.Style.Alignment = 'MiddleCenter'
[void]$grid.Columns.Add($colChk)
foreach ($c in @(
        @('Index', '#', 40), @('Adb', '●', 30),
        @('LineName', 'ชื่อ LINE  ✎', 150), @('Friends', 'เพื่อน', 64), @('Groups', 'กลุ่ม', 58),
        @('FG', 'เพื่อน · กลุ่ม', 84), @('Today', 'วันนี้', 112), @('LastSet', 'ชุดล่าสุด', 96),
        @('Status', 'สถานะ / ผลล่าสุด', 260))) {
    $i = $grid.Columns.Add($c[0], $c[1])
    $grid.Columns[$i].Width = $c[2]
    $grid.Columns[$i].SortMode = 'NotSortable'
    $grid.Columns[$i].ReadOnly = $c[0] -ne 'LineName'
}
$grid.Columns['Status'].AutoSizeMode = 'Fill'
$grid.Columns['Status'].MinimumWidth = 170
$ci = $grid.Columns.Add('SortKey', 'SortKey')
$grid.Columns[$ci].Visible = $false
$grid.Columns[$ci].ReadOnly = $true
$grid.Columns[$ci].SortMode = 'Programmatic'
$grid.ScrollBars = 'Both'
$grid.Columns['Index'].DefaultCellStyle.ForeColor = $uiMuted
$grid.Columns['Index'].DefaultCellStyle.Alignment = 'MiddleCenter'
$grid.Columns['Index'].HeaderCell.Style.Alignment = 'MiddleCenter'
$grid.Columns['LineName'].DefaultCellStyle.Font = $fontBold
$grid.Columns['LineName'].DefaultCellStyle.ForeColor = $uiInk
foreach ($cn in @('Friends', 'Groups', 'FG', 'Adb')) {
    $grid.Columns[$cn].DefaultCellStyle.Alignment = 'MiddleCenter'
    $grid.Columns[$cn].HeaderCell.Style.Alignment = 'MiddleCenter'
}
$grid.Columns['FG'].DefaultCellStyle.Font = $fontBold
# friends / groups stay as data, shown together in one column
$grid.Columns['Friends'].Visible = $false
$grid.Columns['Groups'].Visible = $false
# หน้าตารางโชว์แค่ ✔ · # · ADB · สถานะ (ข้อมูลชื่อ/เพื่อน/กลุ่ม/วันนี้/ชุดล่าสุดยังเก็บไว้ แต่ไม่แสดง)
foreach ($cn in 'LineName', 'FG', 'Today', 'LastSet') { $grid.Columns[$cn].Visible = $false }
$grid.Columns['Today'].DefaultCellStyle.ForeColor = $uiAccentText
$grid.Columns['LastSet'].DefaultCellStyle.ForeColor = $uiMuted
$grid.Add_CellPainting({
    param($s, $e)
    if ($e.RowIndex -lt 0 -or $e.ColumnIndex -lt 0) { return }
    $col = $s.Columns[$e.ColumnIndex].Name
    if ($col -eq 'LineName') {
        if ([string]$e.Value) { return }
        $e.PaintBackground($e.CellBounds, $true)
        $b = $e.CellBounds
        [System.Windows.Forms.TextRenderer]::DrawText($e.Graphics, (T 'ยังไม่มีชื่อ · กดดึงข้อมูล LINE'), $fontSmall, (New-Object System.Drawing.Rectangle(($b.X + 8), $b.Y, ($b.Width - 12), $b.Height)), $uiFaint, $tfLeft)
        $e.Handled = $true
        return
    }
    if ($col -ne 'Chk' -and $col -ne 'Adb' -and $col -ne 'Status') { return }
    $e.PaintBackground($e.CellBounds, $true)
    $g = $e.Graphics
    $g.SmoothingMode = 'AntiAlias'
    $b = $e.CellBounds
    if ($col -eq 'Chk') {
        $rt = $s.Rows[$e.RowIndex].Tag
        if ($null -eq $rt) { $e.Handled = $true; return }
        if ($null -ne $rt -and $script:RowActInfo -and $script:RowActInfo.ContainsKey([int]$rt)) {
            $bar = New-Object System.Drawing.SolidBrush($script:ActColors[$script:RowActInfo[[int]$rt].Kind])
            $g.FillRectangle($bar, $b.X, ($b.Y + 4), 4, ($b.Height - 8)); $bar.Dispose()
        }
        $on = ([string]$e.Value -eq 'True')
        $sz = 18
        [float]$x = $b.X + [int](($b.Width - $sz) / 2)
        [float]$y = $b.Y + [int](($b.Height - $sz) / 2)
        if ($on) {
            Fill-Round $g $uiAccent $x $y $sz $sz 5 $uiAccent
            $pen = New-Object System.Drawing.Pen($uiWhite, [float]2)
            $pen.StartCap = 'Round'; $pen.EndCap = 'Round'
            $pts = [System.Drawing.PointF[]]@(
                (New-Object System.Drawing.PointF(($x + 4.5), ($y + 9.5))),
                (New-Object System.Drawing.PointF(($x + 7.5), ($y + 12.5))),
                (New-Object System.Drawing.PointF(($x + 13.5), ($y + 6))))
            $g.DrawLines($pen, $pts); $pen.Dispose()
        } else {
            Fill-Round $g $uiInput $x $y $sz $sz 5 (New-Rgb 72 80 92)
        }
    } elseif ($col -eq 'Adb') {
        $stt = [string]$s.Rows[$e.RowIndex].Cells['Adb'].Tag
        $dc = switch ($stt) { 'off' { New-Rgb 120 128 140 } 'wait' { New-Rgb 227 179 65 } 'bad' { New-Rgb 255 123 114 } default { New-Rgb 86 211 130 } }
        $dot = New-Object System.Drawing.SolidBrush($dc)
        $g.FillEllipse($dot, [float]($b.X + ($b.Width - 10) / 2), [float]($b.Y + ($b.Height - 10) / 2), [float]10, [float]10); $dot.Dispose()
        $e.Handled = $true
        return
        $txt = [string]$e.Value
        if ($txt) {
            $stt = [string]$s.Rows[$e.RowIndex].Cells['Adb'].Tag
            switch ($stt) {
                'off'  { $pbg = New-Rgb 36 41 49; $pfg = New-Rgb 120 128 140 }
                'wait' { $pbg = New-Rgb 58 46 20; $pfg = New-Rgb 227 179 65 }
                'bad'  { $pbg = New-Rgb 66 32 36; $pfg = New-Rgb 255 123 114 }
                default { $pbg = New-Rgb 22 52 36; $pfg = New-Rgb 86 211 130 }
            }
            $tw = [System.Windows.Forms.TextRenderer]::MeasureText($g, $txt, $fontSmallBold, (New-Object System.Drawing.Size(999, 99)), $tfLeft).Width
            $pw = [Math]::Min($tw + 28, $b.Width - 12)
            [float]$px = $b.X + 8
            [float]$py = $b.Y + [int](($b.Height - 24) / 2)
            Fill-Round $g $pbg $px $py $pw 24 12 $null
            $dot = New-Object System.Drawing.SolidBrush($pfg)
            $g.FillEllipse($dot, [float]($px + 9), [float]($py + 9), [float]6, [float]6); $dot.Dispose()
            [System.Windows.Forms.TextRenderer]::DrawText($g, $txt, $fontSmallBold, (New-Object System.Drawing.Rectangle(([int]$px + 19), [int]$py, ($pw - 22), 24)), $pfg, $tfLeft)
        }
    } elseif ($null -ne $s.Rows[$e.RowIndex].Tag -and $script:RowActInfo -and $script:RowActInfo.ContainsKey([int]$s.Rows[$e.RowIndex].Tag)) {
        $ai = $script:RowActInfo[[int]$s.Rows[$e.RowIndex].Tag]
        $ac = $script:ActColors[$ai.Kind]
        $bw = [System.Windows.Forms.TextRenderer]::MeasureText($g, $ai.Badge, $fontSmallBold, (New-Object System.Drawing.Size(999, 99)), $tfLeft).Width + 30
        $bw = [Math]::Min($bw, $b.Width - 12)
        [float]$px = $b.X + 6
        [float]$py = $b.Y + [int](($b.Height - 24) / 2)
        Fill-Round $g ([System.Drawing.Color]::FromArgb(46, $ac)) $px $py $bw 24 12 ([System.Drawing.Color]::FromArgb(110, $ac))
        $dot = New-Object System.Drawing.SolidBrush($ac)
        $g.FillEllipse($dot, [float]($px + 10), [float]($py + 8), [float]8, [float]8); $dot.Dispose()
        [System.Windows.Forms.TextRenderer]::DrawText($g, $ai.Badge, $fontSmallBold, (New-Object System.Drawing.Rectangle(([int]$px + 22), [int]$py, ($bw - 24), 24)), $ac, $tfLeft)
        if ($ai.Detail) {
            $dx = [int]$px + $bw + 8
            [System.Windows.Forms.TextRenderer]::DrawText($g, $ai.Detail, $fontSmall, (New-Object System.Drawing.Rectangle($dx, $b.Y, [Math]::Max(0, $b.Right - $dx - 4), $b.Height)), $uiMuted, $tfLeft)
        }
    } else {
        $txt = [string]$e.Value
        $dc = $e.CellStyle.ForeColor
        if ($dc.IsEmpty) { $dc = $uiMuted }
        $dot = New-Object System.Drawing.SolidBrush($dc)
        $g.FillEllipse($dot, [float]($b.X + 10), [float]($b.Y + $b.Height / 2 - 4), [float]8, [float]8); $dot.Dispose()
        $fnt = if ($e.CellStyle.Font) { $e.CellStyle.Font } else { $font }
        $rtg = $s.Rows[$e.RowIndex].Tag
        if ($null -ne $rtg -and $script:TickedNames.ContainsKey([int]$rtg)) {
            # base status, then the ticked names: duplicates with other LDs in red
            $tfN = [System.Windows.Forms.TextFormatFlags]'Left, VerticalCenter, SingleLine, NoPrefix, NoPadding'
            $x = $b.X + 26; $right = $b.Right - 6
            $segs = New-Object System.Collections.Generic.List[object]
            if ($txt) { $segs.Add(@("$txt  ·  ", $uiInk, $fnt)) }
            $segs.Add(@((T 'ติ๊ก: '), $uiMuted, $fnt))
            $dups = Get-TickDups ([int]$rtg)
            $nl = @($script:TickedNames[[int]$rtg])
            for ($ni = 0; $ni -lt $nl.Count; $ni++) {
                $o = $dups[(Get-NameKey $nl[$ni])]
                $sep = if ($ni -lt $nl.Count - 1) { ', ' } else { '' }
                if ($o) { $segs.Add(@("$($nl[$ni]) (ซ้ำ #$($o -join ',#'))", (New-Rgb 255 90 90), $fontBold)) }
                else { $segs.Add(@($nl[$ni], (New-Rgb 86 211 130), $fnt)) }
                if ($sep) { $segs.Add(@($sep, $uiMuted, $fnt)) }
            }
            foreach ($sg in $segs) {
                if ($x -ge $right) { break }
                $w = [System.Windows.Forms.TextRenderer]::MeasureText($g, [string]$sg[0], $sg[2], (New-Object System.Drawing.Size(9999, 99)), $tfN).Width
                $rw = [Math]::Min($w, $right - $x)
                $ff = if ($rw -lt $w) { [System.Windows.Forms.TextFormatFlags]'Left, VerticalCenter, SingleLine, NoPrefix, NoPadding, EndEllipsis' } else { $tfN }
                [System.Windows.Forms.TextRenderer]::DrawText($g, [string]$sg[0], $sg[2], (New-Object System.Drawing.Rectangle($x, $b.Y, $rw, $b.Height)), $sg[1], $ff)
                $x += $w
            }
        } else {
        [System.Windows.Forms.TextRenderer]::DrawText($g, $txt, $fnt, (New-Object System.Drawing.Rectangle(($b.X + 26), $b.Y, ($b.Width - 32), $b.Height)), $uiInk, $tfLeft)
        }
    }
    $e.Handled = $true
})
$grid.Add_Paint({
    param($s, $e)
    if ($s.Rows.Count -gt 0) { return }
    $r = New-Object System.Drawing.Rectangle(0, $s.ColumnHeadersHeight, $s.Width, ($s.Height - $s.ColumnHeadersHeight))
    [System.Windows.Forms.TextRenderer]::DrawText($e.Graphics, "ยังไม่พบ LDPlayer ที่เชื่อม ADB`r`nเปิด LD แล้วรอสักครู่ ระบบจะค้นหาและเชื่อมให้อัตโนมัติ", $font, $r, $uiFaint, $tfMulti)
})
$grid.Add_Resize({ if ($this.Rows.Count -eq 0) { $this.Invalidate() } })
$grid.Add_ColumnHeaderMouseClick({
    param($s, $e)
    if ($s.Columns[$e.ColumnIndex].Name -ne 'Chk') { return }
    $anyOff = $false
    foreach ($r in $s.Rows) { if ($null -ne $r.Tag -and [string]$r.Cells['Chk'].Value -ne 'True') { $anyOff = $true; break } }
    Set-AllChecked $anyOff
})
$grid.ShowCellToolTips = $true
$grid.Add_CellToolTipTextNeeded({
    param($s, $e)
    if ($e.RowIndex -lt 0) { return }
    $tg = $s.Rows[$e.RowIndex].Tag
    if ($null -eq $tg) { return }
    $li = $cfg.LineInfo[(Get-InfoKey ([int]$tg))]
    $lo = if ($li -and $li.LastOpen) { $li.LastOpen } else { '-' }
    $adbTxt = [string]$s.Rows[$e.RowIndex].Cells['Adb'].Value
    $e.ToolTipText = "LD #$tg | ADB: $adbTxt | เปิดล่าสุด: $lo"
    if ($script:TickedNames -and $script:TickedNames.ContainsKey([int]$tg)) {
        $dd = Get-TickDups ([int]$tg)
        $e.ToolTipText += "`r`nติ๊กจากการค้นหาชื่อ:`r`n" + ((@($script:TickedNames[[int]$tg]) | ForEach-Object { $o = $dd[(Get-NameKey $_)]; if ($o) { "  ✖ $_  (ซ้ำกับ LD #$($o -join ', #'))" } else { "  ✔ $_" } }) -join "`r`n")
    }
})
$script:lineCols = @{ LineName = 'Name' }

$script:checked = @{}
foreach ($ci0 in @($cfg.Checked)) { $script:checked[[int]$ci0] = $true }
$script:InGridUpdate = $false
function Save-Checked {
    if ($script:InGridUpdate) { return }
    $cfg.Checked = @($script:checked.Keys | Where-Object { $script:checked[$_] } | ForEach-Object { [int]$_ } | Sort-Object)
    Save-Config
}
$script:ctxIdx = -1
$script:idleStatus = @{}
$grid.Add_CurrentCellDirtyStateChanged({
    if ($grid.IsCurrentCellDirty) { [void]$grid.CommitEdit([System.Windows.Forms.DataGridViewDataErrorContexts]::Commit) }
})
$grid.Add_CellValueChanged({
    param($sender, $e)
    if ($e.RowIndex -lt 0) { return }
    $colName = $grid.Columns[$e.ColumnIndex].Name
    $r = $grid.Rows[$e.RowIndex]
    if ($null -eq $r.Tag -or $script:InGridUpdate) { return }
    if ($colName -eq 'Chk') {
        $script:checked[[int]$r.Tag] = [bool]$r.Cells['Chk'].Value
        Save-Checked
    } elseif ($script:lineCols.ContainsKey($colName)) {
        # บันทึก ชื่อ LINE / เพื่อน / กลุ่ม ที่แก้ในตาราง
        $k = Get-InfoKey ([int]$r.Tag)
        if (-not $cfg.LineInfo.ContainsKey($k)) { $cfg.LineInfo[$k] = New-InfoRec }
        $cfg.LineInfo[$k][$script:lineCols[$colName]] = [string]$r.Cells[$colName].Value
        Save-Config
        $script:SortDirty = $true
    }
})
$grid.Add_CellMouseDown({
    param($sender, $e)
    if ($e.Button -eq [System.Windows.Forms.MouseButtons]::Right) {
        if ($e.RowIndex -ge 0) {
            $grid.ClearSelection()
            $grid.Rows[$e.RowIndex].Selected = $true
            $rtg = $grid.Rows[$e.RowIndex].Tag
            $script:ctxIdx = if ($null -ne $rtg) { [int]$rtg } else { -1 }
        } else { $script:ctxIdx = -1 }
    }
})

function Get-Targets {
    # Read checkbox cells directly; do not depend on stale checkbox cache or SelectedRows.
    try { [void]$grid.EndEdit() } catch {}
    $found = New-Object 'System.Collections.Generic.HashSet[int]'
    foreach ($row in $grid.Rows) {
        if ($row.IsNewRow -or $null -eq $row.Tag) { continue }
        $idx = [int]$row.Tag
        $v = $row.Cells['Chk'].Value
        $isChecked = ($null -ne $v -and $v -ne [DBNull]::Value -and [string]$v -eq 'True')
        if ($isChecked) { [void]$found.Add($idx) }
        $script:checked[$idx] = $isChecked
    }
    # Only fall back to the right-clicked row if no checkboxes are ticked.
    if ($found.Count -eq 0 -and $script:ctxIdx -ge 0 -and $script:rowMap.ContainsKey([string]$script:ctxIdx)) {
        [void]$found.Add([int]$script:ctxIdx)
    }
    return @($found | Sort-Object)
}
function Invoke-OnTargets([string]$type, [string]$confirm) {
    $tg = Get-Targets
    if ($tg.Count -eq 0) { return }
    if ($confirm) {
        $a = [System.Windows.Forms.MessageBox]::Show($form, "$confirm $($tg.Count) เครื่อง (#$($tg -join ', #')) ?", 'ยืนยัน', 'YesNo', 'Question')
        if ($a -ne 'Yes') { return }
    }
    foreach ($i in $tg) { $Sync.Busy[[int]$i] = 'รอคิว...' }
    Send-Cmd $type $tg
}

# Run the original Adb-LineAddFriend.ps1 as a separate process; keep GUI responsive.
$script:LineJobs = New-Object System.Collections.ArrayList
$script:PairStatePath = Join-Path $PSScriptRoot 'line_pair_progress.json'
$script:PairState = @{ signature=''; next=0; completed=@(); inprogress=@{}; cycle=1; retry=@() }
$script:LineMainStatus = @{}
function Save-PairState {
    $json = ConvertTo-Json -InputObject $script:PairState -Depth 7
    [System.IO.File]::WriteAllText($script:PairStatePath,$json,(New-Object System.Text.UTF8Encoding($false)))
}
function Load-PairState([string]$signature,[int]$count) {
    if ($script:PairState.signature -eq $signature) { return }
    $script:PairState = @{signature=$signature;next=0;completed=@();inprogress=@{};cycle=1;retry=@()}
    if (Test-Path $script:PairStatePath) {
        try {
            $old = Get-Content $script:PairStatePath -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($old.signature -eq $signature) {
                $script:PairState.next = [int]$old.next
                $script:PairState.cycle = [int]$old.cycle
                $script:PairState.completed = @($old.completed)
                # interrupted work is retried instead of silently skipped
                $retry = @($old.retry | Where-Object { $null -ne $_ } | ForEach-Object { [int]$_ })
                if ($old.inprogress) { foreach ($pr in $old.inprogress.PSObject.Properties) { $retry += [int]$pr.Value } }
                $script:PairState.retry = @($retry | Where-Object { $_ -lt $count -and @($script:PairState.completed) -notcontains $_ } | Select-Object -Unique)
                $script:PairState.inprogress = @{}
            }
        } catch {}
    }
}
# --- ลำดับชุด LINE แบบหมุนคิว: ใช้ชุดบนสุดที่ว่าง แล้วย้ายไปท้ายรายการ ---
$script:SetsInUse = @{}
# วันนี้: นับงานต่อเครื่อง (เริ่มนับใหม่ทุกวัน) แสดงในช่อง "วันนี้" ของตาราง
function Add-Stat([int]$idx, [string]$key, [int]$n = 1) {
    $day = (Get-Date).ToString('yyyy-MM-dd')
    if ([string]$cfg.Today.date -ne $day) { $cfg.Today = @{ date = $day; data = @{} } }
    $k = Get-InfoKey $idx
    if (-not $cfg.Today.data.ContainsKey($k)) { $cfg.Today.data[$k] = @{ added = 0; invite = 0; line = 0; select = 0 } }
    $cfg.Today.data[$k][$key] = [int]$cfg.Today.data[$k][$key] + $n
    Save-Config
}
function Get-TodayText([int]$idx) {
    if ([string]$cfg.Today.date -ne (Get-Date).ToString('yyyy-MM-dd')) { return '' }
    $d = $cfg.Today.data[(Get-InfoKey $idx)]
    if (-not $d) { return '' }
    $parts = @()
    if ([int]$d.added) { $parts += "เพิ่ม $([int]$d.added)" }
    if ([int]$d.invite) { $parts += "เชิญ $([int]$d.invite)" }
    if (-not $parts.Count -and [int]$d.line) { $parts += "รัน $([int]$d.line)" }
    return ($parts -join ' · ')
}
# อ่านไฟล์ที่อาจยังถูกเปิดค้างโดย process อื่น (เช่น adb server ที่สืบทอด handle ของไฟล์ log)
function Read-SharedText([string]$path) {
    if (-not $path -or -not (Test-Path -LiteralPath $path)) { return '' }
    for ($i = 0; $i -lt 5; $i++) {
        try {
            $fs = New-Object System.IO.FileStream($path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, ([System.IO.FileShare]::ReadWrite -bor [System.IO.FileShare]::Delete))
            try {
                $sr = New-Object System.IO.StreamReader($fs, $true)
                return [string]$sr.ReadToEnd()
            } finally { $fs.Dispose() }
        } catch { Start-Sleep -Milliseconds 80 }
    }
    return ''
}
function Get-LastJsonLine([string]$raw) {
    $lines = @(([string]$raw) -split "`r?`n" | Where-Object { $_.Trim().StartsWith('{') })
    if ($lines.Count) { return [string]$lines[$lines.Count - 1] }
    return ''
}
$script:CfgDirty = $false
# ชื่อช่อง ID: ช่อง 1 = Line@, ช่อง 2 = Line
function Get-IdColLabel([int]$k) { switch ($k) { 1 { return 'Line@' } 2 { return 'Line' } default { return "ID $k" } } }
function Get-SetKey($pair) { return ((@(Get-PairSlots $pair)) -join "`n").ToLowerInvariant() }
function Get-SetName($pair) {
    $ids = @(Get-PairIds $pair)
    if (-not $ids.Count) { return '-' }
    if ($ids.Count -gt 1) { return "$($ids[0]) +$($ids.Count - 1)" }
    return [string]$ids[0]
}
function Move-ConfigSet([string]$key, [string]$where) {
    try {
        if (-not $key -or -not (Test-Path -LiteralPath $script:LineConfigPath)) { return }
        $j = Get-Content -LiteralPath $script:LineConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $sets = New-Object System.Collections.ArrayList
        foreach ($pr in @($j.pairs)) { [void]$sets.Add($pr) }
        $pos = -1
        for ($n = 0; $n -lt $sets.Count; $n++) { if ((Get-SetKey $sets[$n]) -eq $key) { $pos = $n; break } }
        if ($pos -lt 0) { return }
        $item = $sets[$pos]
        $sets.RemoveAt($pos)
        if ($where -eq 'top') { $sets.Insert(0, $item) } else { [void]$sets.Add($item) }
        $data = [ordered]@{ pairs = @($sets); searchBy = [string]$j.searchBy }
        Save-LineConfigText (ConvertTo-Json -InputObject $data -Depth 5)
        if ($script:CfgDirty) { Write-LineJobLog 'หน้าตั้งค่า LINE มีการแก้ไขที่ยังไม่บันทึก จึงยังไม่รีเฟรชลำดับในหน้าจอ (กด "โหลดใหม่" เพื่อดูลำดับล่าสุด)' }
        else { Load-LineConfig }
    } catch { Write-LineJobLog "จัดลำดับชุดใน config ไม่สำเร็จ: $($_.Exception.Message)" }
}
# จำนวนกลุ่มของบัญชีในช่อง Line: +1 ทุกครั้งที่ชุดนี้ถูกใช้สำเร็จ (เฉพาะงานที่ใช้ช่อง Line ด้วย)
function Add-SetGroupCount([string]$key) {
    try {
        if (-not $key -or -not (Test-Path -LiteralPath $script:LineConfigPath)) { return $null }
        $j = Get-Content -LiteralPath $script:LineConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $hit = $null
        foreach ($pr in @($j.pairs)) { if ((Get-SetKey $pr) -eq $key) { $hit = $pr; break } }
        if (-not $hit) { return $null }
        $old = 0; [void][int]::TryParse([string]$hit.groups, [ref]$old)
        $new = $old + 1
        if ($hit.PSObject.Properties['groups']) { $hit.groups = $new } else { $hit | Add-Member -NotePropertyName groups -NotePropertyValue $new }
        Save-LineConfigText (ConvertTo-Json -InputObject ([ordered]@{ pairs = @($j.pairs); searchBy = [string]$j.searchBy }) -Depth 5)
        # same number on screen (also when the ID page has unsaved edits, so saving it later keeps the new count)
        $wasDirty = $script:CfgDirty
        foreach ($row in $cfgGrid.Rows) {
            if ($row.IsNewRow) { continue }
            $sl = @(); for ($c = 1; $c -le $script:CfgMaxIds; $c++) { $sl += ([string]$row.Cells[$c].Value).Trim() }
            while ($sl.Count -and -not $sl[$sl.Count - 1]) { $sl = @($sl | Select-Object -First ($sl.Count - 1)) }
            if ((($sl -join "`n").ToLowerInvariant()) -eq $key) { $row.Cells['groups'].Value = [string]$new; break }
        }
        $script:CfgDirty = $wasDirty
        return @($old, $new)
    } catch { Write-LineJobLog "บวกจำนวนกลุ่มไม่สำเร็จ: $($_.Exception.Message)"; return $null }
}
function Set-LineMainStatus([int]$idx,[string]$message) {
    $script:LineMainStatus[$idx] = $message
    Write-LineJobLog "LD #$idx | $message"
    Update-Status
}

$script:LineJobTimer = New-Object System.Windows.Forms.Timer
$script:LineJobTimer.Interval = 550
function Write-LineJobLog([string]$message) {
    $message = T $message
    $stamp = (Get-Date).ToString('HH:mm:ss')
    $txtLog.AppendText("[$stamp] $message`r`n")
    $txtLog.SelectionStart = $txtLog.TextLength
    $txtLog.ScrollToCaret()
    $lblStatus.Text = $message
}
function Start-LineScriptForIndex([int]$idx) {
    $scriptPath = Join-Path $PSScriptRoot 'Adb-LineAddFriend.ps1'
    if (-not (Test-Path -LiteralPath $scriptPath)) {
        [void][System.Windows.Forms.MessageBox]::Show($form,"ไม่พบ $scriptPath",'LINE Script')
        return
    }
    if (-not (Test-Path -LiteralPath $script:LineConfigPath)) {
        [void][System.Windows.Forms.MessageBox]::Show($form,'กรุณาบันทึก LINE config ก่อน','LINE Script')
        return
    }
    Write-LineJobLog "LD #$idx | ขั้นตอน 1/5: ตรวจสอบ config และชุด LINE"
    $pairKey = $null
    try {
        $j = Get-Content -LiteralPath $script:LineConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $pairs = @($j.pairs)
        if (-not $pairs.Count) { throw 'config.json ไม่มี pairs กรุณาตั้งค่า LINE เป็นชุดละ 2 ช่องและบันทึก' }
        foreach ($pair in $pairs) {
            if (@(Get-PairIds $pair).Count -lt 1) { throw 'ทุกชุดต้องมี LINE ID อย่างน้อย 1 ช่อง' }
        }
        foreach ($job in @($script:LineJobs)) {
            if ($job.Index -eq $idx -and -not $job.Process.HasExited) { throw "LD #$idx กำลังรันอยู่แล้ว" }
        }
        # ใช้ชุดบนสุดที่ไม่ได้ถูกใช้อยู่กับเครื่องอื่น ถ้าทุกชุดถูกใช้หมด -> วนกลับมาใช้ชุดบนสุด (ใช้นานที่สุดแล้ว)
        # เลือกใช้เฉพาะ ID ช่องที่กำหนด (0 = ทุกช่อง): ชุดที่ไม่มี ID ช่องนั้นจะถูกข้าม
        $useCol = [Math]::Max(0, [Math]::Min(10, [int]$cfg.UseIdCol))
        $usable = @()
        for ($n = 0; $n -lt $pairs.Count; $n++) {
            if ($useCol -eq 0) { if (@(Get-PairIds $pairs[$n]).Count) { $usable += $n } }
            else { $sl = @(Get-PairSlots $pairs[$n]); if ($sl.Count -ge $useCol -and $sl[$useCol - 1]) { $usable += $n } }
        }
        if (-not $usable.Count) { throw "ไม่มีชุดไหนมี ID ช่องที่ $useCol กรุณาเปลี่ยนตัวเลือก 'ใช้ ID' หรือกรอกเพิ่มในหน้าตั้งค่า LINE" }
        $inUse = @($script:LineJobs | ForEach-Object { [string]$_.PairKey })
        $pairIndex = -1
        foreach ($n in $usable) {
            if ($inUse -notcontains (Get-SetKey $pairs[$n])) { $pairIndex = $n; break }
        }
        $wrapped = $false
        if ($pairIndex -lt 0) { $pairIndex = $usable[0]; $wrapped = $true }
        $pair = $pairs[$pairIndex]
        $pairKey = Get-SetKey $pair
        $setName = if ($useCol -gt 0) { "$(@(Get-PairSlots $pair)[$useCol - 1]) ($(Get-IdColLabel $useCol))" } else { Get-SetName $pair }
        $adbPath = [string]$Sync.Adb
        if (-not (Test-Path -LiteralPath $adbPath)) { throw 'ยังไม่พบ adb.exe กรุณาเลือกโฟลเดอร์ LDPlayer ก่อน' }
        Write-LineJobLog "LD #$idx | ขั้นตอน 2/5: ตรวจสอบ ADB (จำกัดเวลา 5 วินาที)"
        $psiAdb = New-Object System.Diagnostics.ProcessStartInfo
        $psiAdb.FileName = $adbPath
        $psiAdb.Arguments = 'devices'
        $psiAdb.UseShellExecute = $false
        $psiAdb.CreateNoWindow = $true
        $psiAdb.RedirectStandardOutput = $true
        $psiAdb.RedirectStandardError = $true
        $pAdb = New-Object System.Diagnostics.Process
        $pAdb.StartInfo = $psiAdb
        try {
            [void]$pAdb.Start()
            $readOut = $pAdb.StandardOutput.ReadToEndAsync()
            $readErr = $pAdb.StandardError.ReadToEndAsync()
            if (-not $pAdb.WaitForExit(5000)) {
                try { $pAdb.Kill() } catch {}
                throw 'ADB devices ไม่ตอบสนองภายใน 5 วินาที กรุณาตรวจสอบ ADB'
            }
            $adbText = $readOut.Result
            $live = @($adbText -split "`r?`n" | ForEach-Object {
                if ($_ -match '^(\S+)\s+device(?:\s|$)') { $Matches[1] }
            })
        } finally { $pAdb.Dispose() }
        $key = [string]$idx
        $serial = ''
        if ($cfg.SerialMap.ContainsKey($key)) { $serial = [string]$cfg.SerialMap[$key] }
        if (-not $serial) {
            $item = @($Sync.Snapshot | Where-Object { [int]$_.Index -eq $idx } | Select-Object -First 1)
            if ($item.Count) { $serial = [string]$item[0].Serial }
        }
        if ($live -notcontains $serial) {
            if ($live.Count -eq 1) {
                $choice = [System.Windows.Forms.MessageBox]::Show($form,
                    "ADB พบ Serial $($live[0])`nยืนยันว่าเป็น LD #$idx ที่เลือก?",'ยืนยัน ADB Serial','YesNo','Question')
                if ($choice -ne 'Yes') { return }
                $serial = [string]$live[0]
                $cfg.SerialMap[$key] = $serial
                Save-Config
            } else { throw "ไม่สามารถระบุ ADB Serial ของ LD #$idx ได้ (ADB ที่พร้อม: $($live -join ', '))" }
        }
        foreach ($job in @($script:LineJobs)) {
            if ($job.Index -eq $idx -and -not $job.Process.HasExited) { throw "LD #$idx กำลังรัน LINE Script อยู่แล้ว" }
        }
        if ($wrapped) {
            Write-LineJobLog "LD #$idx | ขั้นตอน 3/5: ทุกชุดถูกใช้อยู่ -> วนกลับใช้ชุดบนสุด [$setName] ซ้ำ ให้ Serial $serial"
        } else {
            Write-LineJobLog "LD #$idx | ขั้นตอน 3/5: ใช้ชุดบนสุดที่ว่าง (ลำดับ $($pairIndex+1)/$($pairs.Count)) [$setName] ให้ Serial $serial"
        }
        $outDir = Join-Path $env:APPDATA 'LDAdbConnector\LineScriptLogs'
        [void][System.IO.Directory]::CreateDirectory($outDir)
        $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss_fff')
        $stdout = Join-Path $outDir "LD${idx}_${stamp}.json"
        $stderr = Join-Path $outDir "LD${idx}_${stamp}.err.txt"
        $exe = Join-Path $PSHOME 'powershell.exe'
        if (-not (Test-Path $exe)) { $exe = 'powershell.exe' }
        $pairConfig = Join-Path $outDir "LD${idx}_${stamp}_pair.json"
        $pairIds = @(Get-PairIds $pair)
        if ($useCol -gt 0) {
            $pairIds = @(@(Get-PairSlots $pair)[$useCol - 1])
            Write-LineJobLog "LD #$idx | ใช้เฉพาะ $(Get-IdColLabel $useCol) ของชุดนี้: $($pairIds[0])"
        }
        $pairJson = ConvertTo-Json -InputObject ([ordered]@{texts=@($pairIds);searchBy=[string]$j.searchBy}) -Depth 5
        [System.IO.File]::WriteAllText($pairConfig,$pairJson,(New-Object System.Text.UTF8Encoding($false)))
        $args = @('-NoProfile' ,'-ExecutionPolicy','Bypass','-File',('"'+$scriptPath+'"'),'-Adb',('"'+$adbPath+'"'),'-Serial',('"'+$serial+'"'),'-ConfigPath',('"'+$pairConfig+'"'),'-LaunchLine') -join ' '
        $afterMode = [int]$cfg.AfterIdMode
        if ($script:LineModeFor[$idx] -eq 'replaceoa') { $afterMode = 9 }
        [void]$script:LineModeFor.Remove($idx)
        if ($afterMode -eq 9) {
            $rmNames = @(([string]$cfg.ReplaceOaNames) -split '[,\r\n]+' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
            $ldc = Join-Path ([string]$Sync.LdDir) 'ldconsole.exe'
            $rmB64 = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject @($rmNames) -Compress)))
            $args += " -ReplaceOaB64 $rmB64 -MinMembers $([int]$cfg.ReplaceMinMembers) -LdConsole `"$ldc`" -LdIndex $idx"
            Write-LineJobLog "LD #$idx | โหมด: เปลี่ยน OA → กลุ่มที่สมาชิกเกิน $([int]$cfg.ReplaceMinMembers) คน → ลบ '$($rmNames -join "', '")' → หน้าแรก → เพิ่ม OA ใหม่ + สแกนชื่อ → เชิญเข้ากลุ่มเดิม"
        }
        elseif ($afterMode -eq 1) { Write-LineJobLog "LD #$idx | โหมด: เพิ่ม ID อย่างเดียว (ไม่เข้ากลุ่ม / ไม่ติ๊กวงกลม)" }
        elseif ($afterMode -eq 3) {
            $ldc = Join-Path ([string]$Sync.LdDir) 'ldconsole.exe'
            $args += " -CreateGroup -GroupAction create -CreateWithNames -LdConsole `"$ldc`" -LdIndex $idx"
            $pt = Get-PreTickArg
            if ($pt) { $args += ($pt -replace ' -LdConsole "[^"]*"', '') }
            Write-LineJobLog "LD #$idx | โหมด: เพิ่ม ID + สแกนชื่อ → กลุ่ม → สร้างกลุ่ม → ค้นหาด้วยชื่อที่สแกนแล้วติ๊ก → ลบช่องค้นหา → ติ๊กวงกลมตามที่ตั้ง"
        }
        elseif ($afterMode -eq 2) {
            $args += ' -ScanGroups'
            $preG = [string]$script:PreGroup[$idx]
            [void]$script:PreGroup.Remove($idx)
            if ($preG) {
                $ldc = Join-Path ([string]$Sync.LdDir) 'ldconsole.exe'
                $args += " -JoinGroupB64 $([Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($preG))) -LdConsole `"$ldc`" -LdIndex $idx"
                $pt = Get-PreTickArg
                if ($pt) { $args += ($pt -replace ' -LdConsole "[^"]*"', '') }
                Write-LineJobLog "LD #$idx | โหมด: เพิ่ม ID + สแกนชื่อ → เข้ากลุ่ม '$preG' → แชท → ≡ → เชิญ → ค้นหาด้วยชื่อแล้วติ๊ก (รวดเดียว)"
            } else { Write-LineJobLog "LD #$idx | โหมด: เพิ่ม ID + สแกนชื่อ → สแกนรายชื่อกลุ่ม → ให้เลือกกลุ่ม → เชิญตามชื่อ" }
        }
        else { $args += " -CreateGroup -MaxMembers $([int]$cfg.MaxGroupMembers)" + (Get-PreTickArg) + " -LdIndex $idx" }
        Write-LineJobLog "LD #$idx | ขั้นตอน 4/5: เรียก Adb-LineAddFriend.ps1"
        $p = Start-Process -FilePath $exe -ArgumentList $args -WorkingDirectory $PSScriptRoot -PassThru -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr
        [void]$script:LineJobs.Add([pscustomobject]@{Index=$idx;Serial=$serial;Process=$p;Output=$stdout;ErrorFile=$stderr;Started=Get-Date;PairIndex=$pairIndex;PairKey=$pairKey;UseCol=$useCol;SetName=$setName;PairConfig=$pairConfig;Mode=$afterMode;PreGroup=$(if ($afterMode -eq 2) { $preG } else { '' })})
        Set-LineMainStatus $idx "ชุด [$setName] | กำลังเริ่ม LINE ($($pairIds.Count) ครั้ง)"
        $cfg.LastSet[(Get-InfoKey $idx)] = [string]$setName
        Save-Config
        Move-ConfigSet $pairKey 'end'
        Write-LineJobLog "LD #$idx | ย้ายชุด [$setName] ไปท้ายรายการแล้ว (ชุดถัดไปจะขึ้นมาบนสุด)"
        $script:LineJobTimer.Start()
        Write-LineJobLog "LD #$idx | ขั้นตอน 5/5: สคริปต์เริ่มแล้ว PID $($p.Id) | กำลังรอผล"
        Add-Stat $idx 'line'
    } catch {
        Write-LineJobLog "LD #$idx | ไม่สามารถเริ่มสคริปต์: $($_.Exception.Message)"
        [void][System.Windows.Forms.MessageBox]::Show($form,$_.Exception.Message,'LINE Script')
    }
}
$script:LineModeFor = @{}
# เริ่มจากคิวทีละเครื่อง เพื่อให้ GUI อัปเดตสถานะได้ก่อนเรียก ADB
$script:LineStartQueue = New-Object System.Collections.Queue
$script:LineStartTimer = New-Object System.Windows.Forms.Timer
$script:LineStartTimer.Interval = 100
# ทีละเครื่อง: ห่างกัน StartGap วินาที (และถ้า StartWaitDone = รอเครื่องก่อนหน้าทำเสร็จก่อน)
$script:NextStartAt = [datetime]::MinValue
$script:WaitIdx = $null
$script:GapLogged = $false
$script:LineStartTimer.Add_Tick({
    $script:LineStartTimer.Stop()
    $script:LineStartTimer.Interval = 200
    if ($script:LineStartQueue.Count -eq 0) { $script:WaitIdx = $null; return }
    $gap = [Math]::Max(0, [int]$cfg.StartGap)
    if ($null -ne $script:WaitIdx) {
        $wi = [int]$script:WaitIdx
        if ((Test-RowBusy $wi) -or @($script:PickQueue | Where-Object { [int]$_.Index -eq $wi }).Count) { $script:LineStartTimer.Start(); return }
        Write-LineJobLog "LD #$($script:WaitIdx) | ทำเสร็จแล้ว → เริ่มเครื่องถัดไป$(if ($gap) { " ใน $gap วินาที" })"
        $script:WaitIdx = $null
        $script:NextStartAt = (Get-Date).AddSeconds($gap)
    }
    if ((Get-Date) -lt $script:NextStartAt) {
        if (-not $script:GapLogged) { $script:GapLogged = $true }
        $script:LineStartTimer.Start(); return
    }
    $script:GapLogged = $false
    $idx = [int]$script:LineStartQueue.Dequeue()
    try { Start-LineScriptForIndex $idx }
    catch { Write-LineJobLog "LD #$idx | ERROR: $($_.Exception.Message)" }
    if ([bool]$cfg.StartWaitDone) { $script:WaitIdx = $idx }
    $script:NextStartAt = (Get-Date).AddSeconds($gap)
    if ($script:LineStartQueue.Count -gt 0) {
        if ([bool]$cfg.StartWaitDone) { Write-LineJobLog "คิว: เหลือ $($script:LineStartQueue.Count) เครื่อง รอ LD #$idx ทำเสร็จก่อน" }
        elseif ($gap) { Write-LineJobLog "คิว: เหลือ $($script:LineStartQueue.Count) เครื่อง เริ่มเครื่องถัดไปใน $gap วินาที" }
        $script:LineStartTimer.Start()
    } else { if (-not [bool]$cfg.StartWaitDone) { $script:WaitIdx = $null } }
})
function Start-LineScript([int[]]$targets = $null) {
    Write-LineJobLog 'รับคำสั่งเริ่ม LINE Script แล้ว'
    if ($null -eq $targets) { $targets = @(Get-Targets) }
    $targets = @($targets)
    Write-LineJobLog "ตรวจสอบเครื่องที่เลือก: $($targets.Count) เครื่อง | $($targets -join ', ')"
    if ($targets.Count -eq 0) {
        Write-LineJobLog 'ไม่พบเครื่องที่ติ๊ก: ตรวจสอบว่าแถวเครื่องยังปรากฏในตารางและ ADB เชื่อมต่อแล้ว'
        [void][System.Windows.Forms.MessageBox]::Show($form,'ไม่พบ LDPlayer ที่ติ๊กเลือก กรุณาติ๊กช่อง ✔ ที่แถวเครื่องแล้วลองใหม่','LINE Script')
        return
    }
    $unique = @($targets | ForEach-Object { [int]$_ } | Select-Object -Unique)
    if ([int]$cfg.AfterIdMode -eq 2 -and -not @($unique | Where-Object { $script:LineModeFor[[int]$_] -eq 'replaceoa' }).Count) {
        $ready = @($unique | Where-Object { Test-RowReady $_ })
        $pre = Show-GroupPreselect $ready
        if ($null -eq $pre) { Write-LineJobLog 'ยกเลิกการเริ่ม (ไม่ได้เลือกกลุ่ม)'; return }
        foreach ($k in $pre.Keys) {
            $script:PreGroup[[int]$k] = [string]$pre[$k]
            if ($pre[$k]) { Write-LineJobLog "LD #$k | เลือกกลุ่มไว้แล้ว: '$($pre[$k])' → รันรวดเดียว" }
        }
    }
    if ($script:LineStartQueue.Count -eq 0) { $script:WaitIdx = $null; $script:NextStartAt = [datetime]::MinValue }
    foreach ($idx in $unique) {
        $queued = @($script:LineStartQueue.ToArray() | Where-Object { [int]$_ -eq $idx }).Count -gt 0
        if (-not (Test-RowReady $idx)) { Write-LineJobLog "LD #$idx | ข้าม: LD ยังไม่เปิด / ยังไม่เชื่อม ADB"; continue }
        if ($queued) { Write-LineJobLog "LD #$idx | อยู่ในคิวแล้ว ไม่เพิ่มซ้ำ"; continue }
        if (@($script:LineJobs) | Where-Object { $_.Index -eq $idx }) { Write-LineJobLog "LD #$idx | ข้าม: กำลังรัน LINE Script อยู่แล้ว"; continue }
        if (@($script:InfoJobs) | Where-Object { $_.Index -eq $idx }) { Write-LineJobLog "LD #$idx | ข้าม: มีงานอื่นทำอยู่ในเครื่องนี้"; continue }
        $script:LineStartQueue.Enqueue($idx)
        Set-LineMainStatus $idx 'รับคำสั่งแล้ว | รอเริ่ม LINE Script...'
    }
    # a machine that was skipped must not keep the "replace OA" mode for its next normal start
    foreach ($k in @($script:LineModeFor.Keys)) { if (-not (@($script:LineStartQueue.ToArray()) -contains [int]$k)) { [void]$script:LineModeFor.Remove($k) } }
    Write-LineJobLog "คิวเริ่ม LINE: $($script:LineStartQueue.Count) เครื่อง$(if ([int]$cfg.StartGap -gt 0 -or [bool]$cfg.StartWaitDone) { " (ทีละเครื่อง$(if ([int]$cfg.StartGap -gt 0) { " ห่างกัน $([int]$cfg.StartGap) วินาที" })$(if ([bool]$cfg.StartWaitDone) { ' · รอเครื่องก่อนหน้าทำเสร็จก่อน' }))" })"
    if ($script:LineStartQueue.Count -gt 0) { $script:LineStartTimer.Start() }
}
function Stop-LineJobTree($proc) {
    try {
        if ($proc.HasExited) { return }
        $tk = Join-Path $env:SystemRoot 'System32\taskkill.exe'
        if (Test-Path $tk) {
            $k = Start-Process -FilePath $tk -ArgumentList "/PID $($proc.Id) /T /F" -WindowStyle Hidden -PassThru
            [void]$k.WaitForExit(3000)
        }
        if (-not $proc.HasExited) { $proc.Kill() }
        [void]$proc.WaitForExit(1000)
    } catch {}
}
function Stop-LineScriptsFor([int[]]$targets, [bool]$all) {
    $targets = @($targets | Where-Object { $null -ne $_ } | ForEach-Object { [int]$_ })
    if ($all) {
        $script:LineStartTimer.Stop()
        foreach ($q in @($script:LineStartQueue.ToArray())) { $script:LineMainStatus[[int]$q] = 'ยกเลิกคิว LINE Script โดยผู้ใช้' }
        $script:LineStartQueue.Clear()
        $targets = @(@($script:LineJobs | ForEach-Object { [int]$_.Index }) + @($script:InfoJobs | ForEach-Object { [int]$_.Index }))
    } else {
        $keep = @($script:LineStartQueue.ToArray() | Where-Object { $targets -notcontains [int]$_ })
        $removed = @($script:LineStartQueue.ToArray() | Where-Object { $targets -contains [int]$_ })
        $script:LineStartQueue.Clear()
        foreach ($q in $keep) { $script:LineStartQueue.Enqueue($q) }
        foreach ($q in $removed) { $script:LineMainStatus[[int]$q] = 'ยกเลิกคิว LINE Script โดยผู้ใช้' }
        if ($removed.Count) { Write-LineJobLog "ยกเลิกคิวรอเริ่ม $($removed.Count) เครื่อง" }
    }
    $stopped = 0
    foreach ($k in @($script:LineModeFor.Keys)) { if (-not (@($script:LineStartQueue.ToArray()) -contains [int]$k)) { [void]$script:LineModeFor.Remove($k) } }
    foreach ($pq in @($script:PickQueue.ToArray())) {
        if ($all -or $targets -contains [int]$pq.Index) { [void]$script:PickQueue.Remove($pq); $script:LineMainStatus[[int]$pq.Index] = 'ยกเลิกการเลือกกลุ่มโดยผู้ใช้'; $stopped++ }
    }
    foreach ($idx in @($targets | Select-Object -Unique)) {
        foreach ($job in @($script:LineJobs.ToArray())) {
            if ($job.Index -ne [int]$idx) { continue }
            Stop-LineJobTree $job.Process
            [void]$script:LineJobs.Remove($job)
            # The set was interrupted: release it and put it back on top so it is used next.
            if ($job.PairKey -and -not (@($script:LineJobs) | Where-Object { [string]$_.PairKey -eq [string]$job.PairKey })) {
                Move-ConfigSet ([string]$job.PairKey) 'top'
            }
            Set-LineMainStatus ([int]$idx) "ชุด [$($job.SetName)] | หยุดโดยผู้ใช้ (ชุดนี้กลับไปบนสุด ใช้ต่อได้ทันที)"
            try { $job.Process.Dispose() } catch {}
            $stopped++
        }
        foreach ($job in @($script:InfoJobs.ToArray())) {
            if ($job.Index -ne [int]$idx) { continue }
            Stop-LineJobTree $job.Process
            [void]$script:InfoJobs.Remove($job)
            $what = if ($job.Kind -eq 'select') { 'ติ๊กเพื่อน' } elseif ($job.Kind -in 'group', 'byname') { 'เชิญเข้ากลุ่ม' } elseif ($job.Kind -eq 'check') { 'ตรวจ ID' } elseif ($job.Kind -eq 'findoa') { 'ค้นหา OA' } else { 'ดึงข้อมูล LINE' }
            $script:LineMainStatus[[int]$idx] = "หยุด$what โดยผู้ใช้"
            Write-LineJobLog "LD #$idx | หยุด$what โดยผู้ใช้"
            try { $job.Process.Dispose() } catch {}
            $stopped++
        }
    }
    Write-LineJobLog "หยุดงานแล้ว $stopped งาน"
    try { Complete-FindOaBatch } catch {}
    if ($script:LineJobs.Count -eq 0) { $script:LineJobTimer.Stop() }
    if ($script:InfoJobs.Count -eq 0) { $script:InfoJobTimer.Stop() }
    try { Update-Status } catch {}
}
function Stop-LineScripts([int[]]$targets = $null) {
    if ($null -eq $targets) { $targets = @(Get-Targets) }
    if (-not @($targets).Count) {
        [void][System.Windows.Forms.MessageBox]::Show($form, 'กรุณาติ๊ก ✔ เครื่องที่ต้องการหยุด', 'หยุดงาน')
        return
    }
    Stop-LineScriptsFor @($targets) $false
}
function Stop-AllLineScripts { Stop-LineScriptsFor @() $true }

# --- สถานะงานของแต่ละเครื่อง ---
$script:RowActInfo = @{}
$script:ActColors = @{
    line   = (New-Rgb 0 185 84)
    queue  = (New-Rgb 0 185 84)
    info   = (New-Rgb 88 166 255)
    select = (New-Rgb 188 140 255)
    worker = (New-Rgb 227 179 65)
}
function Get-RowActivity([int]$i) {
    $j = @($script:LineJobs | Where-Object { $_.Index -eq $i } | Select-Object -First 1)
    if ($j.Count) { return @{ Kind = 'line'; Label = 'กำลังรัน LINE Script'; Since = $j[0].Started; Detail = [string]$script:LineMainStatus[$i] } }
    if ($script:LineStartQueue -and (@($script:LineStartQueue.ToArray()) -contains $i)) { return @{ Kind = 'queue'; Label = 'รอคิว LINE Script'; Since = $null; Detail = '' } }
    $k = @($script:InfoJobs | Where-Object { $_.Index -eq $i } | Select-Object -First 1)
    if ($k.Count) {
        if ($k[0].Kind -eq 'select') { return @{ Kind = 'select'; Label = 'กำลังติ๊กเพื่อน'; Since = $k[0].Started; Detail = [string]$k[0].Detail } }
        if ($k[0].Kind -eq 'group') { return @{ Kind = 'select'; Label = 'กำลังเข้ากลุ่ม/เชิญ'; Since = $k[0].Started; Detail = [string]$k[0].Detail } }
        if ($k[0].Kind -eq 'check') { return @{ Kind = 'info'; Label = 'กำลังดึงชื่อ ID'; Since = $k[0].Started; Detail = [string]$k[0].Detail } }
        if ($k[0].Kind -eq 'findoa') { return @{ Kind = 'info'; Label = 'กำลังค้นหา OA'; Since = $k[0].Started; Detail = [string]$k[0].Detail } }
        if ($k[0].Kind -eq 'byname') { return @{ Kind = 'select'; Label = 'กำลังเชิญตามชื่อ'; Since = $k[0].Started; Detail = [string]$k[0].Detail } }
        return @{ Kind = 'info'; Label = 'กำลังดึงข้อมูล LINE'; Since = $k[0].Started; Detail = [string]$k[0].Detail }
    }
    return $null
}
function Test-RowBusy([int]$i) { return ($null -ne (Get-RowActivity $i)) }
function Get-CheckedIdx {
    try { [void]$grid.EndEdit() } catch {}
    $r = @()
    foreach ($row in $grid.Rows) {
        if ($null -eq $row.Tag) { continue }
        if ([string]$row.Cells['Chk'].Value -eq 'True') { $r += [int]$row.Tag }
    }
    return , $r
}
function Need-Checked([string]$title) {
    $c = Get-CheckedIdx
    if (-not $c.Count) { [void][System.Windows.Forms.MessageBox]::Show($form, 'กรุณาติ๊ก ✔ เครื่องที่ต้องการก่อน (หรือกด "เลือกทั้งหมด")', $title) }
    return , $c
}
function Set-AllChecked([bool]$on) {
    try { [void]$grid.EndEdit() } catch {}
    foreach ($r in $grid.Rows) {
        if ($null -eq $r.Tag) { continue }
        if ($on -and -not $r.Visible) { continue }
        $r.Cells['Chk'].Value = $on
        $script:checked[[int]$r.Tag] = $on
    }
    Save-Checked
    $grid.Invalidate()
    try { Update-HeaderStats } catch {}
}

$script:LineJobTimer.Add_Tick({
    $chain = @()
    foreach ($job in @($script:LineJobs.ToArray())) {
        $exited = $true
        try { $exited = $job.Process.HasExited } catch {}
        if (-not $exited) { continue }
        $idx = [int]$job.Index
        try {
            Set-LineMainStatus $idx "ชุด [$($job.SetName)] | อ่านผลการทำงาน"
            $raw = Read-SharedText ([string]$job.Output)
            $line = Get-LastJsonLine $raw
            if (-not $line) { throw 'สคริปต์ไม่ส่งผลลัพธ์ JSON กลับมา' }
            $result = $line | ConvertFrom-Json -ErrorAction Stop
            foreach ($step in @($result.steps)) {
                if ($null -ne $step -and $step.step) {
                    $desc = if ($step.found) { 'พบ' } else { 'ไม่พบ' }
                    Write-LineJobLog "LD #$idx | ขั้นตอน 3/4: $($step.step) -> $desc | $($step.method)"
                }
            }
            foreach ($round in @($result.rounds)) {
                if ($null -ne $round -and $round.round) {
                    $desc = if ($round.ok) { 'สำเร็จ' } else { 'ไม่สำเร็จ' }
                    Write-LineJobLog "LD #$idx | รายการ $($round.round): $desc"
                }
            }
            try { [void](Update-IdNamesFromRounds $result.rounds) } catch {}
            $status = if ($result.ok) { 'สำเร็จ' } else { 'ไม่สำเร็จ' }
            try { Add-Count 'reg' ([bool]$result.ok) } catch {}
            $errMsg = if ($result.error) { " | $($result.error)" } else { '' }
            if ($result.ok) {
                Set-LineMainStatus $idx "ชุด [$($job.SetName)] สำเร็จ"
                if ($job.PSObject.Properties['UseCol'] -and [int]$job.UseCol -in 0, 2 -and $job.PairKey -and @(([string]$job.PairKey) -split "`n").Count -ge 2 -and (([string]$job.PairKey) -split "`n")[1]) {
                    $gc = Add-SetGroupCount ([string]$job.PairKey)
                    if ($gc) { Write-LineJobLog "LD #$idx | กลุ่มของ Line '$((([string]$job.PairKey) -split "`n")[1])': $($gc[0]) → $($gc[1])" }
                }
            } else {
                Set-LineMainStatus $idx "ชุด [$($job.SetName)] ไม่สำเร็จ | ตรวจ Log"
            }
            Write-LineJobLog "LD #$idx | ขั้นตอน 4/4: $status$errMsg"
            $newFriends = @(@($result.rounds) | Where-Object { $null -ne $_ -and $_.ok -and -not $_.note }).Count
            Add-Stat $idx 'added' $newFriends
            if (Write-GroupStepLog $idx $result.createGroup) { $chain += $idx }
            if ($job.PSObject.Properties['Mode'] -and [int]$job.Mode -eq 9) {
                $rp = $result.replace
                if (-not $rp) { Write-LineJobLog "LD #$idx | เปลี่ยน OA: ไม่ได้ผลลัพธ์ส่วนลบ/เชิญ" }
                else {
                    if (-not $rp.scanned) { Write-LineJobLog "LD #$idx | เปลี่ยน OA: เปิดหน้า 'กลุ่ม' ไม่ได้" }
                    $big = @($rp.groups)
                    if (-not $big.Count) { Write-LineJobLog "LD #$idx | เปลี่ยน OA: ไม่มีกลุ่มที่สมาชิกเกิน $([int]$cfg.ReplaceMinMembers) คน" }
                    foreach ($s in @($rp.skipped)) { if ($s) { Write-LineJobLog "LD #$idx | ข้ามกลุ่ม '$($s.name)': ไม่ทราบจำนวนสมาชิก" } }
                    foreach ($round in @($result.rounds)) { if ($round -and $round.ok -and $round.name) { Write-LineJobLog "LD #$idx | OA ใหม่ '$($round.text)' → ชื่อ: $($round.name)" } }
                    if (-not @($rp.newNames).Count) { Write-LineJobLog "LD #$idx | ✖ เพิ่ม OA ใหม่ไม่สำเร็จ / สแกนชื่อไม่ได้ → ไม่ได้เชิญกลับ" }
                    $okG = 0
                    $doneLines = @()
                    foreach ($g in $big) {
                        if ($null -eq $g) { continue }
                        $rmTxt = (@($g.items) | Where-Object { $_ } | ForEach-Object {
                                "'$($_.name)' " + $(if ($_.removed) { "ลบแล้ว $($_.removed)" + $(if ($_.error) { " (ตัวถัดไปลบไม่ได้: $($_.error))" }) } elseif (-not $_.found) { 'ไม่มีในกลุ่ม' } else { "เจอแต่ลบไม่ได้: $($_.error)" }) +
                                $(if ($_.dump) { " | ไฟล์หน้าจอ: $($_.dump)" } else { '' })
                            }) -join ', '
                        if ($g.dump) { $rmTxt += " | ไฟล์หน้าจอ: $($g.dump)" }
                        if (-not $g.opened) { Write-LineJobLog "LD #$idx | กลุ่ม '$($g.name)' ($($g.members) คน): ✖ เปิดหน้าสมาชิกไม่ได้ ($($g.error))"; continue }
                        $invTxt = ''
                        if ([int]$g.removed -gt 0 -or $g.hadOa) {
                            $iv = @($g.invited | Where-Object { $_ })
                            $tk = @($iv | Where-Object { $_.ticked }).Count
                            $why = switch ([string]$g.invite.failStep) {
                                'home' { 'กลับหน้าแรกไม่ได้' } 'groups' { "กดคำว่า 'กลุ่ม' ไม่ได้" } 'group' { 'หากลุ่มนี้ในรายการกลุ่มไม่เจอ' }
                                'enter' { 'กดกลุ่มแล้วไม่เข้ากลุ่ม' } 'chat' { "กด 'แชท' ไม่ได้" } 'menu' { 'หา ≡ ขวาบนไม่เจอ' } 'invite' { "ไม่มีเมนู 'เชิญ'" } default { 'เปิดหน้าเชิญไม่ได้' } }
                            $invTxt = if (-not @($rp.newNames).Count) { ' → ไม่ได้เชิญ (ไม่มีชื่อ OA ใหม่)' } elseif (-not $g.invite) { ' → ยังไม่ได้เชิญ' } elseif (-not $g.invite.opened) { " → ✖ เชิญไม่ได้: $why$(if ($g.invite.dump) { " | ไฟล์หน้าจอ: $($g.invite.dump)" })" } else { " → เชิญ OA ใหม่: ติ๊กแล้ว $tk/$($iv.Count)" }
                            if ($tk -gt 0) { $okG++; Add-Stat $idx 'invite' }
                            $doneLines += "กลุ่ม '$($g.name)': $(if ($g.removed) { "ลบ OA แล้ว $($g.removed)" } else { 'เจอ OA แต่ลบไม่ได้' }) · $(if ($tk -gt 0) { "เชิญ '$((@($iv | Where-Object { $_.ticked }) | ForEach-Object { $_.name }) -join ', ')' แล้ว ✔" } else { "เชิญไม่สำเร็จ ✖" })"
                            Add-OaReplaceRecord $idx $g @($rp.newNames) ($tk -gt 0)
                        }
                        Write-LineJobLog "LD #$idx | กลุ่ม '$($g.name)' ($($g.members) คน): $rmTxt$invTxt"
                    }
                    Write-LineJobLog "LD #$idx | $(if ($okG) { '✔' } else { '✖' }) เปลี่ยน OA เสร็จ: เชิญ OA ใหม่เข้า $okG กลุ่ม (ยังไม่กดยืนยันเชิญ ตรวจแล้วกดเองบนจอ)"
                    Set-LineMainStatus $idx "เปลี่ยน OA: ลบ+เชิญแล้ว $okG กลุ่ม"
                    if (-not $doneLines.Count) { $doneLines = @("ไม่พบ OA ที่มีปัญหาในกลุ่มที่สมาชิกเกิน $([int]$cfg.ReplaceMinMembers) คน") }
                    Show-DoneNotice "LD #$idx — เปลี่ยน OA เสร็จแล้ว" (@("OA ใหม่: $((@($rp.newNames)) -join ', ')") + $doneLines)
                }
            }
            if ($job.PSObject.Properties['Mode'] -and [int]$job.Mode -eq 2) {
                $gl0 = @($result.groupList.groups | Where-Object { $null -ne $_ -and $_.name })
                if ($gl0.Count) { Save-GroupCache $idx $gl0 }
                $pg = if ($job.PSObject.Properties['PreGroup']) { [string]$job.PreGroup } else { '' }
                $cg0 = $result.createGroup
                if ($pg -and $cg0 -and -not $cg0.wantedMissing) {
                    foreach ($round in @($result.rounds)) { if ($round -and $round.ok -and $round.name) { Write-LineJobLog "LD #$idx | ID '$($round.text)' → ชื่อ: $($round.name)" } }
                    Write-ByNameResult $idx $result
                    Add-Stat $idx 'invite'
                } else {
                if ($pg -and $cg0 -and $cg0.wantedMissing) { Write-LineJobLog "LD #$idx | ไม่พบกลุ่ม '$pg' แล้ว (ถูกลบ/เปลี่ยนชื่อ?) → สแกนกลุ่มใหม่ให้เลือกอีกครั้ง" }
                $names = @()
                foreach ($round in @($result.rounds)) {
                    if ($null -eq $round -or -not $round.ok) { continue }
                    $nm = ([string]$round.name).Trim()
                    if ($nm) { Write-LineJobLog "LD #$idx | ID '$($round.text)' → ชื่อ: $nm"; if ($names -notcontains $nm) { $names += $nm } }
                    else { Write-LineJobLog "LD #$idx | ID '$($round.text)' → สแกนชื่อไม่ได้ (จะไม่ถูกเชิญ)" }
                }
                $groups = @($result.groupList.groups | Where-Object { $null -ne $_ -and $_.name })
                if (-not $names.Count) { Write-LineJobLog "LD #$idx | ไม่มีชื่อที่สแกนได้ → ไม่ต้องเลือกกลุ่ม"; Set-LineMainStatus $idx 'ไม่มีชื่อให้เชิญ' }
                elseif (-not $groups.Count) { Write-LineJobLog "LD #$idx | ไม่พบกลุ่มในหน้า 'กลุ่ม' → เชิญตามชื่อไม่ได้"; Set-LineMainStatus $idx 'ไม่พบกลุ่ม' }
                else {
                    Write-LineJobLog "LD #$idx | พบ $($groups.Count) กลุ่ม → รอเลือกกลุ่ม (ชื่อที่จะเชิญ: $($names -join ', '))"
                    Set-LineMainStatus $idx 'รอเลือกกลุ่ม (pop up)'
                    [void]$script:PickQueue.Add([pscustomobject]@{ Index = $idx; Names = $names; Groups = $groups })
                    $script:PickTimer.Start()
                }
                }
            }
        } catch {
            $why = $_.Exception.Message
            $err = ''
            try { $err = (Read-SharedText ([string]$job.ErrorFile)).Trim() } catch {}
            if ($err.Length -gt 300) { $err = $err.Substring(0, 300) }
            try { Add-Count 'reg' $false } catch {}
            try {
                Set-LineMainStatus $idx "ชุด [$($job.SetName)] เกิดข้อผิดพลาด"
                Write-LineJobLog "LD #$idx | ขั้นตอน 4/4: อ่านผลไม่ได้ ($why) $err | ไฟล์ผล: $($job.Output)"
            } catch {}
        } finally {
            $script:NeedInfo[[int]$job.Index] = Get-Date
            [void]$script:LineJobs.Remove($job)
            try { $job.Process.Dispose() } catch {}
        }
    }
    if ($script:LineJobs.Count -eq 0) { $script:LineJobTimer.Stop() }
    foreach ($ci in $chain) {
        try { Start-LineSelect @([int]$ci) -FromLine } catch { Write-LineJobLog "LD #$ci | เริ่มติ๊กวงกลมต่อไม่ได้: $($_.Exception.Message)" }
    }
})

function Write-ByNameResult([int]$idx, $res) {
    $cg = $res.createGroup
    if ($cg -and $cg.preTick) { try { Write-PreTickLog $idx $cg; Set-TickedNames $idx $cg } catch {} }
    if ($cg.wantedMissing) { Write-LineJobLog "LD #$idx | ✖ ไม่พบกลุ่ม '$($cg.group)' ในหน้า 'กลุ่ม'" ; $script:LineMainStatus[$idx] = 'ไม่พบกลุ่มที่เลือก'; return }
    if (-not $cg.opened) {
        $where = if ($cg.enterFailed) { 'กดกลุ่มแล้วไม่เข้ากลุ่ม' } elseif (-not $cg.chat) { 'กด แชท ไม่ได้' } elseif (-not $cg.menu) { 'หา ≡ ขวาบนไม่เจอ' } elseif (-not $cg.inviteFound) { 'ไม่พบเมนู เชิญ' } else { 'เปิดหน้าเชิญไม่ได้' }
        Write-LineJobLog "LD #$idx | ✖ เข้ากลุ่ม '$($cg.group)' แล้ว$where"
        $script:LineMainStatus[$idx] = "เชิญตามชื่อไม่สำเร็จ ($where)"
        return
    }
    $okN = 0; $allN = 0
    foreach ($e in @($res.inviteNames)) {
        if ($null -eq $e) { continue }
        $allN++
        if ($e.ticked) { $okN++ }
        $how = if ($e.already) { 'ติ๊กไว้แล้ว (สีเขียว) ไม่ติ๊กซ้ำ' } elseif ($e.ticked) { 'ติ๊กแล้ว ✔' + $(if ($e.matched -and $e.matched -ne $e.name) { " (ตรงกับ '$($e.matched)')" } else { '' }) } elseif (-not $e.typed) { "พิมพ์ชื่อไม่ได้: $($e.error)" + $(if ($e.dump) { " | ไฟล์หน้าจอ: $($e.dump)" } else { '' }) } elseif (-not $e.found) { 'ไม่พบชื่อนี้ในรายชื่อเชิญ' } else { [string]$e.error }
        Write-LineJobLog "LD #$idx | เชิญ '$($e.name)': $how$(if ($e.typeMethod) { " [พิมพ์ด้วย $($e.typeMethod)]" })"
    }
    Write-LineJobLog "LD #$idx | $(if ($okN -eq $allN) { '✔' } else { '✖' }) เชิญตามชื่อเข้ากลุ่ม '$($cg.group)': ติ๊กได้ $okN/$allN ชื่อ (ยังไม่กดยืนยันเชิญ ตรวจแล้วกดเองบนจอ)"
    $script:LineMainStatus[$idx] = "กลุ่ม '$($cg.group)': ติ๊กแล้ว $okN/$allN ชื่อ"
}

function Get-GroupLabels($groups) {
    $gl = @($groups)
    $cnt = @{}
    foreach ($g in $gl) { $k = "$($g.members)"; $cnt[$k] = 1 + [int]$cnt[$k] }
    $out = @()
    for ($i = 0; $i -lt $gl.Count; $i++) {
        $m = "$($gl[$i].members)"
        $txt = if ($m -ne '') { "$m คน" } else { 'ไม่ทราบจำนวนคน' }
        if ([int]$cnt[$m] -gt 1) { $txt += "   (กลุ่มที่ $($i + 1))" }
        $out += $txt
    }
    return , $out
}
function Save-GroupCache([int]$idx, $groups) {
    $list = @($groups | Where-Object { $_ -and $_.name } | ForEach-Object { @{ name = [string]$_.name; members = $_.members } })
    if (-not $list.Count) { return }
    $cfg.GroupCache[(Get-InfoKey $idx)] = @{ Time = (Get-Date).ToString('yyyy-MM-dd HH:mm'); Groups = $list }
    Save-Config
}
function Get-GroupCache([int]$idx) { return $cfg.GroupCache[(Get-InfoKey $idx)] }
function Set-GroupPick([int]$idx, [string]$name) { $cfg.GroupPick[(Get-InfoKey $idx)] = $name; Save-Config }
$script:PreGroup = @{}
# เลือกกลุ่มให้ทุกเครื่องก่อนเริ่ม (ใช้รายชื่อกลุ่มที่จำไว้) -> รันรวดเดียวไม่ต้องรอ pop up กลางทาง
# returns @{ idx = 'group name' or '' (= scan during the run) } or $null when cancelled
function Show-GroupPreselect([int[]]$targets) {
    $withCache = @($targets | Where-Object { $c = Get-GroupCache $_; $c -and @($c.Groups).Count })
    $out = @{}
    foreach ($i in $targets) { $out[$i] = '' }
    if (-not $withCache.Count) { return $out }   # nothing remembered yet: scan during the run (first time only)
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "เลือกกลุ่มที่จะเชิญ  —  $($targets.Count) เครื่อง"
    $dlg.StartPosition = 'CenterParent'
    $wa = [System.Windows.Forms.Screen]::FromControl($form).WorkingArea
    $dlg.Size = New-Object System.Drawing.Size([Math]::Min(860, $wa.Width - 40), [Math]::Min(180 + 46 * $targets.Count + 120, $wa.Height - 40))
    $dlg.MinimumSize = New-Object System.Drawing.Size(720, 320)
    $dlg.BackColor = $uiBg; $dlg.ForeColor = $uiInk; $dlg.Font = $font
    $dlg.ShowInTaskbar = $false; $dlg.MaximizeBox = $false; $dlg.MinimizeBox = $false
    try { Set-DarkTitle $dlg } catch {}
    $lay = New-Object System.Windows.Forms.TableLayoutPanel
    $lay.Dock = 'Fill'; $lay.ColumnCount = 3; $lay.AutoScroll = $true
    $lay.Padding = New-Object System.Windows.Forms.Padding(28, 16, 28, 8)
    [void]$lay.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 240)))
    [void]$lay.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 380)))
    [void]$lay.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100)))
    $script:pgRow = 0
    function Add-PgRow([object[]]$cells) {
        [void]$lay.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))
        $lay.RowCount = $script:pgRow + 1
        for ($c = 0; $c -lt $cells.Count; $c++) { if ($cells[$c]) { $lay.Controls.Add($cells[$c], $c, $script:pgRow) } }
        $script:pgRow++
    }
    function New-PgLabel([string]$t, $color, $f) {
        $l = New-Object System.Windows.Forms.Label
        $l.Text = $t; $l.AutoSize = $false; $l.Height = 34; $l.Dock = 'Fill'; $l.TextAlign = 'MiddleLeft'
        $l.ForeColor = $color; if ($f) { $l.Font = $f }
        $l.Margin = New-Object System.Windows.Forms.Padding(0, 2, 8, 2)
        return $l
    }
    $scanItem = '— สแกนตอนรัน (ขึ้นหน้าต่างให้เลือกหลังเพิ่ม ID) —'
    $intro = New-PgLabel 'เลือกกลุ่มให้แต่ละเครื่องตอนนี้ แล้วโปรแกรมจะเพิ่ม ID → เข้ากลุ่มนี้ → เชิญตามชื่อ รวดเดียวไม่ต้องรอ' $uiMuted $fontSmall
    $intro.Height = 26
    $lay.SetColumnSpan($intro, 3)
    Add-PgRow @($intro)
    # one group name for every machine
    $all = New-Object System.Windows.Forms.ComboBox
    $all.DropDownStyle = 'DropDownList'; $all.FlatStyle = 'Flat'; $all.BackColor = $uiInput; $all.ForeColor = $uiInk; $all.Dock = 'Fill'
    $all.Margin = New-Object System.Windows.Forms.Padding(0, 5, 8, 5)
    $counts = @()
    foreach ($i in $withCache) { foreach ($g in @((Get-GroupCache $i).Groups)) { $m = "$($g.members)"; if ($m -ne '' -and $counts -notcontains $m) { $counts += $m } } }
    foreach ($m in @($counts | Sort-Object { [int]$_ })) { [void]$all.Items.Add("$m คน") }
    $bAll = New-Btn 'ใช้กับทุกเครื่อง' $null 'ghost'
    $bAll.Anchor = 'Left'
    Add-PgRow @((New-PgLabel 'ทุกเครื่องใช้กลุ่มที่มี' $uiAccentText $fontBold), $all, $bAll)
    $head1 = New-PgLabel 'เครื่อง' $uiFaint $fontSmall; $head2 = New-PgLabel 'กลุ่ม' $uiFaint $fontSmall; $head3 = New-PgLabel 'รายชื่อกลุ่มอัปเดตเมื่อ' $uiFaint $fontSmall
    foreach ($h in @($head1, $head2, $head3)) { $h.Height = 24 }
    Add-PgRow @($head1, $head2, $head3)
    $combos = @{}
    foreach ($i in $targets) {
        $nm = [string]$script:rowMap[[string]$i].Cells['LineName'].Value
        $cache = Get-GroupCache $i
        $cb = New-Object System.Windows.Forms.ComboBox
        $cb.DropDownStyle = 'DropDownList'; $cb.FlatStyle = 'Flat'; $cb.BackColor = $uiInput; $cb.ForeColor = $uiInk; $cb.Dock = 'Fill'
        $cb.Margin = New-Object System.Windows.Forms.Padding(0, 5, 8, 5)
        [void]$cb.Items.Add($scanItem)
        $gl = @()
        if ($cache) { $gl = @($cache.Groups) }
        foreach ($lab in (Get-GroupLabels $gl)) { [void]$cb.Items.Add($lab) }
        $cb.Tag = @{ Groups = $gl }
        $sel = 0
        $last = [string]$cfg.GroupPick[(Get-InfoKey $i)]
        for ($k = 0; $k -lt $gl.Count; $k++) { if ([string]$gl[$k].name -eq $last) { $sel = $k + 1 } }
        $cb.SelectedIndex = $sel
        $combos[$i] = $cb
        $when = if ($cache) { [string]$cache.Time } else { 'ยังไม่เคยสแกน' }
        Add-PgRow @((New-PgLabel ("LD #$i" + $(if ($nm) { "  $nm" } else { '' })) $uiInk $null), $cb, (New-PgLabel $when $uiFaint $fontSmall))
    }
    $bAll.Add_Click({
        $want = ([string]$all.SelectedItem -replace '[^\d]', '')
        if (-not $want) { return }
        foreach ($cb in $combos.Values) {
            $gl = @($cb.Tag.Groups)
            for ($k = 0; $k -lt $gl.Count; $k++) { if ("$($gl[$k].members)" -eq $want) { $cb.SelectedIndex = $k + 1; break } }
        }
    })
    $bar = New-Object System.Windows.Forms.FlowLayoutPanel
    $bar.Dock = 'Bottom'; $bar.AutoSize = $true; $bar.FlowDirection = 'RightToLeft'
    $bar.Padding = New-Object System.Windows.Forms.Padding(28, 10, 28, 16)
    $bar.BackColor = $uiBg
    $script:PreOk = $false
    $bGo = New-Btn '▶  เริ่ม' { $script:PreOk = $true; $dlg.Close() } 'line'
    $bCancel = New-Btn 'ยกเลิก' { $script:PreOk = $false; $dlg.Close() } 'ghost'
    $bGo.Margin = New-Object System.Windows.Forms.Padding(8, 0, 0, 0)
    $bar.Controls.AddRange(@($bGo, $bCancel))
    $dlg.Controls.Add($lay)
    $dlg.Controls.Add($bar)
    $dlg.AcceptButton = $bGo
    try { Apply-Texts $dlg } catch {}
    [void]$dlg.ShowDialog($form)
    $dlg.Dispose()
    if (-not $script:PreOk) { return $null }
    foreach ($i in $targets) {
        $cb = $combos[$i]
        if ($cb.SelectedIndex -gt 0) {
            $g = [string]@($cb.Tag.Groups)[$cb.SelectedIndex - 1].name
            $out[$i] = $g
            Set-GroupPick $i $g
        }
    }
    return $out
}

# ---------- บันทึกว่าลบ OA จากกลุ่มไหน (oa_replace.json) ----------
$script:OaLogPath = Join-Path $CfgDir 'oa_replace.json'
function Add-OaReplaceRecord([int]$idx, $g, [string[]]$newNames, [bool]$invited) {
    try {
        $list = @()
        $j = Read-JsonSafe $script:OaLogPath
        if ($j) { $list = @($j) }
        $ldName = ''
        try { $ldName = [string]$script:rowMap[[string]$idx].Cells['LineName'].Value } catch {}
        $list += [ordered]@{ time = (Get-Date).ToString('yyyy-MM-dd HH:mm'); ld = "LD #$idx"; ldName = $ldName; group = [string]$g.name; members = $g.members
                             removedOa = @(@($g.items) | Where-Object { $_ -and $_.found } | ForEach-Object { [string]$_.name }); removedCount = [int]$g.removed
                             newOa = @($newNames); invited = $invited }
        if ($list.Count -gt 2000) { $list = @($list | Select-Object -Last 2000) }
        Write-SafeText $script:OaLogPath (ConvertTo-Json -InputObject @($list) -Depth 5)
    } catch {}
}
# แจ้งเตือนเมื่อเสร็จ: เสียง + หน้าต่างสรุป (ไม่บล็อกการทำงานของเครื่องอื่น)
function Show-DoneNotice([string]$title, [string[]]$lines) {
    try { [System.Media.SystemSounds]::Asterisk.Play() } catch {}
    try {
        $f = New-Object System.Windows.Forms.Form
        $f.Text = $title; $f.StartPosition = 'CenterScreen'; $f.TopMost = $true
        $f.Size = New-Object System.Drawing.Size(620, [Math]::Min(560, 190 + 26 * $lines.Count))
        $f.BackColor = $uiBg; $f.ForeColor = $uiInk; $f.Font = $font; $f.ShowInTaskbar = $true; $f.MaximizeBox = $false; $f.MinimizeBox = $false
        try { Set-DarkTitle $f } catch {}
        $head = New-Object System.Windows.Forms.Label
        $head.Text = "✔  $title"; $head.Font = $fontBold; $head.ForeColor = $uiOk; $head.Dock = 'Top'; $head.Height = 40
        $head.Padding = New-Object System.Windows.Forms.Padding(20, 12, 20, 0)
        $body = New-Object System.Windows.Forms.TextBox
        $body.Multiline = $true; $body.ReadOnly = $true; $body.BorderStyle = 'None'; $body.ScrollBars = 'Vertical'
        $body.BackColor = $uiBg; $body.ForeColor = $uiInk; $body.Font = $font; $body.Dock = 'Fill'
        $body.Text = ($lines | ForEach-Object { "• $_" }) -join "`r`n"
        $wrap = New-Object System.Windows.Forms.Panel
        $wrap.Dock = 'Fill'; $wrap.Padding = New-Object System.Windows.Forms.Padding(22, 6, 20, 6); $wrap.Controls.Add($body)
        $bar = New-Object System.Windows.Forms.FlowLayoutPanel
        $bar.Dock = 'Bottom'; $bar.AutoSize = $true; $bar.FlowDirection = 'RightToLeft'; $bar.Padding = New-Object System.Windows.Forms.Padding(20, 6, 20, 14)
        $ok = New-Btn 'ตกลง' $null 'primary'
        $ok.Add_Click({ $this.FindForm().Close() })
        $bar.Controls.Add($ok)
        $f.Controls.Add($wrap); $f.Controls.Add($bar); $f.Controls.Add($head)
        $f.Add_FormClosed({ $this.Dispose() })
        try { Apply-Texts $f } catch {}
        if ($form.Visible) { $f.Show($form) } else { $f.Show() }
    } catch {}
}

# --- เลือกกลุ่มเอง (pop up) → เชิญตามชื่อ ---
$script:PickQueue = New-Object System.Collections.ArrayList
$script:PickOpen = $false
function Show-GroupPicker([int]$idx, [string[]]$names, $groups) {
    $dlg = New-Object System.Windows.Forms.Form
    $nm = [string]$script:rowMap[[string]$idx].Cells['LineName'].Value
    $dlg.Text = "LD #$idx" + $(if ($nm) { "  ($nm)" } else { '' }) + '  —  เลือกกลุ่มที่จะเชิญ'
    $dlg.StartPosition = 'CenterParent'
    $dlg.Size = New-Object System.Drawing.Size(560, 520)
    $dlg.MinimumSize = New-Object System.Drawing.Size(460, 400)
    $dlg.BackColor = $uiBg; $dlg.ForeColor = $uiInk; $dlg.Font = $font
    $dlg.ShowInTaskbar = $false; $dlg.MaximizeBox = $false; $dlg.MinimizeBox = $false
    try { Set-DarkTitle $dlg } catch {}
    $lay = New-Object System.Windows.Forms.TableLayoutPanel
    $lay.Dock = 'Fill'; $lay.ColumnCount = 1; $lay.RowCount = 4
    $lay.Padding = New-Object System.Windows.Forms.Padding(14, 12, 14, 12)
    [void]$lay.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))
    [void]$lay.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))
    [void]$lay.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100)))
    [void]$lay.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))
    $l1 = New-Object System.Windows.Forms.Label
    $l1.AutoSize = $true; $l1.ForeColor = $uiMuted
    $l1.MaximumSize = New-Object System.Drawing.Size(520, 0)
    $l1.Text = "ชื่อที่จะค้นหาแล้วติ๊กในหน้าเชิญ ($($names.Count) คน):`r`n" + (($names | ForEach-Object { "  • $_" }) -join "`r`n")
    $l1.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 10)
    $l2 = New-Object System.Windows.Forms.Label
    $l2.AutoSize = $true; $l2.Text = 'เลือกกลุ่ม (ดับเบิลคลิก หรือกด "เชิญเข้ากลุ่มนี้")'
    $l2.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 6)
    $lb = New-Object System.Windows.Forms.ListBox
    $lb.Dock = 'Fill'; $lb.BorderStyle = 'FixedSingle'; $lb.IntegralHeight = $false
    $lb.BackColor = $uiInput; $lb.ForeColor = $uiInk; $lb.Font = $font; $lb.ItemHeight = 26
    foreach ($lab in (Get-GroupLabels $groups)) { [void]$lb.Items.Add($lab) }
    if ($lb.Items.Count) {
        $lb.SelectedIndex = 0
        $lastPick = [string]$cfg.GroupPick[(Get-InfoKey $idx)]
        $gArr = @($groups)
        for ($k = 0; $k -lt $gArr.Count; $k++) { if ([string]$gArr[$k].name -eq $lastPick) { $lb.SelectedIndex = $k } }
    }
    $bar = New-Object System.Windows.Forms.FlowLayoutPanel
    $bar.Dock = 'Fill'; $bar.AutoSize = $true; $bar.FlowDirection = 'RightToLeft'
    $bar.Margin = New-Object System.Windows.Forms.Padding(0, 10, 0, 0)
    $script:PickResult = $null
    $ok = New-Btn 'เชิญเข้ากลุ่มนี้' { if ($lb.SelectedIndex -ge 0) { $script:PickResult = [string]@($groups)[$lb.SelectedIndex].name; $dlg.Close() } } 'primary'
    $skip = New-Btn 'ข้ามเครื่องนี้' { $script:PickResult = $null; $dlg.Close() } 'ghost'
    $ok.Margin = New-Object System.Windows.Forms.Padding(8, 0, 0, 0)
    $bar.Controls.AddRange(@($ok, $skip))
    $lb.Add_DoubleClick({ if ($lb.SelectedIndex -ge 0) { $script:PickResult = [string]@($groups)[$lb.SelectedIndex].name; $dlg.Close() } })
    $lay.Controls.Add($l1, 0, 0); $lay.Controls.Add($l2, 0, 1); $lay.Controls.Add($lb, 0, 2); $lay.Controls.Add($bar, 0, 3)
    $dlg.Controls.Add($lay)
    $dlg.AcceptButton = $ok
    try { if (-not $form.Visible) { Show-Main } } catch {}
    try { Apply-Texts $dlg } catch {}
    [void]$dlg.ShowDialog($form)
    $dlg.Dispose()
    return $script:PickResult
}
$script:PickTimer = New-Object System.Windows.Forms.Timer
$script:PickTimer.Interval = 400
$script:PickTimer.Add_Tick({
    if ($script:PickOpen) { return }
    $script:PickTimer.Stop()
    if ($script:PickQueue.Count -eq 0) { return }
    $p = $script:PickQueue[0]
    $script:PickQueue.RemoveAt(0)
    $script:PickOpen = $true
    try {
        $choice = Show-GroupPicker ([int]$p.Index) @($p.Names) @($p.Groups)
        if ($choice) { Set-GroupPick ([int]$p.Index) $choice; Start-LineInviteByName ([int]$p.Index) $choice @($p.Names) }
        else { Write-LineJobLog "LD #$($p.Index) | ข้ามการเลือกกลุ่ม"; Set-LineMainStatus ([int]$p.Index) 'ข้ามการเลือกกลุ่ม' }
    } catch { Write-LineJobLog "LD #$($p.Index) | pop up เลือกกลุ่มผิดพลาด: $($_.Exception.Message)" }
    finally { $script:PickOpen = $false }
    if ($script:PickQueue.Count -gt 0) { $script:PickTimer.Start() }
})
function Start-LineInviteByName([int]$idx, [string]$groupName, [string[]]$names) {
    $scriptPath = Join-Path $PSScriptRoot 'Adb-LineAddFriend.ps1'
    $adbPath = [string]$Sync.Adb
    if (-not (Test-Path -LiteralPath $scriptPath) -or -not $adbPath -or -not (Test-Path -LiteralPath $adbPath)) { Write-LineJobLog "LD #$idx | เชิญตามชื่อไม่ได้: ไม่พบ Adb-LineAddFriend.ps1 หรือ adb.exe"; return }
    if (-not (Test-RowReady $idx)) { Write-LineJobLog "LD #$idx | เชิญตามชื่อไม่ได้: LD ไม่ได้เปิด / ยังไม่เชื่อม ADB"; return }
    if (Test-RowBusy $idx) { Write-LineJobLog "LD #$idx | เชิญตามชื่อไม่ได้: เครื่องนี้มีงานอื่นทำอยู่"; return }
    $serial = Get-LdSerial $idx
    if (-not $serial) { Write-LineJobLog "LD #$idx | เชิญตามชื่อไม่ได้: ไม่พบ ADB Serial"; return }
    $ldc = Join-Path ([string]$Sync.LdDir) 'ldconsole.exe'
    if (-not (Test-Path -LiteralPath $ldc)) { Write-LineJobLog "LD #$idx | ไม่พบ ldconsole.exe: พิมพ์ได้เฉพาะชื่อภาษาอังกฤษ/ตัวเลข" }
    $outDir = Join-Path $env:APPDATA 'LDAdbConnector\LineGroup'
    [void][System.IO.Directory]::CreateDirectory($outDir)
    $exe = Join-Path $PSHOME 'powershell.exe'
    if (-not (Test-Path $exe)) { $exe = 'powershell.exe' }
    $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss_fff')
    $stdout = Join-Path $outDir "LD${idx}_${stamp}_byname.json"
    $stderr = Join-Path $outDir "LD${idx}_${stamp}_byname.err.txt"
    $gB64 = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($groupName))
    $nB64 = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject @($names) -Compress)))
    $argLine = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $scriptPath + '"'), '-Adb', ('"' + $adbPath + '"'),
        '-Serial', ('"' + $serial + '"'), '-LaunchLine', '-GroupOnly', '-JoinGroupB64', $gB64, '-InviteNamesB64', $nB64,
        '-LdConsole', ('"' + $ldc + '"'), '-LdIndex', "$idx") -join ' '
    $pt = Get-PreTickArg
    if ($pt) { $argLine += ($pt -replace ' -LdConsole "[^"]*"', '') }
    try {
        $p = Start-Process -FilePath $exe -ArgumentList $argLine -WorkingDirectory $PSScriptRoot -PassThru -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr
    } catch { Write-LineJobLog "LD #$idx | เริ่มเชิญตามชื่อไม่ได้: $($_.Exception.Message)"; return }
    [void]$script:InfoJobs.Add([pscustomobject]@{ Kind = 'byname'; Detail = "กลุ่ม '$groupName' · $($names.Count) ชื่อ"; Index = $idx; Process = $p; Output = $stdout; ErrorFile = $stderr; Started = (Get-Date); Timeout = (180 + 30 * $names.Count) })
    Add-Stat $idx 'invite'
    Write-LineJobLog "LD #$idx | เริ่มเชิญตามชื่อ: หน้าแรก → กลุ่ม → '$groupName' → แชท → ≡ → เชิญ → ค้นหาด้วยชื่อแล้วติ๊ก ($($names.Count) ชื่อ)"
    Set-LineMainStatus $idx "กำลังเชิญเข้ากลุ่ม '$groupName'"
    $script:InfoJobTimer.Start()
    try { Update-Status } catch {}
}

# --- ดึงข้อมูล LINE อัตโนมัติ: เครื่องที่ยังไม่มีชื่อ และหลังทำงานเสร็จ (ตอนเครื่องว่าง ทีละไม่เกิน 2 เครื่อง) ---
$script:ReadySince = @{}
$script:NeedInfo = @{}
$script:AutoTried = @{}
function Invoke-AutoInfo {
    return  # ปิดการดึงอัตโนมัติ: ดึงจากปุ่ม "ดึงข้อมูล LINE" เท่านั้น
    $running = @($script:InfoJobs | Where-Object { $_.Kind -eq 'info' }).Count
    if ($running -ge 2) { return }
    $waiting = @($script:PickQueue | ForEach-Object { [int]$_.Index })
    foreach ($row in @($grid.Rows)) {
        if ($null -eq $row.Tag) { continue }
        $i = [int]$row.Tag
        if (-not (Test-RowReady $i) -or -not $script:ReadySince.ContainsKey($i)) { continue }
        if (((Get-Date) - $script:ReadySince[$i]).TotalSeconds -lt 20) { continue }     # let the LD finish starting
        if ((Test-RowBusy $i) -or $waiting -contains $i) { continue }
        $li = $cfg.LineInfo[(Get-InfoKey $i)]
        $noName = -not ($li -and [string]$li.Name)
        $after = $script:NeedInfo.ContainsKey($i) -and ((Get-Date) - $script:NeedInfo[$i]).TotalSeconds -ge 8
        if (-not $noName -and -not $after) { continue }
        if ($noName -and -not $after -and $script:AutoTried.ContainsKey($i) -and ((Get-Date) - $script:AutoTried[$i]).TotalMinutes -lt 10) { continue }
        $script:AutoTried[$i] = Get-Date
        [void]$script:NeedInfo.Remove($i)
        Write-LineJobLog "LD #$i | ดึงข้อมูล LINE อัตโนมัติ ($(if ($noName) { 'ยังไม่มีชื่อ' } else { 'อัปเดตหลังทำงานเสร็จ' }))"
        Start-LineInfoFetch @($i) -Quiet
        $running++
        if ($running -ge 2) { return }
    }
}

# --- ดึงข้อมูล LINE (ชื่อ / เพื่อน / กลุ่ม) ผ่าน Adb-LineInfo.ps1 ---
$script:InfoJobs = New-Object System.Collections.ArrayList
$script:InfoJobTimer = New-Object System.Windows.Forms.Timer
$script:InfoJobTimer.Interval = 600
function Get-LdSerial([int]$idx) {
    $key = [string]$idx
    if ($cfg.SerialMap.ContainsKey($key) -and $cfg.SerialMap[$key]) { return [string]$cfg.SerialMap[$key] }
    $item = @($Sync.Snapshot | Where-Object { [int]$_.Index -eq $idx } | Select-Object -First 1)
    if ($item.Count -and $item[0].Serial) { return [string]$item[0].Serial }
    return ''
}
function Get-CheckedOrAllIdx {
    try { [void]$grid.EndEdit() } catch {}
    $ticked = @()
    $all = @()
    foreach ($row in $grid.Rows) {
        if ($null -eq $row.Tag) { continue }
        $all += [int]$row.Tag
        if ([string]$row.Cells['Chk'].Value -eq 'True') { $ticked += [int]$row.Tag }
    }
    if ($ticked.Count) { return , $ticked }
    return , $all
}
function Set-LineInfoRow([int]$idx, [string]$name, $friends, $groups) {
    $ik = Get-InfoKey $idx
    if (-not $cfg.LineInfo.ContainsKey($ik)) { $cfg.LineInfo[$ik] = New-InfoRec }
    $li = $cfg.LineInfo[$ik]
    $k = [string]$idx
    if ($name) { $li['Name'] = $name }
    if ($null -ne $friends -and "$friends" -ne '') { $li['Friends'] = [string]$friends }
    if ($null -ne $groups -and "$groups" -ne '') { $li['Groups'] = [string]$groups }
    Save-Config
    $row = $script:rowMap[$k]
    if ($row) {
        Set-Cell $row 'LineName' ([string]$li['Name'])
        Set-Cell $row 'Friends' ([string]$li['Friends'])
        Set-Cell $row 'Groups' ([string]$li['Groups'])
    }
}
function Start-LineInfoFetch([int[]]$targets, [switch]$Quiet) {
    $scriptPath = Join-Path $PSScriptRoot 'Adb-LineInfo.ps1'
    if (-not (Test-Path -LiteralPath $scriptPath)) {
        if (-not $Quiet) { [void][System.Windows.Forms.MessageBox]::Show($form, "ไม่พบ $scriptPath", 'ดึงข้อมูล LINE') }
        return
    }
    $adbPath = [string]$Sync.Adb
    if (-not $adbPath -or -not (Test-Path -LiteralPath $adbPath)) {
        if (-not $Quiet) { [void][System.Windows.Forms.MessageBox]::Show($form, 'ยังไม่พบ adb.exe กรุณาเลือกโฟลเดอร์ LDPlayer ก่อน', 'ดึงข้อมูล LINE') }
        return
    }
    $targets = @($targets | Where-Object { $null -ne $_ } | ForEach-Object { [int]$_ } | Select-Object -Unique)
    if (-not $targets.Count) {
        [void][System.Windows.Forms.MessageBox]::Show($form, 'ยังไม่มีเครื่องที่เชื่อม ADB ในตาราง', 'ดึงข้อมูล LINE')
        return
    }
    $outDir = Join-Path $env:APPDATA 'LDAdbConnector\LineInfo'
    [void][System.IO.Directory]::CreateDirectory($outDir)
    $exe = Join-Path $PSHOME 'powershell.exe'
    if (-not (Test-Path $exe)) { $exe = 'powershell.exe' }
    $started = 0
    foreach ($idx in $targets) {
        if (-not (Test-RowReady $idx)) { Write-LineJobLog "LD #$idx | ข้าม: LD ยังไม่เปิด / ยังไม่เชื่อม ADB"; continue }
        if (@($script:LineJobs) | Where-Object { $_.Index -eq $idx }) { Write-LineJobLog "LD #$idx | ข้ามการดึงข้อมูล: กำลังรัน LINE Script อยู่"; continue }
        if (@($script:InfoJobs) | Where-Object { $_.Index -eq $idx }) { Write-LineJobLog "LD #$idx | ข้าม: มีงานอื่นทำอยู่ในเครื่องนี้"; continue }
        if (@($script:LineStartQueue.ToArray()) -contains $idx) { Write-LineJobLog "LD #$idx | ข้าม: อยู่ในคิว LINE Script"; continue }
        $serial = Get-LdSerial $idx
        if (-not $serial) { Write-LineJobLog "LD #$idx | ดึงข้อมูลไม่ได้: ไม่พบ ADB Serial"; continue }
        $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss_fff')
        $stdout = Join-Path $outDir "LD${idx}_${stamp}.json"
        $stderr = Join-Path $outDir "LD${idx}_${stamp}.err.txt"
        $argLine = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $scriptPath + '"'), '-Adb', ('"' + $adbPath + '"'),
            '-Serial', ('"' + $serial + '"'), '-OutDir', ('"' + $outDir + '"'), '-LaunchLine') -join ' '
        try {
            $p = Start-Process -FilePath $exe -ArgumentList $argLine -WorkingDirectory $PSScriptRoot -PassThru -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr
        } catch {
            Write-LineJobLog "LD #$idx | เริ่มดึงข้อมูลไม่ได้: $($_.Exception.Message)"
            continue
        }
        [void]$script:InfoJobs.Add([pscustomobject]@{ Kind = 'info'; Detail = 'อ่านชื่อ / เพื่อน / กลุ่ม'; Index = $idx; Process = $p; Output = $stdout; ErrorFile = $stderr; Started = (Get-Date); Timeout = 120 })
        Write-LineJobLog "LD #$idx | เริ่มดึงข้อมูล LINE (Serial $serial)"
        $started++
    }
    if ($started) { $script:InfoJobTimer.Start() }
    try { Update-Status } catch {}
}
function Get-ExcludeArg {
    $ex = @(([string]$cfg.ExcludeNames) -split '[,\r\n]+' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
    if (-not $ex.Count) { return '' }
    return " -ExcludeB64 $([Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject @($ex) -Compress))))"
}
function Get-PreTickArg {
    # also carries the "do not tick" names, so searching names before the circles skips them too
    $terms = @(([string]$cfg.PreTickNames) -split '[,\r\n]+' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
    if (-not $terms.Count) { return (Get-ExcludeArg) }
    return " -PreTickB64 $([Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject @($terms) -Compress)))) -LdConsole `"$(Join-Path ([string]$Sync.LdDir) 'ldconsole.exe')`"" + (Get-ExcludeArg)
}
function Write-PreTickLog([int]$idx, $cg) {
    $p = $cg.preTick
    if (-not $p) { return }
    foreach ($i in @($p.items)) {
        if ($null -eq $i) { continue }
        $parts = @()
        if (@($i.ticked).Count) { $parts += "ติ๊ก $(@($i.ticked).Count): $(@($i.ticked) -join ', ')" }
        if (@($i.already).Count) { $parts += "เขียวอยู่แล้ว $(@($i.already).Count)" }
        if (@($i.failed).Count) { $parts += "ติ๊กไม่ติด: $(@($i.failed) -join ', ')" }
        if (@($i.excluded).Count) { $parts += "ข้าม (ชื่อห้ามติ๊ก): $(@($i.excluded) -join ', ')" }
        if (@($i.found).Count) { $parts = @("เจอ $(@($i.found).Count): $(@($i.found) -join ', ')") + $parts }
        if ($i.error) { $parts += $(if (-not $i.typed) { "พิมพ์ไม่ได้: $($i.error)" } elseif ($i.error -match 'No result') { 'ไม่พบชื่อนี้' } else { [string]$i.error }) }
        Write-LineJobLog "LD #$idx | ค้นหาชื่อก่อนติ๊ก '$($i.term)': $($parts -join ' · ')"
    }
    Write-LineJobLog "LD #$idx | กดกากบาทล้างช่องค้นหาแล้ว$(if ($p.clear -eq 'keys') { ' (ไม่พบปุ่ม X ใช้ลบด้วยคีย์บอร์ด)' } elseif ($p.clear -eq 'nofield') { ' (ไม่พบช่องค้นหา)' }) → ติ๊กวงกลมต่อ"
}
function Write-GroupStepLog([int]$idx, $cg) {
    # returns $true when the friend selection screen is open (ticking can start)
    if (-not $cg) { return $false }
    $gname = if ($cg.group) { " [$($cg.group)$(if ($null -ne $cg.members) { " $($cg.members) คน" })]" } else { '' }
    $limit = [int]$cfg.MaxGroupMembers
    if ($cg.checked) { Write-LineJobLog "LD #$idx | สแกนกลุ่ม (ชื่อ=จำนวนคน): $(@($cg.checked) -join ', ')" }
    if ($cg.opened) {
        if ($cg.mode -eq 'invite') { Write-LineJobLog "LD #$idx | หน้าแรก → กลุ่ม → เข้ากลุ่ม$gname → แชท → ≡ → เชิญ → เปิดหน้าเลือกเพื่อนแล้ว → เริ่มติ๊กวงกลมต่ออัตโนมัติ" }
        elseif ($cg.allTooBig) { Write-LineJobLog "LD #$idx | ทุกกลุ่มมีสมาชิกเกิน $limit คน → กดสร้างกลุ่มใหม่ → เปิดหน้าเลือกเพื่อนแล้ว → เริ่มติ๊กวงกลมต่ออัตโนมัติ" }
        elseif ($cg.noGroup) { Write-LineJobLog "LD #$idx | หน้าแรก → ยังไม่มีกลุ่ม → กดสร้างกลุ่ม → เปิดหน้าเลือกเพื่อนแล้ว → เริ่มติ๊กวงกลมต่ออัตโนมัติ" }
        else { Write-LineJobLog "LD #$idx | กลุ่ม → สร้างกลุ่ม → เปิดหน้าเลือกเพื่อนแล้ว" }
        try { Write-PreTickLog $idx $cg } catch {}
        return $true
    }
    if ($cg.mode -eq 'invite') {
        if (-not $cg.groupFound) { Write-LineJobLog "LD #$idx | หากลุ่มที่สมาชิกไม่เกิน $limit คนไม่เจอ (ไม่เริ่มติ๊กวงกลม)" }
        elseif ($cg.enterFailed) { Write-LineJobLog "LD #$idx | เจอกลุ่ม$gname ในรายการ แต่กดแล้วไม่เข้ากลุ่ม (ลองกด $($cg.tapTries) ครั้ง) (ไม่เริ่มติ๊กวงกลม)$(if ($cg.dump) { " | ไฟล์หน้าจอ: $($cg.dump)" })" }
        elseif (-not $cg.chat) { Write-LineJobLog "LD #$idx | เข้ากลุ่ม$gname แล้ว แต่กด 'แชท' ไม่ได้ (ไม่เริ่มติ๊กวงกลม)$(if ($cg.dump) { " | ไฟล์หน้าจอ: $($cg.dump)" })" }
        elseif (-not $cg.menu) {
            Write-LineJobLog "LD #$idx | เข้ากลุ่ม$gname แล้ว แต่กด ≡ ขวาบนแล้วไม่เห็นปุ่มเชิญ (ลองแล้ว: $(@($cg.menuTried) -join ' > ')) (ไม่เริ่มติ๊กวงกลม)"
            if ($cg.chatShot) { Write-LineJobLog "LD #$idx | ภาพหน้าจอแชทตอนนั้น: $($cg.chatShot)" }
        }
        elseif (-not $cg.inviteFound) { Write-LineJobLog "LD #$idx | เข้ากลุ่ม$gname แล้ว แต่หาปุ่มเชิญในเมนูไม่เจอ (ไม่เริ่มติ๊กวงกลม)" }
        else { Write-LineJobLog "LD #$idx | กดเชิญแล้ว แต่ไม่เห็นหน้าเลือกเพื่อน (ไม่เริ่มติ๊กวงกลม)" }
    } elseif ($cg.found) { Write-LineJobLog "LD #$idx | กดสร้างกลุ่มแล้ว แต่ไม่เห็นหน้าเลือกเพื่อน (ไม่เริ่มติ๊กวงกลม)" }
    else { Write-LineJobLog "LD #$idx | หาปุ่มสร้างกลุ่ม/เพิ่มกลุ่มในหน้าแรกไม่เจอ (ไม่เริ่มติ๊กวงกลม)" }
    return $false
}
# --- ชื่อที่ค้นเจอในช่องค้นหา (สร้างกลุ่ม / เชิญ): โชว์สดในคอลัมน์สถานะ ---
# ชื่อที่ "ติ๊กวงกลมไปแล้ว" จากการค้นหาชื่อ (ต่อเครื่อง, รอบล่าสุด) -> ใช้โชว์ในช่องสถานะ + เช็คซ้ำกับเครื่องอื่น
$script:TickedNames = @{}
function Get-NameKey([string]$n) { return (($n -replace '\s+', ' ').Trim().ToLowerInvariant()) }
function Set-TickedNames([int]$idx, $cg) {
    $list = @()
    if ($cg -and $cg.preTick) {
        foreach ($i in @($cg.preTick.items)) {
            if ($null -eq $i) { continue }
            $list += @(@($i.ticked) + @($i.already) | Where-Object { $_ })
        }
    }
    $list = @($list | Select-Object -Unique)
    if (-not $list.Count) { [void]$script:TickedNames.Remove($idx); try { $grid.Invalidate() } catch {}; return }
    $script:TickedNames[$idx] = $list
    $dups = Get-TickDups $idx
    $parts = @(); $dupParts = @()
    foreach ($n in $list) {
        $o = $dups[(Get-NameKey $n)]
        if ($o) { $parts += "$n [ซ้ำ LD #$($o -join ', #')]"; $dupParts += "$n (LD #$($o -join ', #'))" } else { $parts += $n }
    }
    Write-LineJobLog "LD #$idx | ติ๊กจากการค้นหาชื่อ $($list.Count) ชื่อ: $($parts -join ', ')"
    if ($dupParts.Count) {
        Write-LineJobLog "LD #$idx | ⚠ ชื่อซ้ำกับเครื่องอื่นที่เปิดอยู่ $($dupParts.Count) ชื่อ: $($dupParts -join ', ')"
        try { [System.Media.SystemSounds]::Exclamation.Play() } catch {}
    } else { Write-LineJobLog "LD #$idx | ✔ ไม่มีชื่อซ้ำกับเครื่องอื่นที่เปิดอยู่" }
    try { $grid.Invalidate() } catch {}
}
# name key -> other LD numbers that ticked the same name
function Get-TickDups([int]$idx) {
    $out = @{}
    if (-not $script:TickedNames.ContainsKey($idx)) { return $out }
    $mine = @{}
    foreach ($n in @($script:TickedNames[$idx])) { $mine[(Get-NameKey $n)] = $true }
    foreach ($k in @($script:TickedNames.Keys)) {
        if ([int]$k -eq $idx) { continue }
        # only LDs that are open right now (shown in the table)
        if (-not $script:rowMap.ContainsKey([string]$k) -or -not [bool]$script:RowReady[[int]$k]) { continue }
        foreach ($n in @($script:TickedNames[$k])) {
            $nk = Get-NameKey $n
            if ($mine.ContainsKey($nk)) { if (-not $out.ContainsKey($nk)) { $out[$nk] = @() }; if ($out[$nk] -notcontains [int]$k) { $out[$nk] += [int]$k } }
        }
    }
    return $out
}
function Get-ProgText([string]$path) {
    if (-not $path -or -not (Test-Path -LiteralPath $path)) { return '' }
    $raw = ''
    try { $raw = [System.IO.File]::ReadAllText($path, [System.Text.Encoding]::UTF8).Trim() } catch { return '' }
    if (-not $raw) { return '' }
    $f = $raw -split "`t"
    $state = $f[0]; $term = if ($f.Count -gt 1) { $f[1] } else { '' }
    $names = if ($f.Count -gt 2 -and $f[2]) { @($f[2] -split '\|') } else { @() }
    $list = ($names | Select-Object -First 6) -join ', '
    if ($names.Count -gt 6) { $list += " …(+$($names.Count - 6))" }
    switch ($state) {
        'search' { return "ค้นหา '$term'…" }
        'none'   { return "ค้นหา '$term' → ไม่เจอชื่อ" }
        'found'  { return "ค้นหา '$term' → เจอ $($names.Count): $list" }
        'tick'   { return "ค้นหา '$term' → ติ๊กแล้ว $($names.Count): $list" }
    }
    return ''
}
function Get-FoundSummary($cg) {
    if (-not $cg -or -not $cg.preTick) { return '' }
    $parts = @()
    foreach ($i in @($cg.preTick.items)) {
        if ($null -eq $i) { continue }
        $fn = @($i.found | Where-Object { $_ })
        $parts += $(if ($fn.Count) { "'$($i.term)' เจอ: $($fn -join ', ')" } else { "'$($i.term)' ไม่เจอ" })
    }
    return ($parts -join ' | ')
}
# ---------- ค้นหา LINE OA: หน้าแรก → ช่องค้นหา → พิมพ์ชื่อ → รายงานว่า # ไหนเจอ / ไม่เจอ ----------
$script:FindOaLogPath = Join-Path $CfgDir 'findoa_history.json'
$script:FindOaBatch = $null
$script:FindOaLast = $null
function Get-FindOaNames([string]$s) { return @(([string]$s) -split '[,\r\n]+' | ForEach-Object { $_.Trim() } | Where-Object { $_ } | Select-Object -Unique) }
function Start-LineFindOa([int[]]$targets, [switch]$Auto) {
    $scriptPath = Join-Path $PSScriptRoot 'Adb-LineAddFriend.ps1'
    if (-not (Test-Path -LiteralPath $scriptPath)) { if (-not $Auto) { [void][System.Windows.Forms.MessageBox]::Show($form, "ไม่พบ $scriptPath", 'ค้นหา LINE OA') }; return }
    $adbPath = [string]$Sync.Adb
    if (-not $adbPath -or -not (Test-Path -LiteralPath $adbPath)) { if (-not $Auto) { [void][System.Windows.Forms.MessageBox]::Show($form, 'ยังไม่พบ adb.exe กรุณาเลือกโฟลเดอร์ LDPlayer ก่อน', 'ค้นหา LINE OA') }; return }
    $names = Get-FindOaNames ([string]$cfg.FindOaNames)
    if (-not $names.Count) { if (-not $Auto) { [void][System.Windows.Forms.MessageBox]::Show($form, 'กรุณาใส่ชื่อ LINE OA ที่จะค้นหา', 'ค้นหา LINE OA') }; return }
    $targets = @($targets | Where-Object { $null -ne $_ } | ForEach-Object { [int]$_ } | Select-Object -Unique | Sort-Object)
    if (-not $targets.Count) { [void][System.Windows.Forms.MessageBox]::Show($form, 'กรุณาติ๊ก ✔ เครื่องที่ต้องการ', 'ค้นหา LINE OA'); return }
    $outDir = Join-Path $env:APPDATA 'LDAdbConnector\LineFindOa'
    [void][System.IO.Directory]::CreateDirectory($outDir)
    $exe = Join-Path $PSHOME 'powershell.exe'
    if (-not (Test-Path $exe)) { $exe = 'powershell.exe' }
    $b64 = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject @($names) -Compress)))
    $ldc = Join-Path ([string]$Sync.LdDir) 'ldconsole.exe'
    # a new report starts when nothing of the previous one is still running (automatic runs are saved one LD at a time, no pop-up)
    if ($Auto) { }
    elseif (-not $script:FindOaBatch) { $script:FindOaBatch = [ordered]@{ Time = (Get-Date); Names = @($names); Targets = @(); Results = @{} } }
    else { foreach ($nm in $names) { if ($script:FindOaBatch.Names -notcontains $nm) { $script:FindOaBatch.Names += $nm } } }
    if ($Auto -and $script:FindOaBatch) { }
    $started = 0
    foreach ($idx in $targets) {
        $skip = ''
        if (-not (Test-RowReady $idx)) { $skip = 'LD ยังไม่เปิด / ยังไม่เชื่อม ADB' }
        elseif (Test-RowBusy $idx) { $skip = 'เครื่องนี้มีงานอื่นทำอยู่' }
        $serial = if (-not $skip) { Get-LdSerial $idx } else { '' }
        if (-not $skip -and -not $serial) { $skip = 'ไม่พบ ADB Serial' }
        if ($Auto) {
            if ($skip) { continue }
        } else {
            if ($script:FindOaBatch.Targets -notcontains $idx) { $script:FindOaBatch.Targets += $idx }
            if ($skip) {
                Write-LineJobLog "LD #$idx | ข้ามการค้นหา OA: $skip"
                $script:FindOaBatch.Results[$idx] = @{ Error = "ข้าม: $skip"; Names = @($names); Items = @() }
                continue
            }
        }
        $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss_fff')
        $stdout = Join-Path $outDir "LD${idx}_${stamp}.json"
        $stderr = Join-Path $outDir "LD${idx}_${stamp}.err.txt"
        $progFile = Join-Path $outDir "LD${idx}_${stamp}.prog.txt"
        $argLine = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $scriptPath + '"'), '-Adb', ('"' + $adbPath + '"'),
            '-Serial', ('"' + $serial + '"'), '-LaunchLine', '-FindOaB64', $b64, '-LdConsole', ('"' + $ldc + '"'), '-LdIndex', "$idx", '-ProgressFile', ('"' + $progFile + '"')) -join ' '
        try {
            $p = Start-Process -FilePath $exe -ArgumentList $argLine -WorkingDirectory $PSScriptRoot -PassThru -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr
        } catch {
            Write-LineJobLog "LD #$idx | เริ่มค้นหา OA ไม่ได้: $($_.Exception.Message)"
            if (-not $Auto) { $script:FindOaBatch.Results[$idx] = @{ Error = 'เริ่มงานไม่ได้'; Names = @($names); Items = @() } }
            continue
        }
        [void]$script:InfoJobs.Add([pscustomobject]@{ Kind = 'findoa'; Auto = [bool]$Auto; Detail = "$(if ($Auto) { 'อัตโนมัติ · ' })ค้นหา $($names.Count) ชื่อ"; Prog = $progFile; Names = @($names); Index = $idx; Process = $p; Output = $stdout; ErrorFile = $stderr; Started = (Get-Date); Timeout = (90 + 30 * $names.Count) })
        Write-LineJobLog "LD #$idx | เริ่มค้นหา LINE OA$(if ($Auto) { ' (อัตโนมัติเมื่อเปิด LD)' }): หน้าแรก → กดช่องค้นหา → $($names -join ', ')"
        $script:LineMainStatus[$idx] = 'กำลังค้นหา LINE OA'
        $started++
    }
    if ($started) { $script:InfoJobTimer.Start() }
    try { Update-Status } catch {}
    if (-not $Auto) { Complete-FindOaBatch }
    return $started
}
function Get-FindOaWhy([string]$err) {
    if (-not $err) { return '' }
    if ($err -match 'Search box not found') { return 'ไม่เจอช่องค้นหาในหน้าแรก' }
    if ($err -match 'type|Thai') { return 'พิมพ์ชื่อไม่ได้' }
    return $err
}
function Write-FindOaResult([int]$idx, $res) {
    $fo = $res.findOa
    $items = @()
    foreach ($it in @($fo.items)) { if ($null -ne $it) { $items += $it } }
    if (-not $fo.home) { Write-LineJobLog "LD #$idx | ค้นหา OA: กลับหน้าแรกไม่สำเร็จ" }
    if ([int]$fo.uiFails -gt 0) { Write-LineJobLog "LD #$idx | ค้นหา OA: อ่านโครงสร้างหน้าจอไม่ได้ $([int]$fo.uiFails) ครั้ง (ใช้ภาพหน้าจอช่วยหาแทน)" }
    foreach ($op in @($fo.opens)) {
        if ($null -eq $op) { continue }
        if ([string]$op.tapped -eq 'oa') {
            Write-LineJobLog "LD #$idx | ค้นหา OA (วิธีสำรอง): $(@($op.path) -join ' > ') → $(if ($op.ok) { 'เปิดช่องค้นหาด้วยชื่อแล้ว' } else { 'ไปไม่ถึงช่องค้นหา' })$(if ($op.dump) { " | ไฟล์หน้าจอตอนติด: $($op.dump)" })$(if (-not $op.ok -and $op.homeDump) { " | ไฟล์หน้าจอเริ่มต้น: $($op.homeDump)" })"
            continue
        }
        $how = switch ([string]$op.tapped) { 'hint' { 'คำว่า ค้นหา' } 'bar' { 'แถบค้นหา' } 'hintbar' { 'ช่องที่มีคำว่า ค้นหา' } 'pixel' { "แถบสีเทาจากภาพหน้าจอ$(if ($op.bar) { " $($op.bar)" })" } default { 'ไม่พบช่องค้นหา' } }
        Write-LineJobLog "LD #$idx | ค้นหา OA$(if ([string]$op.tapped -eq 'pixel') { ' (วิธีสำรอง: ภาพหน้าจอ)' }): กดช่องค้นหาที่ ($($op.x), $($op.y)) [$how] → $(if ($op.ok) { 'เข้าหน้าค้นหาแล้ว' } else { 'ไม่เข้าหน้าค้นหา' })$(if ($op.homeDump) { " | ไฟล์หน้าจอหน้าแรก: $($op.homeDump)" })$(if ($op.dump) { " | ไฟล์หน้าจอหลังกด: $($op.dump)" })"
    }
    $okN = 0
    foreach ($it in $items) {
        $m = @($it.matches | Where-Object { $_ })
        if ($it.found) {
            $okN++
            $where = ($m | ForEach-Object { "'$($_.name)'$(if ($_.section) { " ($($_.section))" })" }) -join ', '
            Write-LineJobLog "LD #$idx | ค้นหา OA '$($it.name)': ✔ เจอ $where"
        } elseif (-not $it.typed) {
            Write-LineJobLog "LD #$idx | ค้นหา OA '$($it.name)': ค้นหาไม่ได้ ($(Get-FindOaWhy ([string]$it.error)))$(if ($it.dump) { " | ไฟล์หน้าจอ: $($it.dump)" })"
        } else {
            Write-LineJobLog "LD #$idx | ค้นหา OA '$($it.name)': ✖ ไม่เจอ$(if ($it.dump) { " | ไฟล์หน้าจอ: $($it.dump)" })"
        }
    }
    $nf = @($items | Where-Object { -not $_.found } | ForEach-Object { [string]$_.name })
    $script:LineMainStatus[$idx] = "ค้นหา OA: เจอ $okN/$($items.Count)" + $(if ($nf.Count) { " · ไม่เจอ: $($nf -join ', ')" } else { ' ✔' })
    if ($script:FindOaBatch -and $script:FindOaBatch.Targets -contains $idx) { $script:FindOaBatch.Results[$idx] = @{ Error = ''; Items = $items } }
    return , $items
}
function Get-FindOaRows([int]$idx, [string[]]$names, $items, [string]$err) {
    $rows = @()
    foreach ($nm in @($names)) {
        $it = @($items | Where-Object { [string]$_.name -eq $nm } | Select-Object -First 1)
        if ($err -or -not $it.Count) { $rows += [ordered]@{ ld = $idx; oa = $nm; state = 'error'; found = @(); note = $(if ($err) { $err } else { 'ไม่มีผลลัพธ์' }) }; continue }
        $i0 = $it[0]
        $st = if ($i0.found) { 'found' } elseif (-not $i0.typed) { 'error' } else { 'none' }
        $rows += [ordered]@{ ld = $idx; oa = $nm; state = $st; found = @(@($i0.matches | Where-Object { $_ }) | ForEach-Object { "$($_.name)$(if ($_.section) { " ($($_.section))" })" }); note = $(if ($st -eq 'error') { Get-FindOaWhy ([string]$i0.error) } else { '' }) }
    }
    return , $rows
}
function Save-FindOaHistory($rep) {
    try {
        $list = @()
        $j = Read-JsonSafe $script:FindOaLogPath
        if ($j) { $list = @($j) }
        $list += $rep
        # keep 90 days
        $cut = (Get-Date).AddDays(-90).ToString('yyyy-MM-dd')
        $list = @($list | Where-Object { $_ -and ([string]$_.time).Substring(0, [Math]::Min(10, ([string]$_.time).Length)) -ge $cut })
        if ($list.Count -gt 20000) { $list = @($list | Select-Object -Last 20000) }
        Write-SafeText $script:FindOaLogPath (ConvertTo-Json -InputObject @($list) -Depth 6)
    } catch {}
}
# ปิด LD หลังค้นหาอัตโนมัติเสร็จ (ldconsole quit)
function Close-LdAfterFind([int]$idx) {
    $lc = [string]$Sync.LdConsole
    if (-not $lc -or -not (Test-Path -LiteralPath $lc)) { Write-LineJobLog "LD #$idx | ปิด LD ไม่ได้: ไม่พบ ldconsole.exe"; return }
    # done by the background worker: it waits and checks the LD really closed (result shows in this log)
    $Sync.Commands.Enqueue([pscustomobject]@{ Type = 'QuitLd'; Idx = @($idx) })
    Write-LineJobLog "LD #$idx | ค้นหา OA เสร็จ → กำลังปิด LD..."
    $script:LineMainStatus[$idx] = "$($script:LineMainStatus[$idx]) · กำลังปิด LD"
}
# --- ค้นหาอัตโนมัติเมื่อเปิด LD ---
$script:AutoFindDone = @{}
function Get-AutoFindKey([int]$i) { return "$i@$(if ($script:ReadySince.ContainsKey($i)) { $script:ReadySince[$i].ToString('yyyyMMddHHmmss') })" }
function Set-FindOaAuto([bool]$on) {
    $cfg.FindOaAuto = $on; Save-Config
    if ($on) {
        # LDs that are already open now are not searched; only LDs opened from now on
        foreach ($k in @($script:ReadySince.Keys)) { $script:AutoFindDone[(Get-AutoFindKey ([int]$k))] = $true }
        Write-LineJobLog "เปิด 'ค้นหา LINE OA อัตโนมัติเมื่อเปิด LD' แล้ว: $((Get-FindOaNames ([string]$cfg.FindOaNames)) -join ', ')"
    } else { Write-LineJobLog "ปิด 'ค้นหา LINE OA อัตโนมัติเมื่อเปิด LD' แล้ว" }
    try { Update-FindAutoUi } catch {}
}
function Invoke-AutoFindOa {
    return   # ค้นหา OA อัตโนมัติ ถูกเอาออกแล้ว
    if (-not [bool]$cfg.FindOaAuto -or -not $Sync.PathOk) { return }
    if (-not @(Get-FindOaNames ([string]$cfg.FindOaNames)).Count) { return }
    $running = @($script:InfoJobs | Where-Object { $_.Kind -eq 'findoa' -and $_.PSObject.Properties['Auto'] -and $_.Auto }).Count
    foreach ($k in @($script:ReadySince.Keys | Sort-Object)) {
        if ($running -ge 3) { break }
        $i = [int]$k
        if (-not (Test-RowReady $i)) { continue }
        if (((Get-Date) - $script:ReadySince[$i]).TotalSeconds -lt 6) { continue }      # ADB just came up: a few seconds, then go (the script opens LINE itself)
        $key = Get-AutoFindKey $i
        if ($script:AutoFindDone.ContainsKey($key)) { continue }
        if (Test-RowBusy $i) { continue }
        $script:AutoFindDone[$key] = $true
        if ([int](Start-LineFindOa @($i) -Auto) -gt 0) { $running++ }
    }
}
function Complete-FindOaBatch {
    $b = $script:FindOaBatch
    if (-not $b) { return }
    if (@($script:InfoJobs | Where-Object { $_.Kind -eq 'findoa' -and -not ($_.PSObject.Properties['Auto'] -and $_.Auto) }).Count) { return }
    $script:FindOaBatch = $null
    foreach ($t in @($b.Targets)) { if (-not $b.Results.ContainsKey($t)) { $b.Results[$t] = @{ Error = 'หยุด / ไม่มีผลลัพธ์'; Items = @() } } }
    # flat rows: one per LD × searched name (only the names we asked for)
    $rows = @()
    foreach ($t in @($b.Targets | Sort-Object)) {
        $r = $b.Results[$t]
        foreach ($nm in @($b.Names)) {
            $it = @($r.Items | Where-Object { [string]$_.name -eq $nm } | Select-Object -First 1)
            if ($r.Error -or -not $it.Count) { $rows += [ordered]@{ ld = [int]$t; oa = $nm; state = 'error'; found = @(); note = $(if ($r.Error) { $r.Error } else { 'ไม่มีผลลัพธ์' }) }; continue }
            $i0 = $it[0]
            $st = if ($i0.found) { 'found' } elseif (-not $i0.typed) { 'error' } else { 'none' }
            $rows += [ordered]@{ ld = [int]$t; oa = $nm; state = $st; found = @(@($i0.matches | Where-Object { $_ }) | ForEach-Object { "$($_.name)$(if ($_.section) { " ($($_.section))" })" }); note = $(if ($st -eq 'error') { Get-FindOaWhy ([string]$i0.error) } else { '' }) }
        }
    }
    $rep = [ordered]@{ time = $b.Time.ToString('yyyy-MM-dd HH:mm'); names = @($b.Names); lds = @($b.Targets | Sort-Object); rows = $rows }
    $script:FindOaLast = $rep
    Save-FindOaHistory $rep
    foreach ($nm in @($b.Names)) {
        $f = @($rows | Where-Object { $_.oa -eq $nm -and $_.state -eq 'found' } | ForEach-Object { "#$($_.ld)" })
        $n = @($rows | Where-Object { $_.oa -eq $nm -and $_.state -eq 'none' } | ForEach-Object { "#$($_.ld)" })
        $e = @($rows | Where-Object { $_.oa -eq $nm -and $_.state -eq 'error' } | ForEach-Object { "#$($_.ld)" })
        Write-LineJobLog "รายงานค้นหา OA '$nm' | เจอ: $(if ($f.Count) { $f -join ', ' } else { '-' }) | ไม่เจอ: $(if ($n.Count) { $n -join ', ' } else { '-' })$(if ($e.Count) { " | ค้นหาไม่ได้: $($e -join ', ')" })"
    }
    try { [System.Media.SystemSounds]::Asterisk.Play() } catch {}
    Show-FindOaReport $rep
}
function Get-FindOaReportText($rep) {
    $lines = @("รายงานค้นหา LINE OA  ($($rep.time))", "เครื่องที่ค้นหา: $((@($rep.lds) | ForEach-Object { "#$_" }) -join ', ')", '')
    foreach ($nm in @($rep.names)) {
        $f = @($rep.rows | Where-Object { $_.oa -eq $nm -and $_.state -eq 'found' } | ForEach-Object { "#$($_.ld)" })
        $n = @($rep.rows | Where-Object { $_.oa -eq $nm -and $_.state -eq 'none' } | ForEach-Object { "#$($_.ld)" })
        $e = @($rep.rows | Where-Object { $_.oa -eq $nm -and $_.state -eq 'error' } | ForEach-Object { "#$($_.ld)" })
        $lines += "[$nm]"
        $lines += "  เจอ ($($f.Count)): $(if ($f.Count) { $f -join ', ' } else { '-' })"
        $lines += "  ไม่เจอ ($($n.Count)): $(if ($n.Count) { $n -join ', ' } else { '-' })"
        if ($e.Count) { $lines += "  ค้นหาไม่ได้ ($($e.Count)): $($e -join ', ')" }
    }
    return ($lines -join "`r`n")
}
function Show-FindOaReport($rep) {
    if (-not $rep) { [void][System.Windows.Forms.MessageBox]::Show($form, 'ยังไม่มีรายงานค้นหา OA (สั่งงาน "ค้นหา LINE OA" ก่อน)', 'รายงานค้นหา LINE OA'); return }
    try {
        $f = New-Object System.Windows.Forms.Form
        $f.Text = "รายงานค้นหา LINE OA  —  $($rep.time)"
        $f.StartPosition = 'CenterScreen'
        $f.Size = New-Object System.Drawing.Size(760, 560)
        $f.MinimumSize = New-Object System.Drawing.Size(560, 380)
        $f.BackColor = $uiBg; $f.ForeColor = $uiInk; $f.Font = $font; $f.ShowInTaskbar = $true; $f.MinimizeBox = $false
        try { Set-DarkTitle $f } catch {}
        $sumBox = New-Object System.Windows.Forms.TextBox
        $sumBox.Multiline = $true; $sumBox.ReadOnly = $true; $sumBox.BorderStyle = 'None'; $sumBox.ScrollBars = 'Vertical'
        $sumBox.BackColor = $uiSurface2; $sumBox.ForeColor = $uiInk; $sumBox.Font = $font; $sumBox.Dock = 'Top'
        $sumBox.Height = [Math]::Min(200, 46 + 62 * @($rep.names).Count)
        $sumBox.Text = Get-FindOaReportText $rep
        $g = New-Object System.Windows.Forms.DataGridView
        $g.Dock = 'Fill'; $g.ReadOnly = $true; $g.AllowUserToAddRows = $false; $g.AllowUserToDeleteRows = $false; $g.AllowUserToResizeRows = $false
        $g.RowHeadersVisible = $false; $g.SelectionMode = 'FullRowSelect'; $g.BorderStyle = 'None'
        $g.BackgroundColor = $uiBg; $g.GridColor = (New-Rgb 48 54 64); $g.EnableHeadersVisualStyles = $false
        $g.ColumnHeadersDefaultCellStyle.BackColor = $uiSurface2; $g.ColumnHeadersDefaultCellStyle.ForeColor = $uiMuted; $g.ColumnHeadersDefaultCellStyle.Font = $fontBold
        $g.DefaultCellStyle.BackColor = $uiBg; $g.DefaultCellStyle.ForeColor = $uiInk; $g.DefaultCellStyle.Font = $font
        $g.DefaultCellStyle.SelectionBackColor = (New-Rgb 40 70 110); $g.DefaultCellStyle.SelectionForeColor = $uiInk
        $g.RowTemplate.Height = 30
        foreach ($c in @(@('LD', '#', 60), @('Oa', 'ชื่อ OA ที่ค้นหา', 190), @('Res', 'ผล', 110), @('Found', 'ชื่อที่เจอ (หมวด)', 300))) {
            $ci = $g.Columns.Add($c[0], $c[1]); $g.Columns[$ci].Width = $c[2]; $g.Columns[$ci].SortMode = 'Automatic'
        }
        $g.Columns['Found'].AutoSizeMode = 'Fill'
        foreach ($r in @($rep.rows)) {
            $txt = switch ($r.state) { 'found' { '✔ เจอ' } 'none' { '✖ ไม่เจอ' } default { '! ค้นหาไม่ได้' } }
            $det = if ($r.state -eq 'found') { (@($r.found) -join ', ') } else { [string]$r.note }
            $ri = $g.Rows.Add(@("#$($r.ld)", [string]$r.oa, $txt, $det))
            $col = switch ($r.state) { 'found' { New-Rgb 86 211 130 } 'none' { New-Rgb 255 110 110 } default { New-Rgb 227 179 65 } }
            $g.Rows[$ri].Cells['Res'].Style.ForeColor = $col
            $g.Rows[$ri].Cells['Res'].Style.Font = $fontBold
        }
        $wrap = New-Object System.Windows.Forms.Panel
        $wrap.Dock = 'Fill'; $wrap.Padding = New-Object System.Windows.Forms.Padding(16, 12, 16, 6)
        $sp = New-Object System.Windows.Forms.Panel; $sp.Dock = 'Top'; $sp.Height = 10
        $wrap.Controls.Add($g); $wrap.Controls.Add($sp); $wrap.Controls.Add($sumBox)
        $bar = New-Object System.Windows.Forms.FlowLayoutPanel
        $bar.Dock = 'Bottom'; $bar.AutoSize = $true; $bar.FlowDirection = 'RightToLeft'; $bar.Padding = New-Object System.Windows.Forms.Padding(16, 6, 16, 14)
        $ok = New-Btn 'ตกลง' { $this.FindForm().Close() } 'primary'
        $cp = New-Btn 'คัดลอกรายงาน' $null 'ghost'
        $cp.Tag.Text = Get-FindOaReportText $rep
        $cp.Add_Click({ try { [System.Windows.Forms.Clipboard]::SetText([string]$this.Tag.Text); Write-LineJobLog 'คัดลอกรายงานค้นหา OA แล้ว' } catch {} })
        $tickF = New-Btn 'ติ๊กเครื่องที่ไม่เจอ' $null 'ghost'
        $tickF.Tag.Lds = @($rep.rows | Where-Object { $_.state -eq 'none' } | ForEach-Object { [int]$_.ld } | Select-Object -Unique)
        $tickF.Add_Click({ try { Set-CheckedOnly @($this.Tag.Lds) } catch {} })
        $hb = New-Btn 'ดูย้อนหลังรายวัน' { Show-FindOaHistory } 'ghost'
        $bar.Controls.AddRange(@($ok, $cp, $tickF, $hb))
        $f.Controls.Add($wrap); $f.Controls.Add($bar)
        $f.Add_FormClosed({ $this.Dispose() })
        try { Apply-Texts $f } catch {}
        if ($form.Visible) { $f.Show($form) } else { $f.Show() }
    } catch { Write-LineJobLog "เปิดรายงานค้นหา OA ไม่ได้: $($_.Exception.Message)" }
}
# --- บันทึกค้นหา LINE OA ย้อนหลัง (ดูรายวัน) ---
function Get-FindOaHistRows {
    $out = New-Object System.Collections.ArrayList
    foreach ($rep in @(Read-JsonSafe $script:FindOaLogPath)) {
        if (-not $rep) { continue }
        $t = [string]$rep.time
        $d = if ($t.Length -ge 10) { $t.Substring(0, 10) } else { $t }
        $hm = if ($t.Length -ge 16) { $t.Substring(11, 5) } else { '' }
        foreach ($r in @($rep.rows)) {
            if (-not $r) { continue }
            [void]$out.Add([pscustomobject]@{ Date = $d; Time = $hm; Ld = [int]$r.ld; Oa = [string]$r.oa; State = [string]$r.state; Found = (@($r.found) -join ', '); Note = [string]$r.note; Auto = [bool]$rep.auto })
        }
    }
    return , $out.ToArray()
}
function Get-FindOaDaySummary($rows) {
    $lines = @()
    foreach ($oa in @($rows | ForEach-Object { $_.Oa } | Select-Object -Unique)) {
        $rs = @($rows | Where-Object { $_.Oa -eq $oa })
        $f = @($rs | Where-Object { $_.State -eq 'found' } | ForEach-Object { $_.Ld } | Sort-Object -Unique)
        $n = @($rs | Where-Object { $_.State -eq 'none' -and $f -notcontains $_.Ld } | ForEach-Object { $_.Ld } | Sort-Object -Unique)
        $lines += "[$oa]  เจอ ($($f.Count)): $(if ($f.Count) { ($f | ForEach-Object { "#$_" }) -join ', ' } else { '-' })   |   ไม่เจอ ($($n.Count)): $(if ($n.Count) { ($n | ForEach-Object { "#$_" }) -join ', ' } else { '-' })"
    }
    return ($lines -join "`r`n")
}
function Show-FindOaHistory {
    $all = Get-FindOaHistRows
    if (-not $all.Count) { [void][System.Windows.Forms.MessageBox]::Show($form, 'ยังไม่มีบันทึกการค้นหา LINE OA', 'บันทึกค้นหา LINE OA ย้อนหลัง'); return }
    try {
        $f = New-Object System.Windows.Forms.Form
        $f.Text = 'บันทึกค้นหา LINE OA ย้อนหลัง (รายวัน)'
        $f.StartPosition = 'CenterScreen'
        $f.Size = New-Object System.Drawing.Size(980, 620)
        $f.MinimumSize = New-Object System.Drawing.Size(720, 420)
        $f.BackColor = $uiBg; $f.ForeColor = $uiInk; $f.Font = $font; $f.ShowInTaskbar = $true; $f.MinimizeBox = $false
        try { Set-DarkTitle $f } catch {}
        $st = @{ All = $all }
        # left: days
        $lb = New-Object System.Windows.Forms.ListBox
        $lb.Dock = 'Left'; $lb.Width = 210; $lb.BorderStyle = 'None'; $lb.IntegralHeight = $false
        $lb.BackColor = $uiSurface2; $lb.ForeColor = $uiInk; $lb.Font = $font; $lb.ItemHeight = 26
        $days = @($all | ForEach-Object { $_.Date } | Sort-Object -Unique -Descending)
        foreach ($d in $days) {
            $dr = @($all | Where-Object { $_.Date -eq $d })
            $nf = @($dr | Where-Object { $_.State -eq 'found' } | ForEach-Object { "$($_.Ld)|$($_.Oa)" } | Select-Object -Unique).Count
            $nl = @($dr | ForEach-Object { $_.Ld } | Select-Object -Unique).Count
            [void]$lb.Items.Add("$d   เจอ $nf · $nl เครื่อง")
        }
        # right
        $sum = New-Object System.Windows.Forms.TextBox
        $sum.Multiline = $true; $sum.ReadOnly = $true; $sum.BorderStyle = 'None'; $sum.ScrollBars = 'Vertical'
        $sum.BackColor = $uiSurface2; $sum.ForeColor = $uiInk; $sum.Font = $font; $sum.Dock = 'Top'; $sum.Height = 110
        $opt = New-Object System.Windows.Forms.FlowLayoutPanel
        $opt.Dock = 'Top'; $opt.AutoSize = $true; $opt.Padding = New-Object System.Windows.Forms.Padding(0, 8, 0, 6)
        $chkF = New-Object System.Windows.Forms.CheckBox
        $chkF.Text = 'แสดงเฉพาะที่เจอ'; $chkF.AutoSize = $true; $chkF.Checked = $true; $chkF.ForeColor = $uiInk
        $opt.Controls.Add($chkF)
        $g = New-Object System.Windows.Forms.DataGridView
        $g.Dock = 'Fill'; $g.ReadOnly = $true; $g.AllowUserToAddRows = $false; $g.AllowUserToDeleteRows = $false; $g.AllowUserToResizeRows = $false
        $g.RowHeadersVisible = $false; $g.SelectionMode = 'FullRowSelect'; $g.BorderStyle = 'None'
        $g.BackgroundColor = $uiBg; $g.GridColor = (New-Rgb 48 54 64); $g.EnableHeadersVisualStyles = $false
        $g.ColumnHeadersDefaultCellStyle.BackColor = $uiSurface2; $g.ColumnHeadersDefaultCellStyle.ForeColor = $uiMuted; $g.ColumnHeadersDefaultCellStyle.Font = $fontBold
        $g.DefaultCellStyle.BackColor = $uiBg; $g.DefaultCellStyle.ForeColor = $uiInk; $g.DefaultCellStyle.Font = $font
        $g.DefaultCellStyle.SelectionBackColor = (New-Rgb 40 70 110); $g.DefaultCellStyle.SelectionForeColor = $uiInk
        $g.RowTemplate.Height = 28
        foreach ($c in @(@('Time', 'เวลา', 64), @('LD', '#', 56), @('Oa', 'ชื่อ OA ที่ค้นหา', 170), @('Res', 'ผล', 100), @('Found', 'ชื่อที่เจอ / หมายเหตุ', 260), @('How', 'สั่งแบบ', 80))) {
            $ci = $g.Columns.Add($c[0], $c[1]); $g.Columns[$ci].Width = $c[2]; $g.Columns[$ci].SortMode = 'Automatic'
        }
        $g.Columns['Found'].AutoSizeMode = 'Fill'
        $right = New-Object System.Windows.Forms.Panel
        $right.Dock = 'Fill'; $right.Padding = New-Object System.Windows.Forms.Padding(14, 10, 14, 6)
        $right.Controls.Add($g); $right.Controls.Add($opt); $right.Controls.Add($sum)
        $st.Lb = $lb; $st.Sum = $sum; $st.Grid = $g; $st.Chk = $chkF; $st.Days = $days
        $fill = {
            param($st)
            $i = $st.Lb.SelectedIndex
            if ($i -lt 0) { return }
            $d = $st.Days[$i]
            $dr = @($st.All | Where-Object { $_.Date -eq $d })
            $st.Sum.Text = "วันที่ $d`r`n" + (Get-FindOaDaySummary $dr)
            $st.Grid.Rows.Clear()
            $show = if ($st.Chk.Checked) { @($dr | Where-Object { $_.State -eq 'found' }) } else { $dr }
            foreach ($r in @($show | Sort-Object Time, Ld -Descending)) {
                $txt = switch ($r.State) { 'found' { '✔ เจอ' } 'none' { '✖ ไม่เจอ' } default { '! ค้นหาไม่ได้' } }
                $det = if ($r.State -eq 'found') { $r.Found } else { $r.Note }
                $ri = $st.Grid.Rows.Add(@($r.Time, "#$($r.Ld)", $r.Oa, $txt, $det, $(if ($r.Auto) { 'อัตโนมัติ' } else { 'สั่งเอง' })))
                $col = switch ($r.State) { 'found' { New-Rgb 86 211 130 } 'none' { New-Rgb 255 110 110 } default { New-Rgb 227 179 65 } }
                $st.Grid.Rows[$ri].Cells['Res'].Style.ForeColor = $col
                $st.Grid.Rows[$ri].Cells['Res'].Style.Font = $fontBold
            }
        }
        $st.Fill = $fill
        $lb.Tag = $st; $chkF.Tag = $st
        $lb.Add_SelectedIndexChanged({ $s2 = $this.Tag; & $s2.Fill $s2 })
        $chkF.Add_CheckedChanged({ $s2 = $this.Tag; & $s2.Fill $s2 })
        $bar = New-Object System.Windows.Forms.FlowLayoutPanel
        $bar.Dock = 'Bottom'; $bar.AutoSize = $true; $bar.FlowDirection = 'RightToLeft'; $bar.Padding = New-Object System.Windows.Forms.Padding(14, 6, 14, 12)
        $ok = New-Btn 'ปิด' { $this.FindForm().Close() } 'primary'
        $cp = New-Btn 'คัดลอกวันนี้ที่เลือก' $null 'ghost'
        $cp.Tag.St = $st
        $cp.Add_Click({ try { [System.Windows.Forms.Clipboard]::SetText([string]$this.Tag.St.Sum.Text); Write-LineJobLog 'คัดลอกสรุปค้นหา OA ของวันที่เลือกแล้ว' } catch {} })
        $bar.Controls.AddRange(@($ok, $cp))
        $f.Controls.Add($right); $f.Controls.Add($lb); $f.Controls.Add($bar)
        $f.Add_FormClosed({ $this.Dispose() })
        try { Apply-Texts $f } catch {}
        if ($lb.Items.Count) { $lb.SelectedIndex = 0 }
        if ($form.Visible) { $f.Show($form) } else { $f.Show() }
    } catch { Write-LineJobLog "เปิดบันทึกย้อนหลังไม่ได้: $($_.Exception.Message)" }
}
function Set-CheckedOnly([int[]]$lds) {
    foreach ($r in $grid.Rows) {
        if ($null -eq $r.Tag) { continue }
        $on = $lds -contains [int]$r.Tag
        $r.Cells['Chk'].Value = $on
        $script:checked[[int]$r.Tag] = $on
    }
    try { Save-Checked } catch {}
    $grid.Invalidate()
    Write-LineJobLog "ติ๊กเครื่องที่ไม่เจอ OA: $((@($lds) | ForEach-Object { "#$_" }) -join ', ')"
}
# เชิญเข้ากลุ่ม: หน้าแรก -> มีกลุ่ม? เข้ากลุ่ม -> เชิญ (ไม่มีกลุ่ม -> สร้างกลุ่ม) -> ติ๊กวงกลมต่ออัตโนมัติ
function Start-LineGroupInvite([int[]]$targets, [string]$action = 'auto') {
    $scriptPath = Join-Path $PSScriptRoot 'Adb-LineAddFriend.ps1'
    if (-not (Test-Path -LiteralPath $scriptPath)) { [void][System.Windows.Forms.MessageBox]::Show($form, "ไม่พบ $scriptPath", 'เชิญเข้ากลุ่ม'); return }
    $adbPath = [string]$Sync.Adb
    if (-not $adbPath -or -not (Test-Path -LiteralPath $adbPath)) { [void][System.Windows.Forms.MessageBox]::Show($form, 'ยังไม่พบ adb.exe กรุณาเลือกโฟลเดอร์ LDPlayer ก่อน', 'เชิญเข้ากลุ่ม'); return }
    $targets = @($targets | Where-Object { $null -ne $_ } | ForEach-Object { [int]$_ } | Select-Object -Unique)
    if (-not $targets.Count) { [void][System.Windows.Forms.MessageBox]::Show($form, 'กรุณาติ๊ก ✔ เครื่องที่ต้องการ หรือคลิกขวาที่แถวเครื่อง', 'เชิญเข้ากลุ่ม'); return }
    $outDir = Join-Path $env:APPDATA 'LDAdbConnector\LineGroup'
    [void][System.IO.Directory]::CreateDirectory($outDir)
    $exe = Join-Path $PSHOME 'powershell.exe'
    if (-not (Test-Path $exe)) { $exe = 'powershell.exe' }
    $started = 0
    foreach ($idx in $targets) {
        if (-not (Test-RowReady $idx)) { Write-LineJobLog "LD #$idx | ข้าม: LD ยังไม่เปิด / ยังไม่เชื่อม ADB"; continue }
        if (Test-RowBusy $idx) { Write-LineJobLog "LD #$idx | ข้ามการเชิญเข้ากลุ่ม: เครื่องนี้มีงานอื่นทำอยู่"; continue }
        $serial = Get-LdSerial $idx
        if (-not $serial) { Write-LineJobLog "LD #$idx | เชิญเข้ากลุ่มไม่ได้: ไม่พบ ADB Serial"; continue }
        $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss_fff')
        $stdout = Join-Path $outDir "LD${idx}_${stamp}.json"
        $stderr = Join-Path $outDir "LD${idx}_${stamp}.err.txt"
        $argLine = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $scriptPath + '"'), '-Adb', ('"' + $adbPath + '"'),
            '-Serial', ('"' + $serial + '"'), '-LaunchLine', '-GroupOnly', '-GroupAction', $action, '-MaxMembers', "$([int]$cfg.MaxGroupMembers)") -join ' '
        [void]$script:TickedNames.Remove($idx)
        $progFile = Join-Path $outDir "LD${idx}_${stamp}.prog.txt"
        $argLine += (Get-PreTickArg) + " -LdIndex $idx -ProgressFile `"$progFile`""
        try {
            $p = Start-Process -FilePath $exe -ArgumentList $argLine -WorkingDirectory $PSScriptRoot -PassThru -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr
        } catch { Write-LineJobLog "LD #$idx | เริ่มเชิญเข้ากลุ่มไม่ได้: $($_.Exception.Message)"; continue }
        $det = if ($action -eq 'create') { 'สร้างกลุ่ม → ค้นหาชื่อ → ติ๊ก' } else { "หากลุ่ม ≤ $([int]$cfg.MaxGroupMembers) คน → เชิญ" }
        [void]$script:InfoJobs.Add([pscustomobject]@{ Kind = 'group'; Detail = $det; Prog = $progFile; Index = $idx; Process = $p; Output = $stdout; ErrorFile = $stderr; Started = (Get-Date); Timeout = 180 + 40 * [Math]::Max(0, @(([string]$cfg.PreTickNames) -split '[,\r\n]+' | Where-Object { $_.Trim() }).Count) })
        Add-Stat $idx 'invite'
        if ($action -eq 'create') { Write-LineJobLog "LD #$idx | เริ่มสร้างกลุ่มอย่างเดียว: กลุ่ม → สร้างกลุ่ม → ค้นหาด้วยชื่อแล้วติ๊ก → X → ติ๊กวงกลมตามที่ตั้ง" }
        else { Write-LineJobLog "LD #$idx | เริ่มเชิญเข้ากลุ่ม: หน้าแรก → กลุ่ม → หากลุ่มที่ไม่เกิน $([int]$cfg.MaxGroupMembers) คน → แชท → ≡ → เชิญ (ไม่มีกลุ่มที่เข้าเงื่อนไขจะสร้างกลุ่ม)" }
        $started++
    }
    if ($started) { $script:InfoJobTimer.Start() }
    try { Update-Status } catch {}
}
function Start-LineSelect([int[]]$targets, [switch]$FromLine) {
    $scriptPath = Join-Path $PSScriptRoot 'Adb-LineSelect.ps1'
    if (-not (Test-Path -LiteralPath $scriptPath)) {
        [void][System.Windows.Forms.MessageBox]::Show($form, "ไม่พบ $scriptPath", 'ติ๊กเลือกเพื่อน')
        return
    }
    $adbPath = [string]$Sync.Adb
    if (-not $adbPath -or -not (Test-Path -LiteralPath $adbPath)) {
        [void][System.Windows.Forms.MessageBox]::Show($form, 'ยังไม่พบ adb.exe กรุณาเลือกโฟลเดอร์ LDPlayer ก่อน', 'ติ๊กเลือกเพื่อน')
        return
    }
    $targets = @($targets | Where-Object { $null -ne $_ } | ForEach-Object { [int]$_ } | Select-Object -Unique)
    if (-not $targets.Count) {
        [void][System.Windows.Forms.MessageBox]::Show($form, 'กรุณาติ๊ก ✔ เครื่องที่ต้องการ หรือคลิกขวาที่แถวเครื่อง', 'ติ๊กเลือกเพื่อน')
        return
    }
    $n = [int]$numSel.Value
    $allMode = [bool]$cfg.SelectAll
    $outDir = Join-Path $env:APPDATA 'LDAdbConnector\LineSelect'
    [void][System.IO.Directory]::CreateDirectory($outDir)
    $exe = Join-Path $PSHOME 'powershell.exe'
    if (-not (Test-Path $exe)) { $exe = 'powershell.exe' }
    $started = 0
    foreach ($idx in $targets) {
        if (-not (Test-RowReady $idx)) { Write-LineJobLog "LD #$idx | ข้าม: LD ยังไม่เปิด / ยังไม่เชื่อม ADB"; continue }
        if (@($script:LineJobs) | Where-Object { $_.Index -eq $idx }) { Write-LineJobLog "LD #$idx | ข้ามการติ๊กเพื่อน: กำลังรัน LINE Script อยู่"; continue }
        if (@($script:InfoJobs) | Where-Object { $_.Index -eq $idx }) { Write-LineJobLog "LD #$idx | ข้าม: มีงานอื่นทำอยู่ในเครื่องนี้"; continue }
        if (@($script:LineStartQueue.ToArray()) -contains $idx) { Write-LineJobLog "LD #$idx | ข้าม: อยู่ในคิว LINE Script"; continue }
        $serial = Get-LdSerial $idx
        if (-not $serial) { Write-LineJobLog "LD #$idx | ติ๊กเพื่อนไม่ได้: ไม่พบ ADB Serial"; continue }
        $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss_fff')
        $stdout = Join-Path $outDir "LD${idx}_${stamp}.json"
        $stderr = Join-Path $outDir "LD${idx}_${stamp}.err.txt"
        $argLine = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $scriptPath + '"'), '-Adb', ('"' + $adbPath + '"'),
            '-Serial', ('"' + $serial + '"'), '-Count', "$n", '-OutDir', ('"' + $outDir + '"')) -join ' '
        if ($allMode) { $argLine += ' -All' }
        $exN = @(([string]$cfg.ExcludeNames) -split '[,\r\n]+' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
        if ($exN.Count) { $argLine += " -ExcludeB64 $([Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject @($exN) -Compress))))" }
        try {
            $p = Start-Process -FilePath $exe -ArgumentList $argLine -WorkingDirectory $PSScriptRoot -PassThru -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr
        } catch {
            Write-LineJobLog "LD #$idx | เริ่มติ๊กเพื่อนไม่ได้: $($_.Exception.Message)"
            continue
        }
        Add-Stat $idx 'select'
        [void]$script:InfoJobs.Add([pscustomobject]@{ Kind = 'select'; Origin = $(if ($FromLine) { 'line' } else { '' }); Detail = $(if ($allMode) { 'ทั้งหมดจนถึงล่างสุด' } else { "เป้าหมาย $n คน" }); Index = $idx; Process = $p; Output = $stdout; ErrorFile = $stderr; Started = (Get-Date); Timeout = $(if ($allMode) { 1800 } else { 300 }) })
        if ($allMode) { Write-LineJobLog "LD #$idx | เริ่มติ๊กวงกลมทั้งหมดจนถึงล่างสุด (ข้ามคนที่เป็นสีเขียวแล้ว แล้วย้อนตรวจซ้ำอีกรอบ)" }
        else { Write-LineJobLog "LD #$idx | เริ่มติ๊กเลือกเพื่อน $n คน (ข้ามคนที่เป็นสีเขียวแล้ว)" }
        $started++
    }
    if ($started) { $script:InfoJobTimer.Start() }
    try { Update-Status } catch {}
}
$script:InfoJobTimer.Add_Tick({
    $chainSel = @()
    foreach ($job in @($script:InfoJobs.ToArray())) {
        $idx = [int]$job.Index
        $limit = if ($job.PSObject.Properties['Timeout']) { [int]$job.Timeout } else { 120 }
        $timedOut = ((Get-Date) - $job.Started).TotalSeconds -gt $limit
        if (-not $job.Process.HasExited -and -not $timedOut) {
            if ($job.PSObject.Properties['Prog']) { $pt = Get-ProgText ([string]$job.Prog); if ($pt) { $job.Detail = $pt } }
            continue
        }
        if (-not $job.Process.HasExited) { Stop-LineJobTree $job.Process }
        $res = $null; $jobFail = $false
        try {
            if ($timedOut) { throw "หมดเวลา (เกิน $limit วินาที)" }
            $raw = Read-SharedText ([string]$job.Output)
            $line = Get-LastJsonLine $raw
            if (-not $line) { throw 'สคริปต์ไม่ส่งผลลัพธ์กลับมา' }
            $res = $line | ConvertFrom-Json -ErrorAction Stop
            if ($job.PSObject.Properties['Kind'] -and $job.Kind -eq 'check') {
                $nOk = 0; $nNf = 0
                foreach ($rd in @($res.rounds)) {
                    if ($null -eq $rd) { continue }
                    if ($rd.name) { $nOk++; Write-LineJobLog "LD #$idx | ID '$($rd.text)' → ชื่อจริง: $($rd.name)" }
                    elseif ($rd.status -eq 'notfound') { $nNf++; Write-LineJobLog "LD #$idx | ID '$($rd.text)' → ไม่พบบัญชี" }
                    else { Write-LineJobLog "LD #$idx | ID '$($rd.text)' → อ่านชื่อไม่ได้ ($($rd.error))" }
                }
                [void](Update-IdNamesFromRounds $res.rounds)
                $script:LineMainStatus[$idx] = "ดึงชื่อจริงของ ID: ได้ $nOk$(if ($nNf) { " · ไม่พบ $nNf" })"
                throw '__done__'
            }
            if ($job.PSObject.Properties['Kind'] -and $job.Kind -eq 'findoa') {
                if (-not $res.findOa) { throw $(if ($res.error) { [string]$res.error } else { 'ไม่มีผลค้นหา' }) }
                $its = Write-FindOaResult $idx $res
                if ($job.Auto) {
                    $rws = Get-FindOaRows $idx @($job.Names) $its ''
                    Save-FindOaHistory ([ordered]@{ time = (Get-Date).ToString('yyyy-MM-dd HH:mm'); auto = $true; names = @($job.Names); lds = @($idx); rows = $rws })
                    $fn = @($rws | Where-Object { $_.state -eq 'found' } | ForEach-Object { $_.oa })
                    Write-LineJobLog "LD #$idx | ค้นหา OA อัตโนมัติเสร็จ: $(if ($fn.Count) { "เจอ $($fn -join ', ')" } else { 'ไม่เจอ OA ที่ตั้งไว้' }) (ดูย้อนหลังได้)"
                    # close the LD only when every name was really searched (a problem leaves it open for checking)
                    $okAll = -not @($rws | Where-Object { $_.state -eq 'error' }).Count
                    if ([bool]$cfg.FindOaAutoClose) {
                        if ($okAll) { Close-LdAfterFind $idx } else { Write-LineJobLog "LD #$idx | ไม่ปิด LD: ค้นหาบางชื่อไม่ได้ (เปิดค้างไว้ให้ตรวจ)" }
                    }
                }
                throw '__done__'
            }
            if ($job.PSObject.Properties['Kind'] -and $job.Kind -eq 'byname') {
                Write-ByNameResult $idx $res
                throw '__done__'
            }
            if ($job.PSObject.Properties['Kind'] -and $job.Kind -eq 'group') {
                if (Write-GroupStepLog $idx $res.createGroup) {
                    $chainSel += $idx
                    Set-TickedNames $idx $res.createGroup
                    $script:LineMainStatus[$idx] = $(if ($res.createGroup.mode -eq 'invite') { 'เปิดหน้าเชิญเข้ากลุ่มแล้ว → ติ๊กวงกลมต่อ' } else { 'สร้างกลุ่มแล้ว → ติ๊กวงกลมต่อ' })
                } else {
                    Set-TickedNames $idx $res.createGroup
                    $script:LineMainStatus[$idx] = 'เชิญเข้ากลุ่มไม่สำเร็จ (ดูบันทึก)'
                }
                throw '__done__'
            }
            if ($job.PSObject.Properties['Kind'] -and $job.Kind -eq 'select') {
                if (@($res.excluded).Count) { Write-LineJobLog "LD #$idx | ไม่ติ๊กตามรายชื่อที่ตั้งไว้ $(@($res.excluded).Count) คน: $(@($res.excluded) -join ', ')" }
                if ([int]$res.noName -gt 0 -and ([string]$cfg.ExcludeNames).Trim()) { Write-LineJobLog "LD #$idx | หมายเหตุ: บางวงอ่านชื่อไม่ได้ จึงเช็ครายชื่อห้ามติ๊กไม่ได้ (ติ๊กไปตามปกติ)" }
                $cnt = if ($null -ne $res.before -and $null -ne $res.after) { " | ตัวเลขหัวจอ: เลือก $($res.before) -> $($res.after)" } else { '' }
                $sel = if ($null -ne $res.selected) { [int]$res.selected } else { 0 }
                $req = if ($null -ne $res.requested) { [int]$res.requested } else { 0 }
                $extra = " | กดซ้ำ $([int]$res.retried) | ใช้เวลา $($res.seconds) วิ"
                if ($res.all) {
                    if ($res.ok) {
                        Write-LineJobLog "LD #$idx | ✔ ติ๊กครบทั้งรายการถึงล่างสุด: เขียวหมดแล้ว | ติ๊กเพิ่ม $sel คน, เขียวอยู่แล้ว $($res.skippedGreen) คน, รอบตรวจซ้ำแก้เพิ่ม $([int]$res.fixedInCheck)$cnt$extra"
                        $script:LineMainStatus[$idx] = "ติ๊กครบทั้งรายการ ✔ (+$sel คน, $($res.seconds) วิ)"
                    } else {
                        Write-LineJobLog "LD #$idx | ✖ ติ๊กทั้งรายการไม่ครบ: ติ๊กได้ $sel คน, ยังขาว $([int]$res.whiteLeft) แถว | $($res.error)$cnt$extra"
                        $script:LineMainStatus[$idx] = "ติ๊กทั้งรายการไม่ครบ (ยังขาว $([int]$res.whiteLeft))"
                    }
                    throw '__done__'
                }
                if ($res.ok) {
                    Write-LineJobLog "LD #$idx | ✔ ติ๊กเลือกเพื่อนครบ $sel/$req คน (ตรวจแล้วเป็นสีเขียวทุกวง, ข้ามที่เลือกไว้แล้ว $($res.skippedGreen))$cnt$extra"
                    $script:LineMainStatus[$idx] = "ติ๊กเพื่อนครบ $sel/$req คน ✔ ($($res.seconds) วิ)"
                } else {
                    Write-LineJobLog "LD #$idx | ✖ ติ๊กเลือกเพื่อนไม่ครบ: ได้ $sel/$req คน | $($res.error)$cnt$extra"
                    $script:LineMainStatus[$idx] = "ติ๊กเพื่อนไม่ครบ $sel/$req คน"
                }
                throw '__done__'
            }
            $hasAny = ($null -ne $res.friends) -or ($null -ne $res.groups) -or [bool]$res.name
            if (-not $hasAny) {
                $why = if ($res.error) { [string]$res.error } else { 'อ่านข้อมูลไม่ได้' }
                if ($res.dump) { $why += " | ไฟล์หน้าจอ: $($res.dump)" }
                throw $why
            }
            Set-LineInfoRow $idx ([string]$res.name) $res.friends $res.groups
            $fTxt = if ($null -ne $res.friends) { [string]$res.friends } else { '-' }
            $gTxt = if ($null -ne $res.groups) { [string]$res.groups } else { '-' }
            $nTxt = if ($res.name) { [string]$res.name } else { '-' }
            Write-LineJobLog "LD #$idx | ดึงข้อมูล LINE สำเร็จ | ชื่อ: $nTxt | เพื่อน: $fTxt | กลุ่ม: $gTxt"
            $script:LineMainStatus[$idx] = "ดึงข้อมูล LINE สำเร็จ · เพื่อน $fTxt · กลุ่ม $gTxt"
            if (($null -eq $res.friends -or $null -eq $res.groups -or -not $res.name) -and $res.dump) {
                Write-LineJobLog "LD #$idx | อ่านได้ไม่ครบ ตรวจไฟล์หน้าจอ: $($res.dump)"
            }
        } catch {
            if ($_.Exception.Message -ne '__done__') {
            $jobFail = $true
            $err = ''
            try { $err = (Read-SharedText ([string]$job.ErrorFile)).Trim() } catch {}
            if ($err.Length -gt 300) { $err = $err.Substring(0, 300) }
            $what = if ($job.PSObject.Properties['Kind'] -and $job.Kind -eq 'select') { 'ติ๊กเลือกเพื่อน' } elseif ($job.PSObject.Properties['Kind'] -and $job.Kind -in 'group', 'byname') { 'เชิญเข้ากลุ่ม' } elseif ($job.PSObject.Properties['Kind'] -and $job.Kind -eq 'check') { 'ตรวจ ID' } elseif ($job.PSObject.Properties['Kind'] -and $job.Kind -eq 'findoa') { 'ค้นหา OA' } else { 'ดึงข้อมูล LINE' }
            if ($job.Kind -eq 'findoa' -and $job.Auto) { Save-FindOaHistory ([ordered]@{ time = (Get-Date).ToString('yyyy-MM-dd HH:mm'); auto = $true; names = @($job.Names); lds = @($idx); rows = (Get-FindOaRows $idx @($job.Names) @() "ไม่สำเร็จ: $($_.Exception.Message)") }) }
            elseif ($job.Kind -eq 'findoa' -and $script:FindOaBatch) { $script:FindOaBatch.Results[$idx] = @{ Error = "ไม่สำเร็จ: $($_.Exception.Message)"; Items = @() } }
            Write-LineJobLog "LD #$idx | $what ไม่สำเร็จ: $($_.Exception.Message) $err"
            $script:LineMainStatus[$idx] = "$what ไม่สำเร็จ (ดูบันทึก)"
            }
        }
        # count "เพิ่มเพื่อน" once per job: invite/create that continues into ticking is counted when the ticking ends
        try {
            $isLineChain = ($job.PSObject.Properties['Origin'] -and [string]$job.Origin -eq 'line')
            $isAuto = ($job.PSObject.Properties['Auto'] -and [bool]$job.Auto)
            if ($job.Kind -in 'select', 'group', 'findoa' -and -not $isLineChain -and -not $isAuto) {
                if ($jobFail -or $null -eq $res) { Add-Count 'add' $false }
                elseif ($job.Kind -eq 'group') { if ($chainSel -notcontains $idx) { Add-Count 'add' $false } }
                else { Add-Count 'add' ([bool]$res.ok) }
            }
        } catch {}
        [void]$script:InfoJobs.Remove($job)
        if ($job.Kind -ne 'info') { $script:NeedInfo[$idx] = Get-Date }
        try { $job.Process.Dispose() } catch {}
    }
    if ($script:InfoJobs.Count -eq 0) { $script:InfoJobTimer.Stop() }
    try { Complete-FindOaBatch } catch {}
    foreach ($ci in $chainSel) {
        try { Start-LineSelect @([int]$ci) } catch { Write-LineJobLog "LD #$ci | เริ่มติ๊กวงกลมต่อไม่ได้: $($_.Exception.Message)" }
    }
    try { Update-Status } catch {}
})

$ctx = New-Object System.Windows.Forms.ContextMenuStrip
$ctx.Font = $font
$ctxStart = $ctx.Items.Add('เริ่ม LINE Script', $null, { Start-LineScript @(Get-Targets) })
$ctxInfo = $ctx.Items.Add('ดึงข้อมูล LINE (ชื่อ / เพื่อน / กลุ่ม)', $null, { Start-LineInfoFetch @(Get-Targets) })
$ctxSelect = $ctx.Items.Add('ติ๊กวงกลมเลือกเพื่อน', $null, { Start-LineSelect @(Get-Targets) })
$ctxInvite = $ctx.Items.Add('เชิญเข้ากลุ่ม (หากลุ่ม → เชิญ → ติ๊กวงกลม)', $null, { Start-LineGroupInvite @(Get-Targets) })
$ctxFindRep = $ctx.Items.Add('บันทึกค้นหา LINE OA ย้อนหลัง (รายวัน)', $null, { Show-FindOaHistory })
[void]$ctx.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
$ctxStop = $ctx.Items.Add('หยุดงาน', $null, { Stop-LineScripts @(Get-Targets) })
$ctxStopAll = $ctx.Items.Add('หยุดงานทั้งหมด', $null, { Stop-AllLineScripts })
[void]$ctx.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
$ctxAll = $ctx.Items.Add('☑  เลือกทั้งหมด', $null, { Set-AllChecked $true })
$ctxNone = $ctx.Items.Add('☐  ไม่เลือก', $null, { Set-AllChecked $false })
$ctx.Add_Opening({
    param($sender, $e)
    if ($grid.Rows.Count -eq 0) { $e.Cancel = $true; return }
    $tg = @(Get-Targets)
    $who = if ($tg.Count -gt 1) { "$($tg.Count) เครื่องที่ติ๊ก" } elseif ($tg.Count -eq 1) { "LD #$($tg[0])" } else { 'ยังไม่ได้เลือกเครื่อง' }
    $free = @($tg | Where-Object { -not (Test-RowBusy ([int]$_)) })
    $busy = @($tg | Where-Object { Test-RowBusy ([int]$_) })
    $suffix = if ($tg.Count -and $busy.Count) { " ($($free.Count)/$($tg.Count) ว่าง)" } else { " ($who)" }
    $ctxStart.Enabled = ($free.Count -gt 0)
    $ctxStart.Text = "▶  เริ่ม LINE Script$suffix"
    $ctxInfo.Enabled = ($free.Count -gt 0); $ctxInfo.Visible = $false
    $ctxInfo.Text = "ดึงข้อมูล LINE (ชื่อ / เพื่อน / กลุ่ม)$suffix"
    $ctxSelect.Enabled = ($free.Count -gt 0)
    $ctxInvite.Enabled = ($free.Count -gt 0)
    $ctxInvite.Text = "เชิญเข้ากลุ่ม → ติ๊กวงกลม$suffix"
    $ctxSelect.Text = $(if ($cfg.SelectAll) { "ติ๊กวงกลมทั้งหมดถึงล่างสุด$suffix" } else { "ติ๊กวงกลมเลือกเพื่อน $([int]$numSel.Value) คน$suffix" })
    $ctxStop.Enabled = ($busy.Count -gt 0)
    $ctxStop.Text = if ($busy.Count) { "■  หยุดงาน ($($busy.Count) เครื่องที่กำลังทำงาน)" } else { '■  หยุดงาน (เครื่องที่เลือกไม่ได้ทำงานอยู่)' }
    $allCount = $script:LineJobs.Count + $script:InfoJobs.Count + $script:LineStartQueue.Count
    $ctxStopAll.Enabled = ($allCount -gt 0)
    $ctxStopAll.Text = "■  หยุดงานทั้งหมด ($allCount งาน)"
})
$grid.ContextMenuStrip = $ctx
$ctx.Add_Opened({ try { Apply-MenuTexts $ctx.Items } catch {} })
Set-DarkMenu $ctx
$ctxStart.Font = $fontBold
$ctxStop.ForeColor = New-Rgb 255 123 114
$ctxStopAll.ForeColor = New-Rgb 255 123 114
$ctxInfo.ForeColor = $uiAccentText
$ctxInfo.Visible = $false; $ctxFindRep.Visible = $false   # ดึงข้อมูล LINE / ค้นหา OA ถูกเอาออกแล้ว
$ctxSelect.ForeColor = $uiAccentText
$ctxInvite.ForeColor = New-Rgb 188 140 255
$ctxInvite.Padding = New-Object System.Windows.Forms.Padding(6, 6, 6, 6)
$ctxSelect.Padding = New-Object System.Windows.Forms.Padding(6, 6, 6, 6)
$ctxInfo.Padding = New-Object System.Windows.Forms.Padding(6, 6, 6, 6)
$ctxStart.ForeColor = New-Rgb 86 211 130
foreach ($it in @($ctxStart, $ctxAll, $ctxNone)) { $it.Padding = New-Object System.Windows.Forms.Padding(6, 6, 6, 6) }
foreach ($it in @($ctxStop, $ctxStopAll)) { $it.Padding = New-Object System.Windows.Forms.Padding(6, 6, 6, 6) }
$ctxStart.Padding = New-Object System.Windows.Forms.Padding(6, 6, 6, 6)

# --- Content card: nav tabs + pages ---
$contentCard = New-Card 2
$contentCard.Padding = New-Object System.Windows.Forms.Padding(10, 8, 10, 8)
$contentCard.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 2)
[void]$contentCard.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$contentCard.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100)))

$navBar = New-Table @('Auto', 'Fill', 'Auto')
$navBar.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 6)
$navFlow = New-Flow
$navFlow.Anchor = 'Left'
$script:navBtns = [ordered]@{}
$script:pages = @{}
foreach ($nv in @(@('list', 'รายการเครื่อง'), @('config', 'ชุด ID'), @('settings', 'ตั้งค่า'), @('log', 'บันทึก'))) {
    $key = $nv[0]
    $nb = New-Btn $nv[1] $null 'tab'
    $nb.Name = "nav_$key"
    $nb.Margin = New-Object System.Windows.Forms.Padding(0, 0, 6, 0)
    $nb.Add_Click({ Show-Page ($this.Name.Substring(4)) })
    $script:navBtns[$key] = $nb
    $navFlow.Controls.Add($nb)
}
$listActions = New-Flow
$listActions.Anchor = 'Right'
$listBar = New-Object System.Windows.Forms.FlowLayoutPanel
$listBar.Dock = 'Top'
$listBar.AutoSize = $true
$listBar.AutoSizeMode = 'GrowAndShrink'
$listBar.WrapContents = $true
$listBar.Margin = New-Object System.Windows.Forms.Padding(0)
$listBar.Padding = New-Object System.Windows.Forms.Padding(0, 0, 0, 4)
function New-Sep {
    $sp = New-Object System.Windows.Forms.Panel
    $sp.Width = 1; $sp.Height = 22; $sp.BackColor = $uiBorder
    $sp.Margin = New-Object System.Windows.Forms.Padding(4, 6, 4, 0)
    return $sp
}
# group = controls that always stay together on one line
function New-Group([object[]]$items) {
    $gp = New-Flow
    $gp.Margin = New-Object System.Windows.Forms.Padding(0, 0, 14, 6)
    $first = $true
    foreach ($it in $items) {
        if ($it -is [System.Windows.Forms.Button] -and -not $first) { $it.Margin = New-Object System.Windows.Forms.Padding(6, 0, 0, 0) }
        elseif ($it -is [System.Windows.Forms.Button]) { $it.Margin = New-Object System.Windows.Forms.Padding(0) }
        [void]$gp.Controls.Add($it)
        $first = $false
    }
    return $gp
}
# segmented control: [☑ เลือกทั้งหมด | ☐ ไม่เลือก]
$script:BtnKinds['seg'] = @{ Bg = $uiSurface2; Hover = (New-Rgb 44 52 64); Press = (New-Rgb 52 61 75); Fg = $uiInk; Border = $null }
$segSel = New-Flow
$segSel.BackColor = $uiSurface2
$segSel.Padding = New-Object System.Windows.Forms.Padding(3)
$segSel.Margin = New-Object System.Windows.Forms.Padding(0)
Set-DoubleBuffered $segSel
$segSel.Add_Paint({
    param($s, $e)
    $g = $e.Graphics
    $g.Clear($s.Parent.BackColor)
    $g.SmoothingMode = 'AntiAlias'
    Fill-Round $g $uiSurface2 0.5 0.5 ($s.Width - 1.5) ($s.Height - 1.5) 9 $uiBorder
})
$btnAll = New-Btn '☑  เลือกทั้งหมด' { Set-AllChecked $true } 'seg'
$btnNone = New-Btn '☐  ไม่เลือก' { Set-AllChecked $false } 'seg'
foreach ($sb in @($btnAll, $btnNone)) {
    $sb.MinimumSize = New-Object System.Drawing.Size(0, 28)
    $sb.Padding = New-Object System.Windows.Forms.Padding(10, 0, 10, 0)
    $sb.Margin = New-Object System.Windows.Forms.Padding(0)
}
$segDiv = New-Object System.Windows.Forms.Panel
$segDiv.Width = 1; $segDiv.Height = 18; $segDiv.BackColor = $uiBorder
$segDiv.Margin = New-Object System.Windows.Forms.Padding(2, 5, 2, 0)
$segSel.Controls.AddRange(@($btnAll, $segDiv, $btnNone))
# counter pill
$lblChecked = New-Object System.Windows.Forms.Label
$lblChecked.Text = 'ติ๊กแล้ว 0/0'
$lblChecked.AutoSize = $true
$lblChecked.Font = $fontBold
$lblChecked.ForeColor = $uiAccentText
$lblChecked.Padding = New-Object System.Windows.Forms.Padding(12, 8, 12, 8)
$lblChecked.Margin = New-Object System.Windows.Forms.Padding(8, 0, 0, 0)
Set-DoubleBuffered $lblChecked
$lblChecked.Add_Paint({
    param($s, $e)
    $g = $e.Graphics
    $g.Clear($s.Parent.BackColor)
    $g.SmoothingMode = 'AntiAlias'
    Fill-Round $g (New-Rgb 24 38 58) 0.5 0.5 ($s.Width - 1.5) ($s.Height - 1.5) 17 (New-Rgb 40 70 110)
    [System.Windows.Forms.TextRenderer]::DrawText($g, $s.Text, $s.Font, $s.ClientRectangle, $s.ForeColor, $tfCenter)
})
$lblChecked.Add_TextChanged({ $this.Invalidate() })

$btnAdbScan = New-Btn '●  ADB: เปิด' { Set-AdbScan (-not $Sync.Paused) } 'scanOn'
$tipAdbScan = New-Object System.Windows.Forms.ToolTip
$tipAdbScan.SetToolTip($btnAdbScan, 'กรุณาปิดก่อนเพิ่มเพื่อน (ปิดแล้วโปรแกรมเร็วขึ้น เครื่องที่เชื่อมอยู่ยังสั่งงานได้)')
function Set-AdbScan([bool]$pause) {
    $Sync.Paused = $pause
    if ($pause) {
        $btnAdbScan.Text = '○  ADB: ปิด'; $btnAdbScan.Tag.Kind = 'scanOff'
        $tipAdbScan.SetToolTip($btnAdbScan, 'กดเพื่อเปิดสแกน ADB อีกครั้ง (หา LD ที่เพิ่งเปิด)')
        Write-LineJobLog 'ปิดการสแกน ADB แล้ว: ตารางค้างตามเดิม เครื่องที่เชื่อมอยู่ยังสั่งงานได้'
    } else {
        $btnAdbScan.Text = '●  ADB: เปิด'; $btnAdbScan.Tag.Kind = 'scanOn'
        $tipAdbScan.SetToolTip($btnAdbScan, 'กรุณาปิดก่อนเพิ่มเพื่อน (ปิดแล้วโปรแกรมเร็วขึ้น เครื่องที่เชื่อมอยู่ยังสั่งงานได้)')
        $Sync.Commands.Enqueue([pscustomobject]@{ Type = 'ConnectAll'; Idx = @() })
        Write-LineJobLog 'เปิดการสแกน ADB แล้ว'
    }
    $btnAdbScan.Invalidate()
    try { $statusBar.Invalidate() } catch {}
}
$chkFindAuto = New-Object System.Windows.Forms.CheckBox
$chkFindAuto.AutoSize = $true; $chkFindAuto.Font = $fontBold; $chkFindAuto.Cursor = [System.Windows.Forms.Cursors]::Hand
$chkFindAuto.Margin = New-Object System.Windows.Forms.Padding(10, 7, 0, 0)
function Update-FindAutoUi {
    $on = [bool]$cfg.FindOaAuto
    $script:FindAutoUiBusy = $true
    if ($chkFindAuto.Checked -ne $on) { $chkFindAuto.Checked = $on }
    $script:FindAutoUiBusy = $false
    $chkFindAuto.Text = $(if ($on) { 'ค้นหา OA อัตโนมัติ: กำลังทำงาน' } else { 'ค้นหา OA อัตโนมัติ' })
    $chkFindAuto.ForeColor = $(if ($on) { New-Rgb 86 211 130 } else { $uiMuted })
    $n = @(Get-FindOaNames ([string]$cfg.FindOaNames))
    try { $tipFindAuto.SetToolTip($chkFindAuto, $(if ($n.Count) { "ชื่อที่ค้นหา: $($n -join ', ')`r`nLD ที่เชื่อม ADB ใหม่จะเข้า LINE แล้วค้นหาเองทันที" } else { 'ยังไม่ได้ใส่ชื่อ OA' })) } catch {}
}
$tipFindAuto = New-Object System.Windows.Forms.ToolTip
$chkFindClose = New-Object System.Windows.Forms.CheckBox
$chkFindClose.AutoSize = $true; $chkFindClose.Font = $font; $chkFindClose.ForeColor = $uiMuted; $chkFindClose.Cursor = [System.Windows.Forms.Cursors]::Hand
$chkFindClose.Margin = New-Object System.Windows.Forms.Padding(8, 8, 0, 0)
$chkFindClose.Text = 'เสร็จแล้วปิด LD'
$chkFindClose.Checked = [bool]$cfg.FindOaAutoClose
$chkFindClose.Add_CheckedChanged({
    $cfg.FindOaAutoClose = $this.Checked; Save-Config
    $this.ForeColor = $(if ($this.Checked) { $uiInk } else { $uiMuted })
    Write-LineJobLog $(if ($this.Checked) { 'ค้นหา OA อัตโนมัติ: เสร็จแล้วจะปิด LD เครื่องนั้นให้เอง' } else { 'ค้นหา OA อัตโนมัติ: เสร็จแล้วไม่ปิด LD' })
})
if ($chkFindClose.Checked) { $chkFindClose.ForeColor = $uiInk }
$chkFindAuto.Add_CheckedChanged({
    if ($script:FindAutoUiBusy) { return }
    $want = $this.Checked
    if ($want -and -not @(Get-FindOaNames ([string]$cfg.FindOaNames)).Count) {
        Add-Type -AssemblyName Microsoft.VisualBasic
        $v = [Microsoft.VisualBasic.Interaction]::InputBox('ใส่ชื่อ LINE OA ที่จะค้นหา (หลายชื่อคั่นด้วย ,)', 'ค้นหา OA อัตโนมัติ', '')
        if (-not @(Get-FindOaNames $v).Count) { Update-FindAutoUi; return }
        $cfg.FindOaNames = $v.Trim()
    }
    Set-FindOaAuto $want
})
$btnLineInfo = New-Btn '☰ ดึงข้อมูล LINE' { $c = Need-Checked 'ดึงข้อมูล LINE'; if ($c.Count) { Start-LineInfoFetch $c } } 'ghost'
$lblSel = New-Label 'ติ๊กเพื่อน'
$lblSel.Margin = New-Object System.Windows.Forms.Padding(0, 9, 8, 0)
$numSel = New-Object System.Windows.Forms.NumericUpDown
$numSel.Minimum = 1; $numSel.Maximum = 500
$numSel.Value = [Math]::Min(500, [Math]::Max(1, [int]$cfg.SelectCount))
$numSel.BackColor = $uiInput
$numSel.ForeColor = $uiInk
$numSel.Font = $font
$numSel.TextAlign = 'Center'
$numSel.Add_ValueChanged({ $cfg.SelectCount = [int]$numSel.Value; Save-Config })
$numSelWrap = New-InputWrap $numSel 70
$numSelWrap.Padding = New-Object System.Windows.Forms.Padding(8, 6, 4, 4)
$numSelWrap.Margin = New-Object System.Windows.Forms.Padding(0)
$lblSelUnit = New-Label 'คน'
$lblSelUnit.Margin = New-Object System.Windows.Forms.Padding(8, 9, 0, 0)
$btnSelect = New-Btn 'ติ๊กวงกลม' { $c = Need-Checked 'ติ๊กเลือกเพื่อน'; if ($c.Count) { Start-LineSelect $c } } 'primary'
$lblUseId = New-Label 'ใช้ ID'
$lblUseId.Margin = New-Object System.Windows.Forms.Padding(0, 9, 6, 0)
$comboUseId = New-Object System.Windows.Forms.ComboBox
$comboUseId.DropDownStyle = 'DropDownList'
$comboUseId.FlatStyle = 'Flat'
$comboUseId.Font = $font
$comboUseId.BackColor = $uiInput
$comboUseId.ForeColor = $uiInk
$comboUseId.Width = 112
$comboUseId.Margin = New-Object System.Windows.Forms.Padding(0, 5, 0, 0)
$comboUseId.Cursor = [System.Windows.Forms.Cursors]::Hand
[void]$comboUseId.Items.Add('ทุกช่อง')
for ($n = 1; $n -le 10; $n++) { [void]$comboUseId.Items.Add("เฉพาะ $(Get-IdColLabel $n)") }
$comboUseId.SelectedIndex = [Math]::Max(0, [Math]::Min(10, [int]$cfg.UseIdCol))
$comboUseId.Add_SelectedIndexChanged({
    if ($comboUseId.SelectedIndex -lt 0 -or $script:RebuildUseId) { return }
    $cfg.UseIdCol = [int]$comboUseId.SelectedIndex
    Save-Config
    $lblStatus.Text = if ($cfg.UseIdCol -eq 0) { 'LINE Script: ใช้ ID ทุกช่องของแต่ละชุด' } else { "LINE Script: ใช้เฉพาะ ID $($cfg.UseIdCol) ของแต่ละชุด" }
})
$lblAfterId = New-Label 'หลังเพิ่ม ID'
$lblAfterId.Margin = New-Object System.Windows.Forms.Padding(10, 9, 6, 0)
$comboAfterId = New-Object System.Windows.Forms.ComboBox
$comboAfterId.DropDownStyle = 'DropDownList'
$comboAfterId.FlatStyle = 'Flat'
$comboAfterId.Font = $font
$comboAfterId.BackColor = $uiInput
$comboAfterId.ForeColor = $uiInk
$comboAfterId.Width = 150
$comboAfterId.Margin = New-Object System.Windows.Forms.Padding(0, 5, 0, 0)
$comboAfterId.Cursor = [System.Windows.Forms.Cursors]::Hand
[void]$comboAfterId.Items.Add('เชิญกลุ่ม+ติ๊ก')
[void]$comboAfterId.Items.Add('จบเลย (ID อย่างเดียว)')
[void]$comboAfterId.Items.Add('เลือกกลุ่มเอง+เชิญตามชื่อ')
[void]$comboAfterId.Items.Add('สร้างกลุ่ม+ใส่ชื่อ ID ที่สแกน')
$comboAfterId.Width = 190
$comboAfterId.SelectedIndex = [Math]::Max(0, [Math]::Min(3, [int]$cfg.AfterIdMode))
$comboAfterId.Add_SelectedIndexChanged({
    $cfg.AfterIdMode = [int]$comboAfterId.SelectedIndex
    $cfg.IdOnly = ($cfg.AfterIdMode -eq 1)
    Save-Config
    $lblStatus.Text = switch ([int]$cfg.AfterIdMode) {
        1 { 'LINE Script: เพิ่ม ID อย่างเดียวแล้วจบ' }
        2 { 'LINE Script: เพิ่ม ID + สแกนชื่อ → หน้าแรก → กลุ่ม → (pop up เลือกกลุ่ม) → แชท → ≡ → เชิญ → ค้นหาด้วยชื่อแล้วติ๊ก' }
        3 { 'LINE Script: เพิ่ม ID + สแกนชื่อ → กลุ่ม → สร้างกลุ่ม → ค้นหาชื่อแล้วติ๊ก → ลบช่องค้นหา → ติ๊กวงกลมตามที่ตั้ง' }
        default { 'LINE Script: เพิ่ม ID → เข้ากลุ่ม/เชิญ → ติ๊กวงกลมต่อ' }
    }
})
$btnLineStart = New-Btn '▶  เริ่มใช้งาน' { $c = Need-Checked 'เริ่มใช้งาน'; if ($c.Count) { Invoke-RunDialog $c } } 'line'
$btnStopSel = New-Btn '■  หยุดที่ติ๊ก' { $c = Need-Checked 'หยุดงาน'; if ($c.Count) { Stop-LineScripts $c } } 'stop'
$btnLineStop = New-Btn '■  หยุดทั้งหมด' { Stop-AllLineScripts } 'stop'
# โหมดติ๊กวงกลม: ถึงล่างสุด / ตามจำนวน  (ใช้กับปุ่มติ๊กวงกลม, เชิญเข้ากลุ่ม และหลัง LINE Script)
$comboSelMode = New-Object System.Windows.Forms.ComboBox
$comboSelMode.DropDownStyle = 'DropDownList'
$comboSelMode.FlatStyle = 'Flat'
$comboSelMode.Font = $font
$comboSelMode.BackColor = $uiInput
$comboSelMode.ForeColor = $uiInk
$comboSelMode.Width = 120
$comboSelMode.Margin = New-Object System.Windows.Forms.Padding(0, 5, 0, 0)
$comboSelMode.Cursor = [System.Windows.Forms.Cursors]::Hand
[void]$comboSelMode.Items.Add('ถึงล่างสุด')
[void]$comboSelMode.Items.Add('ตามจำนวน')
$comboSelMode.SelectedIndex = $(if ([bool]$cfg.SelectAll) { 0 } else { 1 })
function Update-SelAllUi {
    $on = [bool]$cfg.SelectAll
    $want = $(if ($on) { 0 } else { 1 })
    if ($comboSelMode.SelectedIndex -ne $want) { $comboSelMode.SelectedIndex = $want }
    $numSel.Enabled = -not $on
    $numSelWrap.Visible = -not $on
    $lblSelUnit.Visible = -not $on
    $btnSelect.Text = if ($on) { 'ติ๊กถึงล่างสุด' } else { 'ติ๊กตามจำนวน' }
}
$comboSelMode.Add_SelectedIndexChanged({
    $cfg.SelectAll = ($comboSelMode.SelectedIndex -eq 0)
    Save-Config
    Update-SelAllUi
    $lblStatus.Text = if ($cfg.SelectAll) { 'ติ๊กวงกลม: ติ๊กทุกวงจนถึงล่างสุด (ใช้กับเชิญเข้ากลุ่มและหลัง LINE Script ด้วย)' } else { "ติ๊กวงกลม: ติ๊กตามจำนวน $([int]$numSel.Value) คน (ใช้กับเชิญเข้ากลุ่มและหลัง LINE Script ด้วย)" }
})
$lblSel.Text = 'ติ๊กวงกลม'
$selGroup = New-Group @($lblSel, $comboSelMode, $numSelWrap, $lblSelUnit, $btnSelect)
$numSelWrap.Margin = New-Object System.Windows.Forms.Padding(8, 0, 0, 0)
$script:BtnKinds['invite'] = @{ Bg = (New-Rgb 98 60 160); Hover = (New-Rgb 116 74 186); Press = (New-Rgb 84 50 140); Fg = $uiWhite; Border = $null }
$lblMaxMem = New-Label 'กลุ่มไม่เกิน'
$lblMaxMem.Margin = New-Object System.Windows.Forms.Padding(10, 9, 6, 0)
$numMaxMem = New-Object System.Windows.Forms.NumericUpDown
$numMaxMem.Minimum = 1; $numMaxMem.Maximum = 500
$numMaxMem.Value = [Math]::Min(500, [Math]::Max(1, [int]$cfg.MaxGroupMembers))
$numMaxMem.BackColor = $uiInput
$numMaxMem.ForeColor = $uiInk
$numMaxMem.Font = $font
$numMaxMem.TextAlign = 'Center'
$numMaxMem.Add_ValueChanged({ $cfg.MaxGroupMembers = [int]$numMaxMem.Value; Save-Config })
$numMaxMemWrap = New-InputWrap $numMaxMem 70
$numMaxMemWrap.Padding = New-Object System.Windows.Forms.Padding(8, 6, 4, 4)
$numMaxMemWrap.Margin = New-Object System.Windows.Forms.Padding(0)
$lblMaxMemUnit = New-Label 'คน'
$lblMaxMemUnit.Margin = New-Object System.Windows.Forms.Padding(8, 9, 0, 0)
$btnInvite = New-Btn '+  เชิญเข้ากลุ่ม' { $c = Need-Checked 'เชิญเข้ากลุ่ม'; if ($c.Count) { Start-LineGroupInvite $c } } 'invite'
$numSelWrap.Margin = New-Object System.Windows.Forms.Padding(8, 0, 0, 0)
Update-SelAllUi
$btnSelect.Margin = New-Object System.Windows.Forms.Padding(8, 0, 0, 0)
$lblLdSort = New-Label 'เรียง'
$lblLdSort.Margin = New-Object System.Windows.Forms.Padding(10, 9, 6, 0)
$comboLdSort = New-Object System.Windows.Forms.ComboBox
$comboLdSort.DropDownStyle = 'DropDownList'
$comboLdSort.FlatStyle = 'Flat'
$comboLdSort.Font = $font
$comboLdSort.BackColor = $uiInput
$comboLdSort.ForeColor = $uiInk
$comboLdSort.Width = 140
$comboLdSort.Margin = New-Object System.Windows.Forms.Padding(0, 5, 0, 0)
$comboLdSort.Cursor = [System.Windows.Forms.Cursors]::Hand
$script:SortModes = @(0, 4)
if ([int]$cfg.LdSort -notin 0, 4) { $cfg.LdSort = 0 }
foreach ($sn in @('เลข #', 'ชื่อ LINE')) { [void]$comboLdSort.Items.Add($sn) }
$comboLdSort.SelectedIndex = [Math]::Max(0, [array]::IndexOf($script:SortModes, [int]$cfg.LdSort))
$comboLdSort.Add_SelectedIndexChanged({
    $cfg.LdSort = [int]$script:SortModes[[Math]::Max(0, $comboLdSort.SelectedIndex)]
    Save-Config
    try { Update-Sort -Force } catch {}
})
$btnModes = New-Btn 'โหมด' { Show-Page 'settings' } 'ghost'
$btnModes.AutoSizeMode = 'GrowAndShrink'
$btnModes.Font = $font
function Get-AfterIdText {
    switch ([int]$cfg.AfterIdMode) { 1 { 'จบเลย (ID อย่างเดียว)' } 2 { 'เลือกกลุ่มเอง + เชิญตามชื่อ' } 3 { 'สร้างกลุ่ม + ใส่ชื่อ ID ที่สแกน' } default { 'หากลุ่มเอง + ติ๊กวงกลม' } }
}
function Update-ModeHint {
    $ids = if ([int]$cfg.UseIdCol -eq 0) { 'ทุกช่อง' } else { "ID $([int]$cfg.UseIdCol)" }
    $sel = if ([bool]$cfg.SelectAll) { 'ถึงล่างสุด' } else { "$([int]$cfg.SelectCount) คน" }
    $btnModes.Text = "⚙  ใช้ ID: $ids  ·  หลังเพิ่ม ID: $(Get-AfterIdText)  ·  ติ๊ก: $sel"
    try { $script:hintAfterId.Text = switch ([int]$cfg.AfterIdMode) {
        1 { 'เพิ่ม ID ครบแล้วจบ ไม่เข้ากลุ่ม ไม่ติ๊กวงกลม' }
        2 { 'สแกนชื่อของ ID ที่เพิ่ม → หน้าแรก → กลุ่ม → ขึ้นหน้าต่างให้เลือกกลุ่ม → แชท → ≡ → เชิญ → ค้นหาด้วยชื่อแล้วติ๊ก' }
        3 { 'สแกนชื่อของ ID ทุกตัวในชุด → กลุ่ม → สร้างกลุ่ม → ค้นหาด้วยชื่อแล้วติ๊กทีละคน → ลบช่องค้นหา → ติ๊กวงกลมตามที่ตั้ง' }
        default { 'หน้าแรก → กลุ่ม → กลุ่มแรกที่สมาชิกไม่เกินที่ตั้งไว้ → เชิญ → ติ๊กวงกลม (ไม่มีกลุ่มจะสร้างกลุ่มใหม่)' } } } catch {}
}
foreach ($cb in @($comboUseId, $comboAfterId, $comboSelMode)) { $cb.Add_SelectedIndexChanged({ try { Update-ModeHint } catch {} }) }
$numSel.Add_ValueChanged({ try { Update-ModeHint } catch {} })
$btnSelect.Margin = New-Object System.Windows.Forms.Padding(6, 0, 0, 0)
$lblRunHint = New-Label ''
$lblRunHint.Font = $fontSmall
$lblRunHint.ForeColor = $uiFaint
$lblRunHint.Margin = New-Object System.Windows.Forms.Padding(6, 10, 0, 0)
function Update-RunHint {
    $p = if ($cfg.LastPreset) { "รายการล่าสุด: $($cfg.LastPreset)" } else { '' }
    $lblRunHint.Text = $p
    try { if (-not $script:tipRun) { $script:tipRun = New-Object System.Windows.Forms.ToolTip }; $script:tipRun.SetToolTip($btnLineStart, $(if ($p) { $p } else { 'เลือกงานแล้วเริ่ม' })) } catch {}
}
Update-RunHint
Update-FindAutoUi
# ---------- CPU / Memory ของเครื่อง (ค่าเดียวกับ Task Manager) ----------
if (-not ('LdSysMon' -as [type])) {
    Add-Type -TypeDefinition @'
using System; using System.Runtime.InteropServices;
public static class LdSysMon {
    [StructLayout(LayoutKind.Sequential)] struct FT { public uint Lo, Hi; }
    [StructLayout(LayoutKind.Sequential)] public class MEMSTAT { public uint dwLength = 64; public uint dwMemoryLoad; public ulong ullTotalPhys, ullAvailPhys, ullTotalPageFile, ullAvailPageFile, ullTotalVirtual, ullAvailVirtual, ullAvailExtendedVirtual; }
    [DllImport("kernel32.dll")] static extern bool GetSystemTimes(out FT idle, out FT kernel, out FT user);
    [DllImport("kernel32.dll")] static extern bool GlobalMemoryStatusEx([In, Out] MEMSTAT m);
    static ulong pi, pk, pu;
    static ulong U(FT f) { return ((ulong)f.Hi << 32) | f.Lo; }
    // % CPU from GetSystemTimes (fallback when the "% Processor Utility" counter is missing)
    public static double Cpu() {
        FT i, k, u; if (!GetSystemTimes(out i, out k, out u)) return -1;
        ulong ni = U(i), nk = U(k), nu = U(u);
        double di = ni - pi, dk = nk - pk, du = nu - pu; bool first = pi == 0;
        pi = ni; pk = nk; pu = nu;
        if (first || dk + du <= 0) return -1;
        return Math.Max(0, Math.Min(100, (dk + du - di) * 100.0 / (dk + du)));
    }
    // { % used, used bytes, total bytes }
    public static double[] Mem() {
        var m = new MEMSTAT(); m.dwLength = (uint)Marshal.SizeOf(typeof(MEMSTAT));
        if (!GlobalMemoryStatusEx(m)) return new double[] { -1, 0, 0 };
        return new double[] { m.dwMemoryLoad, (double)(m.ullTotalPhys - m.ullAvailPhys), (double)m.ullTotalPhys };
    }
}
'@
}
$script:CpuCounter = $null
try {
    # Task Manager (Windows 10/11) shows "% Processor Utility"; older Windows: "% Processor Time"
    $script:CpuCounter = New-Object System.Diagnostics.PerformanceCounter('Processor Information', '% Processor Utility', '_Total')
    [void]$script:CpuCounter.NextValue()
} catch {
    try { $script:CpuCounter = New-Object System.Diagnostics.PerformanceCounter('Processor', '% Processor Time', '_Total'); [void]$script:CpuCounter.NextValue() } catch { $script:CpuCounter = $null }
}
try { [void][LdSysMon]::Cpu() } catch {}
# การ์ด CPU / Memory บนหัวโปรแกรม (ป้ายชื่อเป็นตัวหนังสือจริง ไม่ได้วาดเอง จึงแสดงแน่นอน)
$script:SysCardBg = New-Rgb 28 33 41
function New-SysCard([string]$title, [int]$width) {
    $p = New-Object System.Windows.Forms.Panel
    $p.Width = $width; $p.Dock = 'Right'; $p.BackColor = $uiBg
    Set-DoubleBuffered $p
    $t = New-Object System.Windows.Forms.Label
    $t.Text = $title; $t.AutoSize = $true; $t.Font = $fontBold; $t.ForeColor = $uiInk; $t.BackColor = $script:SysCardBg
    $t.Location = New-Object System.Drawing.Point(11, 5)
    $v = New-Object System.Windows.Forms.Label
    $v.Text = '–'; $v.AutoSize = $false; $v.TextAlign = 'MiddleRight'; $v.Font = $fontBold; $v.ForeColor = $uiMuted; $v.BackColor = $script:SysCardBg
    $v.Size = New-Object System.Drawing.Size(52, 18); $v.Location = New-Object System.Drawing.Point(($width - 62), 5)
    $v.Anchor = 'Top, Right'
    $p.Controls.Add($t); $p.Controls.Add($v)
    $p.Tag = @{ Value = -1.0; Val = $v; Title = $t; Col = $uiMuted; Tip = '' }
    $p.Add_Paint({
        param($s, $e)
        $g = $e.Graphics
        $g.SmoothingMode = 'AntiAlias'
        $h = $s.ClientSize.Height
        Fill-Round $g $script:SysCardBg 0.5 0.5 ($s.Width - 1.5) ($h - 1.5) 9 (New-Rgb 48 54 64)
        $v = [double]$s.Tag.Value
        $bwFull = [float]($s.Width - 22)
        $by = [float]($h - 6)
        $bt = New-Object System.Drawing.SolidBrush((New-Rgb 48 54 64))
        $g.FillRectangle($bt, [float]11, $by, $bwFull, [float]2.5); $bt.Dispose()
        if ($v -gt 0) {
            $b = New-Object System.Drawing.SolidBrush($s.Tag.Col)
            $g.FillRectangle($b, [float]11, $by, [float]($bwFull * [Math]::Min(100, $v) / 100), [float]2.5); $b.Dispose()
        }
    })
    $p.Add_Resize({ $this.Invalidate() })
    return $p
}
function Set-SysCard($card, [double]$val) {
    if ([Math]::Abs([double]$card.Tag.Value - $val) -lt 0.5) { return }
    $card.Tag.Value = $val
    $col = if ($val -lt 0) { $uiMuted } elseif ($val -ge 90) { New-Rgb 255 110 110 } elseif ($val -ge 70) { New-Rgb 227 179 65 } else { New-Rgb 86 211 130 }
    $card.Tag.Col = $col
    $card.Tag.Val.Text = $(if ($val -lt 0) { '–' } else { "$([int][Math]::Round($val))%" })
    $card.Tag.Val.ForeColor = $col
    $card.Invalidate()
}
$lblMem = New-SysCard 'Memory' 138
$sysGap1 = New-Object System.Windows.Forms.Panel; $sysGap1.Width = 8; $sysGap1.Dock = 'Right'; $sysGap1.BackColor = $uiBg
$lblCpu = New-SysCard 'CPU' 112
$sysGap2 = New-Object System.Windows.Forms.Panel; $sysGap2.Width = 10; $sysGap2.Dock = 'Right'; $sysGap2.BackColor = $uiBg
# right side of the header: [CPU] [Memory] [⚙ ตั้งค่า]
$header.Controls.Add($sysGap2); $sysGap2.BringToFront()
$header.Controls.Add($lblMem); $lblMem.BringToFront()
$header.Controls.Add($sysGap1); $sysGap1.BringToFront()
$header.Controls.Add($lblCpu); $lblCpu.BringToFront()
$tipSys = New-Object System.Windows.Forms.ToolTip
function Update-SysMon {
    $cpu = -1.0
    try { if ($script:CpuCounter) { $cpu = [double]$script:CpuCounter.NextValue() } } catch { $script:CpuCounter = $null }
    if ($cpu -lt 0) { try { $cpu = [double][LdSysMon]::Cpu() } catch {} }
    if ($cpu -gt 100) { $cpu = 100 }
    $m = @(-1, 0, 0)
    try { $m = [LdSysMon]::Mem() } catch {}
    Set-SysCard $lblCpu $cpu
    Set-SysCard $lblMem ([double]$m[0])
    if ([double]$m[2] -gt 0) {
        $tip = "หน่วยความจำ: ใช้ $([Math]::Round($m[1] / 1GB, 1)) GB จาก $([Math]::Round($m[2] / 1GB, 1)) GB"
        if ($lblMem.Tag.Tip -ne $tip) { $lblMem.Tag.Tip = $tip; $tipSys.SetToolTip($lblMem, $tip); $tipSys.SetToolTip($lblMem.Tag.Val, $tip); $tipSys.SetToolTip($lblMem.Tag.Title, $tip) }
    }
}
$tipSys.SetToolTip($lblCpu, 'CPU: การใช้ CPU ของเครื่อง (เหมือน Task Manager)')
$tipSys.SetToolTip($lblMem, 'Memory (RAM): หน่วยความจำที่ใช้อยู่ของเครื่อง')
# ---------- นับยอด 2 หมวด: สมัครใหม่ (LINE Script) / เพิ่มเพื่อน (งานอื่น) ----------
function Get-Counters {
    $c = $cfg.Counters
    $today = (Get-Date).ToString('yyyy-MM-dd')
    if ([string]$c.date -ne $today) { $c.date = $today; foreach ($k in 'regToday', 'regFailToday', 'addToday', 'addFailToday') { $c[$k] = 0 } }
    return $c
}
function Add-Count([string]$cat, [bool]$ok) {
    $c = Get-Counters
    if ($ok) { $c["${cat}Today"] = 1 + [int]$c["${cat}Today"]; $c["${cat}Total"] = 1 + [int]$c["${cat}Total"] }
    else { $c["${cat}FailToday"] = 1 + [int]$c["${cat}FailToday"]; $c["${cat}FailTotal"] = 1 + [int]$c["${cat}FailTotal"] }
    Save-Config
    try { Update-CountUi } catch {}
}
function New-CountChip([string]$title, [System.Drawing.Color]$accent) {
    $p = New-Object System.Windows.Forms.Panel
    $p.Height = 34; $p.Width = 180; $p.BackColor = $uiSurface
    $p.Margin = New-Object System.Windows.Forms.Padding(8, 0, 0, 0)
    Set-DoubleBuffered $p
    $bg = $script:SysCardBg
    $t = New-Object System.Windows.Forms.Label
    $t.Text = $title; $t.AutoSize = $true; $t.Font = $fontSmall; $t.ForeColor = $uiMuted; $t.BackColor = $bg
    $v = New-Object System.Windows.Forms.Label
    $v.Text = '0'; $v.AutoSize = $true; $v.Font = $fontBold; $v.ForeColor = $accent; $v.BackColor = $bg
    $tot = New-Object System.Windows.Forms.Label
    $tot.Text = 'รวม 0'; $tot.AutoSize = $true; $tot.Font = $fontSmall; $tot.ForeColor = $uiMuted; $tot.BackColor = $bg
    $p.Controls.AddRange(@($t, $v, $tot))
    $p.Tag = @{ T = $t; V = $v; Tot = $tot }
    $p.Add_Paint({
        param($s, $e)
        $e.Graphics.SmoothingMode = 'AntiAlias'
        Fill-Round $e.Graphics $script:SysCardBg 0.5 0.5 ($s.Width - 1.5) ($s.Height - 1.5) 9 (New-Rgb 48 54 64)
    })
    return $p
}
function Set-CountChip($chip, [int]$today, [int]$total) {
    $chip.Tag.V.Text = "$today"
    $chip.Tag.Tot.Text = "รวม $total"
    # lay out: [title  today]  [รวม total]
    $x = 11
    $chip.Tag.T.Location = New-Object System.Drawing.Point($x, 10); $x += $chip.Tag.T.PreferredWidth + 4
    $chip.Tag.V.Location = New-Object System.Drawing.Point($x, 8); $x += $chip.Tag.V.PreferredWidth + 8
    $chip.Tag.Tot.Location = New-Object System.Drawing.Point($x, 10); $x += $chip.Tag.Tot.PreferredWidth + 10
    foreach ($l in @($chip.Tag.T, $chip.Tag.V, $chip.Tag.Tot)) { $l.BackColor = $script:SysCardBg }
    if ($chip.Width -ne $x) { $chip.Width = $x }
    $chip.Invalidate()
}
$chipReg = New-CountChip 'สมัครใหม่ วันนี้' (New-Rgb 86 211 130)
$chipAdd = New-CountChip 'เพิ่มเพื่อน วันนี้' (New-Rgb 121 192 255)
$tipCount = New-Object System.Windows.Forms.ToolTip
function Update-CountUi {
    $c = Get-Counters
    Set-CountChip $chipReg ([int]$c.regToday) ([int]$c.regTotal)
    Set-CountChip $chipAdd ([int]$c.addToday) ([int]$c.addTotal)
    $r = "สมัครใหม่ (LINE Script ที่สำเร็จ)`r`nวันนี้: สำเร็จ $([int]$c.regToday) · ไม่สำเร็จ $([int]$c.regFailToday)`r`nรวม: สำเร็จ $([int]$c.regTotal) · ไม่สำเร็จ $([int]$c.regFailTotal)"
    $a = "เพิ่มเพื่อน (ติ๊กวงกลม / เชิญ / สร้างกลุ่ม)`r`nวันนี้: สำเร็จ $([int]$c.addToday) · ไม่สำเร็จ $([int]$c.addFailToday)`r`nรวม: สำเร็จ $([int]$c.addTotal) · ไม่สำเร็จ $([int]$c.addFailTotal)"
    foreach ($w in @($chipReg, $chipReg.Tag.T, $chipReg.Tag.V, $chipReg.Tag.Tot)) { $tipCount.SetToolTip($w, $r) }
    foreach ($w in @($chipAdd, $chipAdd.Tag.T, $chipAdd.Tag.V, $chipAdd.Tag.Tot)) { $tipCount.SetToolTip($w, $a) }
}
$listActions.Controls.Add($chipReg)
$listActions.Controls.Add($chipAdd)
Update-CountUi
$listBar.Controls.AddRange(@(
    (New-Group @($segSel, $lblChecked)),
    (New-Group @($btnLineStart, $btnStopSel, $btnLineStop))))
# header right side: [สแกน ADB] [CPU] [Memory] [⚙ ตั้งค่า]
$sysGap3 = New-Object System.Windows.Forms.Panel; $sysGap3.Width = 10; $sysGap3.Dock = 'Right'; $sysGap3.BackColor = $uiBg
$btnAdbScan.Dock = 'Right'; $btnAdbScan.AutoSize = $false; $btnAdbScan.MinimumSize = New-Object System.Drawing.Size(0, 0)
$btnAdbScan.Width = [System.Windows.Forms.TextRenderer]::MeasureText('○  ADB: เปิด ', $fontBold).Width + 26
$header.Controls.Add($sysGap3); $sysGap3.BringToFront()
$header.Controls.Add($btnAdbScan); $btnAdbScan.BringToFront()

# ---------- หน้าต่าง "เริ่มงาน": เลือกงาน + ตั้งค่า + บันทึกเป็นรายการ ----------
$script:RunJobs = [ordered]@{
    line   = @('▶  LINE Script (เพิ่ม ID)', 'ค้นหาและเพิ่ม ID จากแท็บ "ชุด ID" แล้วทำต่อตาม "หลังเพิ่ม ID"')
    select = @('◉  ติ๊กวงกลมอย่างเดียว', 'ต้องเปิดหน้าเลือกเพื่อน / หน้าเชิญไว้แล้ว')
    invite = @('+  เชิญเข้ากลุ่ม', 'หน้าแรก → กลุ่ม → กลุ่มที่สมาชิกไม่เกินที่ตั้ง → เชิญ → ติ๊กวงกลม')
    creategroup = @('◎  สร้างกลุ่มอย่างเดียว', 'กลุ่ม → สร้างกลุ่ม → ค้นหาด้วยชื่อแล้วติ๊ก → X → ติ๊กวงกลมตามที่ตั้ง')
}
# ---------- "ค้นหากี่ชื่อ" + ช่องกรอกตามจำนวน (ใช้ทั้งหน้าต่างเริ่มงานและแท็บตั้งค่า) ----------
function New-PreTickEditor([string]$init, [scriptblock]$onChange) {
    $f = New-Object System.Windows.Forms.FlowLayoutPanel
    $f.AutoSize = $true; $f.AutoSizeMode = 'GrowAndShrink'; $f.WrapContents = $true
    $f.MaximumSize = New-Object System.Drawing.Size(440, 0)
    $f.Margin = New-Object System.Windows.Forms.Padding(0, 2, 0, 2)
    $ed = @{ Panel = $f; Boxes = @(); Pairs = @(); OnChange = $onChange; Loading = $true }
    $lead = New-Flow
    $l1 = New-Label 'ค้นหา'; $l1.Margin = New-Object System.Windows.Forms.Padding(0, 9, 6, 0)
    $num = New-Object System.Windows.Forms.NumericUpDown
    $num.Minimum = 0; $num.Maximum = 10; $num.Width = 56; $num.TextAlign = 'Center'
    $num.BackColor = $uiInput; $num.ForeColor = $uiInk; $num.Font = $font
    $num.Margin = New-Object System.Windows.Forms.Padding(0, 5, 0, 0)
    $l2 = New-Label 'ชื่อ  (3 ตัวแรก หรือชื่อเต็ม)'; $l2.Margin = New-Object System.Windows.Forms.Padding(6, 9, 14, 0)
    $lead.Controls.AddRange(@($l1, $num, $l2))
    $lead.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 2)
    [void]$f.Controls.Add($lead)
    $f.SetFlowBreak($lead, $true)
    $ed.Num = $num
    for ($i = 1; $i -le 10; $i++) {
        $pair = New-Flow
        $pair.Margin = New-Object System.Windows.Forms.Padding(0, 0, 10, 4)
        $lb = New-Label "$i."; $lb.Font = $fontSmall; $lb.ForeColor = $uiFaint; $lb.Margin = New-Object System.Windows.Forms.Padding(0, 8, 4, 0)
        $tb = New-Object System.Windows.Forms.TextBox
        $tb.BackColor = $uiInput; $tb.ForeColor = $uiInk; $tb.Font = $font; $tb.BorderStyle = 'FixedSingle'; $tb.Width = 150
        $tb.Margin = New-Object System.Windows.Forms.Padding(0, 4, 0, 0)
        $tb.Tag = $ed
        $tb.Add_TextChanged({ $e = $this.Tag; if (-not $e.Loading -and $e.OnChange) { & $e.OnChange } })
        $pair.Controls.AddRange(@($lb, $tb))
        $pair.Visible = $false
        [void]$f.Controls.Add($pair)
        $ed.Boxes += $tb; $ed.Pairs += $pair
    }
    $num.Tag = $ed
    $num.Add_ValueChanged({
        $e = $this.Tag
        for ($i = 0; $i -lt 10; $i++) { $e.Pairs[$i].Visible = ($i -lt [int]$this.Value) }
        if (-not $e.Loading -and $e.OnChange) { & $e.OnChange }
    })
    Set-PreTickText $ed $init
    $ed.Loading = $false
    return $ed
}
function Set-PreTickText($ed, [string]$s) {
    $was = $ed.Loading; $ed.Loading = $true
    $terms = @(([string]$s) -split '[,\r\n]+' | ForEach-Object { $_.Trim() } | Where-Object { $_ } | Select-Object -First 10)
    for ($i = 0; $i -lt 10; $i++) { $ed.Boxes[$i].Text = $(if ($i -lt $terms.Count) { $terms[$i] } else { '' }) }
    $ed.Num.Value = $terms.Count
    for ($i = 0; $i -lt 10; $i++) { $ed.Pairs[$i].Visible = ($i -lt $terms.Count) }
    $ed.Loading = $was
}
function Get-PreTickText($ed) {
    if (-not $ed) { return '' }
    $n = [int]$ed.Num.Value
    return ((@($ed.Boxes | Select-Object -First $n) | ForEach-Object { $_.Text.Trim() } | Where-Object { $_ }) -join ', ')
}
function Get-CurrentRun {
    $job = if ($script:RunJobs.Contains([string]$cfg.LastJob)) { [string]$cfg.LastJob } else { 'line' }
    return [pscustomobject]@{ Name = ''; Job = $job; UseIdCol = [int]$cfg.UseIdCol; AfterIdMode = [int]$cfg.AfterIdMode
                              SelectAll = [bool]$cfg.SelectAll; SelectCount = [int]$cfg.SelectCount; MaxGroupMembers = [int]$cfg.MaxGroupMembers
                              RemoveNames = [string]$cfg.ReplaceOaNames; MinMembers = [int]$cfg.ReplaceMinMembers; PreTickNames = [string]$cfg.PreTickNames; FindOaNames = [string]$cfg.FindOaNames; StartGap = [int]$cfg.StartGap; StartWaitDone = [bool]$cfg.StartWaitDone; ExcludeNames = [string]$cfg.ExcludeNames }
}
function Apply-Run($s) {
    # set the controls of the settings page (their handlers save the config)
    $comboUseId.SelectedIndex = [Math]::Max(0, [Math]::Min($comboUseId.Items.Count - 1, [int]$s.UseIdCol))
    $comboAfterId.SelectedIndex = [Math]::Max(0, [Math]::Min(3, [int]$s.AfterIdMode))
    $numSel.Value = [Math]::Min($numSel.Maximum, [Math]::Max($numSel.Minimum, [int]$s.SelectCount))
    $comboSelMode.SelectedIndex = $(if ([bool]$s.SelectAll) { 0 } else { 1 })
    $numMaxMem.Value = [Math]::Min($numMaxMem.Maximum, [Math]::Max($numMaxMem.Minimum, [int]$s.MaxGroupMembers))
    $cfg.LastJob = [string]$s.Job
    if ($null -ne $s.RemoveNames) { $cfg.ReplaceOaNames = [string]$s.RemoveNames }
    if ($s.PSObject.Properties['FindOaNames'] -and $null -ne $s.FindOaNames) { $cfg.FindOaNames = [string]$s.FindOaNames }
    if ($s.PSObject.Properties['ExcludeNames'] -and $null -ne $s.ExcludeNames) { $cfg.ExcludeNames = [string]$s.ExcludeNames }
    if ($s.PSObject.Properties['StartGap'] -and $null -ne $s.StartGap) { $cfg.StartGap = [Math]::Max(0, [int]$s.StartGap) }
    if ($s.PSObject.Properties['StartWaitDone'] -and $null -ne $s.StartWaitDone) { $cfg.StartWaitDone = [bool]$s.StartWaitDone }
    if ($s.PSObject.Properties['PreTickNames']) { $cfg.PreTickNames = [string]$s.PreTickNames; try { Set-PreTickText $script:setPreEd ([string]$s.PreTickNames) } catch {} }
    if ($null -ne $s.MinMembers -and [int]$s.MinMembers -gt 0) { $cfg.ReplaceMinMembers = [int]$s.MinMembers }
    Save-Config
}
function New-DlgCombo([string[]]$items, [int]$width) {
    $c = New-Object System.Windows.Forms.ComboBox
    $c.DropDownStyle = 'DropDownList'; $c.FlatStyle = 'Flat'; $c.Font = $font
    $c.BackColor = $uiInput; $c.ForeColor = $uiInk; $c.Width = $width
    $c.Margin = New-Object System.Windows.Forms.Padding(0, 3, 0, 3)
    foreach ($i in $items) { [void]$c.Items.Add($i) }
    return $c
}
function New-DlgNum([int]$min, [int]$max, [int]$val) {
    $n = New-Object System.Windows.Forms.NumericUpDown
    $n.Minimum = $min; $n.Maximum = $max; $n.Value = [Math]::Min($max, [Math]::Max($min, $val))
    $n.BackColor = $uiInput; $n.ForeColor = $uiInk; $n.Font = $font; $n.Width = 90; $n.TextAlign = 'Center'
    $n.Margin = New-Object System.Windows.Forms.Padding(0, 3, 0, 3)
    return $n
}
function Show-RunDialog([int[]]$targets) {
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "เริ่มใช้งาน  —  $($targets.Count) เครื่องที่ติ๊ก"
    # always fits the screen: never taller / wider than the work area, can be resized, scrolls when needed
    $wa = [System.Windows.Forms.Screen]::FromControl($form).WorkingArea
    $dlg.StartPosition = 'Manual'
    $dw = [Math]::Min(820, $wa.Width - 24); $dh = [Math]::Min(780, $wa.Height - 24)
    $dlg.Size = New-Object System.Drawing.Size($dw, $dh)
    $dlg.MinimumSize = New-Object System.Drawing.Size([Math]::Min(560, $dw), [Math]::Min(420, $dh))
    $dlg.Location = New-Object System.Drawing.Point(($wa.X + [int](($wa.Width - $dw) / 2)), ($wa.Y + [int](($wa.Height - $dh) / 2)))
    $dlg.FormBorderStyle = 'Sizable'
    $dlg.BackColor = $uiBg; $dlg.ForeColor = $uiInk; $dlg.Font = $font
    $dlg.ShowInTaskbar = $false; $dlg.MaximizeBox = $false; $dlg.MinimizeBox = $false
    try { Set-DarkTitle $dlg } catch {}
    $lay = New-Object System.Windows.Forms.TableLayoutPanel
    $lay.Dock = 'Fill'; $lay.ColumnCount = 1; $lay.AutoScroll = $true
    $lay.Padding = New-Object System.Windows.Forms.Padding(28, 16, 28, 12)
    [void]$lay.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100)))
    function Add-DlgRow($ctl) {
        $lay.RowCount += 1
        [void]$lay.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))
        $lay.Controls.Add($ctl, 0, ($lay.RowCount - 1))
    }
    function New-DlgHead([string]$t) {
        $h = New-Object System.Windows.Forms.Label
        $h.Text = $t; $h.Font = $fontBold; $h.ForeColor = $uiAccentText; $h.AutoSize = $true
        $h.Margin = New-Object System.Windows.Forms.Padding(0, 14, 0, 6)
        return $h
    }
    function New-DlgLine([string]$label, [object[]]$ctrls) {
        $row = New-Table @('Auto', 'Fill')
        $row.Margin = New-Object System.Windows.Forms.Padding(18, 2, 0, 2)
        $l = New-Object System.Windows.Forms.Label
        $l.Text = $label; $l.AutoSize = $false; $l.Width = 170; $l.Height = 34; $l.TextAlign = 'MiddleLeft'; $l.ForeColor = $uiMuted
        if ($script:DlgTips.ContainsKey($label)) { Set-Tip $l $script:DlgTips[$label]; $l.Cursor = [System.Windows.Forms.Cursors]::Help; foreach ($c0 in $ctrls) { Set-Tip $c0 $script:DlgTips[$label] } }
        $f = New-Flow
        $first = $true
        foreach ($c in $ctrls) {
            if (-not $first) { $c.Margin = New-Object System.Windows.Forms.Padding(8, $c.Margin.Top, 0, 0) }
            [void]$f.Controls.Add($c); $first = $false
        }
        $row.Controls.Add($l, 0, 0); $row.Controls.Add($f, 1, 0)
        return $row
    }

    # --- saved lists ---
    Add-DlgRow (New-DlgHead 'รายการที่บันทึกไว้')
    $cbP = New-Object System.Windows.Forms.ComboBox
    $cbP.DropDownStyle = 'DropDown'; $cbP.FlatStyle = 'Flat'; $cbP.Font = $font
    $cbP.BackColor = $uiInput; $cbP.ForeColor = $uiInk; $cbP.Width = 230
    $cbP.Margin = New-Object System.Windows.Forms.Padding(0, 3, 0, 3)
    function Fill-Presets { $cbP.Items.Clear(); foreach ($p in @($cfg.Presets)) { [void]$cbP.Items.Add([string]$p.Name) } }
    Fill-Presets
    $bSave = New-Btn 'บันทึกรายการ' $null 'primary'
    $bDel = New-Btn 'ลบรายการ' $null 'ghost'
    $pHint = New-Label 'พิมพ์ชื่อใหม่แล้วกดบันทึก = เพิ่มรายการใหม่, เลือกชื่อเดิมแล้วกดบันทึก = บันทึกทับ'
    $pHint.MaximumSize = New-Object System.Drawing.Size(460, 0)
    $pHint.Font = $fontSmall; $pHint.ForeColor = $uiFaint
    $pHint.Margin = New-Object System.Windows.Forms.Padding(206, 0, 0, 4)
    Add-DlgRow (New-DlgLine 'ชื่อรายการ' @($cbP, $bSave, $bDel))
    Add-DlgRow $pHint

    # --- job: 2 boxes = which counter the job adds to ---
    Add-DlgRow (New-DlgHead 'งานที่จะสั่ง')
    $radios = @{}
    $jobGrid = New-Object System.Windows.Forms.TableLayoutPanel
    $jobGrid.ColumnCount = 2; $jobGrid.RowCount = 1
    $jobGrid.AutoSize = $true; $jobGrid.AutoSizeMode = 'GrowAndShrink'; $jobGrid.Dock = 'Fill'
    $jobGrid.Margin = New-Object System.Windows.Forms.Padding(18, 0, 0, 4)
    [void]$jobGrid.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 50)))
    [void]$jobGrid.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 50)))
    function New-JobBox([string]$title, [string]$sub, [System.Drawing.Color]$accent, [string[]]$keys, [string]$extraTitle = '', [string[]]$extraKeys = @()) {
        $box = New-Object System.Windows.Forms.FlowLayoutPanel
        $box.FlowDirection = 'TopDown'; $box.WrapContents = $false
        $box.AutoSize = $true; $box.AutoSizeMode = 'GrowAndShrink'; $box.Dock = 'Fill'
        $box.BackColor = $uiSurface
        $box.Padding = New-Object System.Windows.Forms.Padding(14, 10, 12, 10)
        $box.Margin = New-Object System.Windows.Forms.Padding(0, 0, 10, 0)
        $box.Tag = $accent
        Set-DoubleBuffered $box
        $box.Add_Paint({
            param($s, $e)
            $e.Graphics.SmoothingMode = 'AntiAlias'
            $pen = New-Object System.Drawing.Pen($s.Tag, [float]1.5)
            $e.Graphics.DrawRectangle($pen, 1, 1, $s.Width - 3, $s.Height - 3); $pen.Dispose()
            $b = New-Object System.Drawing.SolidBrush($s.Tag)
            $e.Graphics.FillRectangle($b, 1, 1, $s.Width - 3, 4); $b.Dispose()
        })
        $h = New-Object System.Windows.Forms.Label
        $h.Text = $title; $h.AutoSize = $true; $h.Font = $fontTitle; $h.ForeColor = $accent; $h.BackColor = $uiSurface
        $h.Margin = New-Object System.Windows.Forms.Padding(0, 2, 0, 0)
        $hs = New-Label $sub; $hs.Font = $fontSmall; $hs.ForeColor = $uiMuted; $hs.BackColor = $uiSurface
        $hs.Margin = New-Object System.Windows.Forms.Padding(1, 0, 0, 8)
        $box.Controls.AddRange(@($h, $hs))
        $add = {
            param($k)
            $rb = New-Object System.Windows.Forms.RadioButton
            $rb.Text = $script:RunJobs[$k][0]
            $rb.AutoSize = $true; $rb.Font = $fontBold; $rb.ForeColor = $uiInk; $rb.BackColor = $uiSurface; $rb.Cursor = [System.Windows.Forms.Cursors]::Hand
            $rb.Margin = New-Object System.Windows.Forms.Padding(0, 4, 0, 0)
            $rb.Tag = $k
            $radios[$k] = $rb
            Set-Tip $rb ($script:RunJobs[$k][1] + "`r`n" + $(if ($k -eq 'line') { 'สำเร็จแล้วนับเป็น "สมัครใหม่" +1 ต่อเครื่อง' } else { 'สำเร็จแล้วนับเป็น "เพิ่มเพื่อน" +1 ต่อเครื่อง' }))
            $rd = New-Label $script:RunJobs[$k][1]
            $rd.Font = $fontSmall; $rd.ForeColor = $uiFaint; $rd.BackColor = $uiSurface
            $rd.MaximumSize = New-Object System.Drawing.Size(300, 0)
            $rd.Margin = New-Object System.Windows.Forms.Padding(20, 0, 0, 4)
            $box.Controls.AddRange(@($rb, $rd))
        }
        foreach ($k in $keys) { & $add $k }
        if ($extraKeys.Count) {
            $xh = New-Label $extraTitle; $xh.Font = $fontSmallBold; $xh.ForeColor = $uiMuted; $xh.BackColor = $uiSurface
            $xh.Margin = New-Object System.Windows.Forms.Padding(0, 10, 0, 0)
            $box.Controls.Add($xh)
            foreach ($k in $extraKeys) { & $add $k }
        }
        return $box
    }
    $boxReg = New-JobBox 'สมัครใหม่' 'สำเร็จแล้วนับในยอด "สมัครใหม่"' (New-Rgb 86 211 130) @('line')
    $boxAdd = New-JobBox 'เพิ่มเพื่อน' 'สำเร็จแล้วนับในยอด "เพิ่มเพื่อน"' (New-Rgb 121 192 255) @('select', 'invite', 'creategroup')
    $boxAdd.Margin = New-Object System.Windows.Forms.Padding(0)
    $jobGrid.Controls.Add($boxReg, 0, 0); $jobGrid.Controls.Add($boxAdd, 1, 0)
    Add-DlgRow $jobGrid
    # job descriptions wrap to the box width
    $jobGrid.Add_SizeChanged({ foreach ($bx in @($boxReg, $boxAdd)) { $w = [Math]::Max(160, $bx.Width - 50); foreach ($c in $bx.Controls) { if ($c -is [System.Windows.Forms.Label] -and $c.MaximumSize.Width -gt 0) { $c.MaximumSize = New-Object System.Drawing.Size($w, 0) } } } })

    # --- options ---
    $optHead = New-DlgHead 'ตั้งค่างาน'
    Add-DlgRow $optHead
    $dUse = New-DlgCombo (@('ทุกช่อง') + @(1..(Get-IdColCount) | ForEach-Object { "เฉพาะ $(Get-IdColLabel $_)" })) 300
    $dAfter = New-DlgCombo @('หากลุ่มเอง + ติ๊กวงกลม', 'จบเลย (ID อย่างเดียว)', 'เลือกกลุ่มเอง + เชิญตามชื่อ', 'สร้างกลุ่ม + ใส่ชื่อ ID ที่สแกน') 300
    $dSelMode = New-DlgCombo @('ถึงล่างสุด', 'ตามจำนวน') 300
    $dNum = New-DlgNum 1 500 5
    $dNumUnit = New-Label 'คน'; $dNumUnit.Margin = New-Object System.Windows.Forms.Padding(6, 9, 0, 0)
    $dMax = New-DlgNum 1 500 50
    $dMaxUnit = New-Label 'คน'; $dMaxUnit.Margin = New-Object System.Windows.Forms.Padding(6, 9, 0, 0)
    $rowUse = New-DlgLine 'ใช้ ID ของแต่ละชุด' @($dUse)
    $rowAfter = New-DlgLine 'หลังเพิ่ม ID แล้ว' @($dAfter)
    $rowSel = New-DlgLine 'ติ๊กวงกลม' @($dSelMode, $dNum, $dNumUnit)
    $rowMax = New-DlgLine 'เลือกกลุ่มที่สมาชิกไม่เกิน' @($dMax, $dMaxUnit)
    $dRm = New-Object System.Windows.Forms.TextBox
    $dRm.BackColor = $uiInput; $dRm.ForeColor = $uiInk; $dRm.Font = $font; $dRm.BorderStyle = 'FixedSingle'; $dRm.Width = 300
    $dRm.Margin = New-Object System.Windows.Forms.Padding(0, 5, 0, 3)
    $dRmHint = New-Label 'หลายชื่อคั่นด้วย ,'
    $dRmHint.Font = $fontSmall; $dRmHint.ForeColor = $uiFaint; $dRmHint.Margin = New-Object System.Windows.Forms.Padding(8, 9, 0, 0)
    $dMin = New-DlgNum 1 5000 50
    $dMinUnit = New-Label 'คน'; $dMinUnit.Margin = New-Object System.Windows.Forms.Padding(6, 9, 0, 0)
    $rowRm = New-DlgLine 'ชื่อ OA ที่มีปัญหา (จะลบ)' @($dRm, $dRmHint)
    $preEd = New-PreTickEditor '' { Update-Dlg }
    $rowPre = New-DlgLine 'ค้นหาชื่อก่อนติ๊กวงกลม' @($preEd.Panel)
    $dExBoxes = @()
    $dExCtl = @()
    for ($q = 1; $q -le 2; $q++) {
        $lq = New-Label "$q."; $lq.Font = $fontSmall; $lq.ForeColor = $uiFaint; $lq.Margin = New-Object System.Windows.Forms.Padding($(if ($q -gt 1) { 12 } else { 0 }), 9, 4, 0)
        $tq = New-Object System.Windows.Forms.TextBox
        $tq.BackColor = $uiInput; $tq.ForeColor = $uiInk; $tq.Font = $font; $tq.BorderStyle = 'FixedSingle'; $tq.Width = 150
        $tq.Margin = New-Object System.Windows.Forms.Padding(0, 5, 0, 3)
        $dExBoxes += $tq; $dExCtl += $lq; $dExCtl += $tq
    }
    $dExHint = New-Label 'มีคำนี้ในชื่อ = ข้าม (ทั้งตอนค้นหาชื่อ และตอนติ๊กวงกลม)'
    $dExHint.Font = $fontSmall; $dExHint.ForeColor = $uiFaint; $dExHint.Margin = New-Object System.Windows.Forms.Padding(206, 0, 0, 4)
    $rowEx = New-DlgLine 'ไม่ติ๊กวงกลมชื่อเหล่านี้' $dExCtl
    $rowMin = New-DlgLine 'ทำกับกลุ่มที่สมาชิกเกิน' @($dMin, $dMinUnit)
    $dFo = New-Object System.Windows.Forms.TextBox
    $dFo.BackColor = $uiInput; $dFo.ForeColor = $uiInk; $dFo.Font = $font; $dFo.BorderStyle = 'FixedSingle'; $dFo.Width = 300
    $dFo.Margin = New-Object System.Windows.Forms.Padding(0, 5, 0, 3)
    $dFoHint = New-Label 'หลายชื่อคั่นด้วย ,'
    $dFoHint.Font = $fontSmall; $dFoHint.ForeColor = $uiFaint; $dFoHint.Margin = New-Object System.Windows.Forms.Padding(8, 9, 0, 0)
    $rowFo = New-DlgLine 'ชื่อ LINE OA ที่จะค้นหา' @($dFo, $dFoHint)
    $dGap = New-DlgNum 0 600 0
    $dGapUnit = New-Label 'วินาที'; $dGapUnit.Margin = New-Object System.Windows.Forms.Padding(6, 9, 0, 0)
    $dWait = New-Object System.Windows.Forms.CheckBox
    $dWait.Text = 'รอเครื่องก่อนหน้าทำเสร็จก่อน'; $dWait.AutoSize = $true; $dWait.ForeColor = $uiInk; $dWait.Cursor = [System.Windows.Forms.Cursors]::Hand
    $dWait.Margin = New-Object System.Windows.Forms.Padding(14, 8, 0, 3)
    $rowGap = New-DlgLine 'เริ่มทีละเครื่อง ห่างกัน' @($dGap, $dGapUnit, $dWait)
    $dFoAuto = New-Object System.Windows.Forms.CheckBox
    $dFoAuto.Text = 'ค้นหาอัตโนมัติเมื่อเปิด LD'; $dFoAuto.AutoSize = $true; $dFoAuto.ForeColor = $uiInk; $dFoAuto.Cursor = [System.Windows.Forms.Cursors]::Hand
    $dFoAuto.Margin = New-Object System.Windows.Forms.Padding(0, 8, 0, 3)
    $dFoAuto.Checked = [bool]$cfg.FindOaAuto
    $dFoHist = New-Btn 'ดูบันทึกย้อนหลัง' { Show-FindOaHistory } 'ghost'
    $rowFo2 = New-DlgLine 'บันทึก' @($dFoHist)
    $dFoAutoHint = New-Label 'ติ๊กแล้วมีผลทันที: LD ที่เปิดหลังจากนี้ (หรือตอนเปิดโปรแกรม) จะเข้า LINE แล้วค้นหาชื่อในช่องด้านบนเอง ไม่ต้องกดเริ่ม · ผลเก็บลงบันทึกรายวัน'
    $dFoAutoHint.Font = $fontSmall; $dFoAutoHint.ForeColor = $uiFaint; $dFoAutoHint.MaximumSize = New-Object System.Drawing.Size(440, 0)
    $dFoAutoHint.Margin = New-Object System.Windows.Forms.Padding(206, 0, 0, 4)
    foreach ($r in @($rowUse, $rowAfter, $rowGap, $rowSel, $rowPre, $rowEx, $dExHint, $rowMax, $rowRm, $rowMin, $rowFo, $rowFo2)) { Add-DlgRow $r }
    $sum = New-Label ''
    $sum.ForeColor = $uiInk; $sum.MaximumSize = New-Object System.Drawing.Size(640, 0)
    $sum.Padding = New-Object System.Windows.Forms.Padding(12, 10, 12, 10)
    $sum.BackColor = $uiSurface2
    $sum.Margin = New-Object System.Windows.Forms.Padding(18, 16, 0, 0)
    Add-DlgRow $sum

    function Get-DlgJob { foreach ($k in $radios.Keys) { if ($radios[$k].Checked) { return $k } }; return 'line' }
    function Get-DlgRun {
        return [pscustomobject]@{ Name = $cbP.Text.Trim(); Job = (Get-DlgJob); UseIdCol = [int]$dUse.SelectedIndex; AfterIdMode = [int]$dAfter.SelectedIndex
                                  SelectAll = ($dSelMode.SelectedIndex -eq 0); SelectCount = [int]$dNum.Value; MaxGroupMembers = [int]$dMax.Value
                                  RemoveNames = $dRm.Text.Trim(); MinMembers = [int]$dMin.Value; PreTickNames = (Get-PreTickText $preEd); FindOaNames = $dFo.Text.Trim(); StartGap = [int]$dGap.Value; StartWaitDone = [bool]$dWait.Checked; ExcludeNames = ((@($dExBoxes | ForEach-Object { $_.Text.Trim() } | Where-Object { $_ })) -join ', ') }
    }
    function Set-Dlg($s) {
        $k = if ($radios.ContainsKey([string]$s.Job)) { [string]$s.Job } else { 'line' }
        $radios[$k].Checked = $true
        $dUse.SelectedIndex = [Math]::Max(0, [Math]::Min($dUse.Items.Count - 1, [int]$s.UseIdCol))
        $dAfter.SelectedIndex = [Math]::Max(0, [Math]::Min(3, [int]$s.AfterIdMode))
        $dSelMode.SelectedIndex = $(if ([bool]$s.SelectAll) { 0 } else { 1 })
        $dNum.Value = [Math]::Min(500, [Math]::Max(1, [int]$s.SelectCount))
        $dMax.Value = [Math]::Min(500, [Math]::Max(1, [int]$s.MaxGroupMembers))
        $dRm.Text = $(if ($s.PSObject.Properties['RemoveNames'] -and $s.RemoveNames) { [string]$s.RemoveNames } else { [string]$cfg.ReplaceOaNames })
        $exs = @(([string]$(if ($s.PSObject.Properties['ExcludeNames'] -and $null -ne $s.ExcludeNames) { [string]$s.ExcludeNames } else { [string]$cfg.ExcludeNames })) -split '[,\r\n]+' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
        for ($q = 0; $q -lt 2; $q++) { $dExBoxes[$q].Text = $(if ($q -lt $exs.Count) { $exs[$q] } else { '' }) }
        $dGap.Value = [Math]::Min(600, [Math]::Max(0, $(if ($s.PSObject.Properties['StartGap'] -and $null -ne $s.StartGap) { [int]$s.StartGap } else { [int]$cfg.StartGap })))
        $dWait.Checked = $(if ($s.PSObject.Properties['StartWaitDone'] -and $null -ne $s.StartWaitDone) { [bool]$s.StartWaitDone } else { [bool]$cfg.StartWaitDone })
        $dFo.Text = $(if ($s.PSObject.Properties['FindOaNames'] -and $s.FindOaNames) { [string]$s.FindOaNames } else { [string]$cfg.FindOaNames })
        Set-PreTickText $preEd $(if ($s.PSObject.Properties['PreTickNames']) { [string]$s.PreTickNames } else { [string]$cfg.PreTickNames })
        $dMin.Value = [Math]::Min(5000, [Math]::Max(1, $(if ($s.PSObject.Properties['MinMembers'] -and [int]$s.MinMembers -gt 0) { [int]$s.MinMembers } else { [int]$cfg.ReplaceMinMembers })))
    }
    function Update-Dlg {
        $s = Get-DlgRun
        $isLine = ($s.Job -eq 'line')
        $needSel = ($s.Job -in 'select', 'invite', 'creategroup') -or ($isLine -and $s.AfterIdMode -in 0, 3)
        $needMax = ($s.Job -eq 'invite') -or ($isLine -and $s.AfterIdMode -eq 0)
        $isRep = ($s.Job -eq 'replaceoa')
        $rowUse.Enabled = ($isLine -or $isRep); $rowAfter.Enabled = $isLine
        $rowRm.Enabled = $isRep; $rowMin.Enabled = $isRep
        $rowGap.Enabled = ($isLine -or $isRep)
        $rowFo.Enabled = ($s.Job -eq 'findoa'); $rowFo2.Enabled = $rowFo.Enabled; $dFoAutoHint.Enabled = $rowFo.Enabled
        $rowSel.Enabled = $needSel; $rowMax.Enabled = $needMax; $rowEx.Enabled = ($needSel -or ($s.Job -in 'invite', 'creategroup') -or ($isLine -and $s.AfterIdMode -in 0, 2, 3)); $dExHint.Enabled = $rowEx.Enabled
        $rowPre.Enabled = ($s.Job -in 'invite', 'creategroup') -or ($isLine -and $s.AfterIdMode -in 0, 2, 3)
        # show only the settings this job uses (shorter window)
        $lay.SuspendLayout()
        foreach ($rw in @($rowUse, $rowAfter, $rowGap, $rowSel, $rowPre, $rowEx, $dExHint, $rowMax, $rowRm, $rowMin, $rowFo, $rowFo2)) { if ($rw.Visible -ne $rw.Enabled) { $rw.Visible = $rw.Enabled } }
        $optHead.Visible = [bool]@(@($rowUse, $rowAfter, $rowGap, $rowSel, $rowPre, $rowEx, $rowMax, $rowRm, $rowMin, $rowFo) | Where-Object { $_.Enabled }).Count
        $lay.ResumeLayout()
        $dNum.Visible = -not $s.SelectAll; $dNumUnit.Visible = -not $s.SelectAll
        $dSelMode.Width = $(if ($s.SelectAll) { 300 } else { 196 })
        $tick = if ($s.SelectAll) { 'ติ๊กวงกลมถึงล่างสุด' } else { "ติ๊กวงกลม $($s.SelectCount) คน" }
        if ($s.ExcludeNames) { $tick += " (ยกเว้น '$($s.ExcludeNames)')" }
        $ids = if ($s.UseIdCol -eq 0) { 'ทุก ID ในชุด' } else { "ID $($s.UseIdCol) ของชุด" }
        $sum.Text = 'จะทำ: ' + $(switch ($s.Job) {
            'line' { switch ($s.AfterIdMode) {
                    1 { "เพิ่ม $ids แล้วจบ" }
                    2 { "เพิ่ม $ids + สแกนชื่อ → หน้าแรก → กลุ่ม → ขึ้นหน้าต่างให้เลือกกลุ่ม → แชท → ≡ → เชิญ → $(if ($s.PreTickNames) { "ค้นหา '$($s.PreTickNames)' แล้วติ๊ก (ชื่อละ 1) → " })ค้นหาด้วยชื่อที่สแกนแล้วติ๊ก" }
                    3 { "เพิ่ม $ids + สแกนชื่อ → กลุ่ม → สร้างกลุ่ม → ค้นหาด้วยชื่อที่สแกนแล้วติ๊ก$(if ($s.PreTickNames) { " (+ '$($s.PreTickNames)')" }) → ลบช่องค้นหา → $tick" }
                    default { "เพิ่ม $ids → หน้าแรก → กลุ่ม (ไม่เกิน $($s.MaxGroupMembers) คน) → เชิญ → $tick" } } }
            'select' { "$tick ในหน้าที่เปิดอยู่" }
            'creategroup' { "กลุ่ม → สร้างกลุ่ม → $(if ($s.PreTickNames) { "ค้นหา '$($s.PreTickNames)' แล้วติ๊ก → X → " } else { '(ไม่ได้ใส่ชื่อค้นหา) → ' })$tick" }
            'invite' { "หน้าแรก → กลุ่ม (ไม่เกิน $($s.MaxGroupMembers) คน) → เชิญ → $(if ($s.PreTickNames) { "ค้นหา '$($s.PreTickNames)' แล้วติ๊ก → X → " })$tick" }
            'info' { 'อ่านชื่อ LINE / เพื่อน / กลุ่ม' }
            'findoa' { $fn = @(Get-FindOaNames $s.FindOaNames); if ($fn.Count) { "หน้าแรก → กดช่องค้นหา → พิมพ์ $(($fn | ForEach-Object { "'$_'" }) -join ', ') ทีละชื่อ → จบแล้วขึ้นรายงานว่า # ไหนเจอ / ไม่เจอ" } else { '(ยังไม่ได้ใส่ชื่อ OA ที่จะค้นหา)' } }
            'replaceoa' { $rn = if ($s.RemoveNames) { "'$($s.RemoveNames)'" } else { '(ยังไม่ได้ใส่ชื่อ OA ที่จะลบ)' }; "กลุ่มที่สมาชิกเกิน $($s.MinMembers) คน → ≡ → สมาชิก → แก้ไข → ลบ $rn → หน้าแรก → เพิ่ม OA ใหม่ ($ids) + สแกนชื่อ → เข้ากลุ่มเดิม → ≡ → เชิญ → ค้นหาด้วยชื่อ OA ใหม่แล้วติ๊ก" }
            }) + $(if (($isLine -or $isRep) -and ($s.StartGap -gt 0 -or $s.StartWaitDone)) { "  ·  เริ่มทีละเครื่อง$(if ($s.StartGap -gt 0) { " ห่าง $($s.StartGap) วิ" })$(if ($s.StartWaitDone) { ' (รอเสร็จก่อน)' })" } else { '' }) + "  ·  $($targets.Count) เครื่อง"
    }
    # each radio sits in its own row, so keep only one selected by hand
    foreach ($rb in $radios.Values) {
        $rb.Add_CheckedChanged({
            if ($this.Checked) { foreach ($o in @($radios.Values)) { if ($o -ne $this -and $o.Checked) { $o.Checked = $false } } }
            Update-Dlg
        })
    }
    foreach ($c in @($dUse, $dAfter, $dSelMode)) { $c.Add_SelectedIndexChanged({ Update-Dlg }) }
    foreach ($n in @($dNum, $dMax, $dMin, $dGap)) { $n.Add_ValueChanged({ Update-Dlg }) }
    $dWait.Add_CheckedChanged({ Update-Dlg })
    foreach ($tq in $dExBoxes) { $tq.Add_TextChanged({ Update-Dlg }) }
    $dRm.Add_TextChanged({ Update-Dlg })
    $dFo.Add_TextChanged({ Update-Dlg; if ($dFoAuto.Checked) { $cfg.FindOaNames = $dFo.Text.Trim(); Save-Config } })
    $dFoAuto.Add_CheckedChanged({
        if ($this.Checked -and -not @(Get-FindOaNames $dFo.Text).Count) { [void][System.Windows.Forms.MessageBox]::Show($dlg, 'ใส่ชื่อ LINE OA ที่จะค้นหาก่อน แล้วค่อยติ๊ก', 'ค้นหาอัตโนมัติ'); $this.Checked = $false; return }
        $cfg.FindOaNames = $dFo.Text.Trim()
        if ([bool]$cfg.FindOaAuto -ne $this.Checked) { Set-FindOaAuto $this.Checked }
    })
    $cbP.Add_SelectedIndexChanged({
        $nm = [string]$cbP.SelectedItem
        $p = @($cfg.Presets | Where-Object { $_.Name -eq $nm } | Select-Object -First 1)
        if ($p.Count) { Set-Dlg $p[0]; Update-Dlg }
    })
    $bSave.Add_Click({
        $s = Get-DlgRun
        if (-not $s.Name) { [void][System.Windows.Forms.MessageBox]::Show($dlg, 'กรุณาพิมพ์ชื่อรายการก่อน', 'บันทึกรายการ'); return }
        $list = @($cfg.Presets | Where-Object { $_.Name -ne $s.Name })
        $cfg.Presets = @($list + $s)
        $cfg.LastPreset = $s.Name
        Save-Config
        Fill-Presets
        $cbP.Text = $s.Name
        Write-LineJobLog "บันทึกรายการ '$($s.Name)' แล้ว"
    })
    $bDel.Add_Click({
        $nm = $cbP.Text.Trim()
        if (-not $nm -or -not @($cfg.Presets | Where-Object { $_.Name -eq $nm }).Count) { return }
        if ([System.Windows.Forms.MessageBox]::Show($dlg, "ลบรายการ '$nm' ?", 'ลบรายการ', 'YesNo', 'Question') -ne 'Yes') { return }
        $cfg.Presets = @($cfg.Presets | Where-Object { $_.Name -ne $nm })
        if ($cfg.LastPreset -eq $nm) { $cfg.LastPreset = '' }
        Save-Config
        Fill-Presets
        $cbP.Text = ''
    })

    # --- buttons ---
    $bar = New-Object System.Windows.Forms.FlowLayoutPanel
    $bar.Dock = 'Bottom'; $bar.AutoSize = $true; $bar.FlowDirection = 'RightToLeft'
    $bar.Padding = New-Object System.Windows.Forms.Padding(28, 10, 28, 16)
    $bar.BackColor = $uiBg
    $script:RunChoice = $null
    $bGo = New-Btn '▶  เริ่ม' {
        $s = Get-DlgRun
        if ($s.Job -eq 'findoa' -and -not @(Get-FindOaNames $s.FindOaNames).Count) { [void][System.Windows.Forms.MessageBox]::Show($dlg, 'กรุณาใส่ชื่อ LINE OA ที่จะค้นหา', 'ค้นหา LINE OA'); return }
        if ($s.Job -eq 'replaceoa' -and -not $s.RemoveNames) { [void][System.Windows.Forms.MessageBox]::Show($dlg, 'กรุณาใส่ชื่อ OA ที่มีปัญหา (ชื่อที่จะลบออกจากกลุ่ม)', 'เปลี่ยน OA ในกลุ่ม'); return }
        $script:RunChoice = $s; $dlg.Close()
    } 'line'
    $bCancel = New-Btn 'ยกเลิก' { $script:RunChoice = $null; $dlg.Close() } 'ghost'
    $bGo.Margin = New-Object System.Windows.Forms.Padding(8, 0, 0, 0)
    $bar.Controls.AddRange(@($bGo, $bCancel))

    # start from the last used list (or the current settings)
    $start = Get-CurrentRun
    $last = @($cfg.Presets | Where-Object { $_.Name -eq [string]$cfg.LastPreset } | Select-Object -First 1)
    if ($last.Count) { $start = $last[0]; $cbP.Text = [string]$last[0].Name }
    Set-Dlg $start
    Update-Dlg

    $dlg.Controls.Add($lay)
    $dlg.Controls.Add($bar)
    $dlg.AcceptButton = $bGo
    try { Apply-Texts $dlg } catch {}
    [void]$dlg.ShowDialog($form)
    $dlg.Dispose()
    return $script:RunChoice
}
function Invoke-RunDialog([int[]]$targets) {
    $s = Show-RunDialog $targets
    if (-not $s) { return }
    Apply-Run $s
    if ($s.Name -and @($cfg.Presets | Where-Object { $_.Name -eq $s.Name }).Count) { $cfg.LastPreset = $s.Name; Save-Config }
    Update-RunHint
    $label = $script:RunJobs[[string]$s.Job][0].Trim()
    Write-LineJobLog "เริ่มงาน: $label$(if ($s.Name) { " (รายการ '$($s.Name)')" }) กับ $($targets.Count) เครื่อง"
    switch ([string]$s.Job) {
        'select' { Start-LineSelect $targets }
        'invite' { Start-LineGroupInvite $targets }
        'creategroup' { Start-LineGroupInvite $targets 'create' }
        'info'   { Start-LineInfoFetch $targets }
        'findoa' { Start-LineFindOa $targets }
        'replaceoa' { foreach ($tg in $targets) { $script:LineModeFor[[int]$tg] = 'replaceoa' }; Start-LineScript $targets }
        default  { Start-LineScript $targets }
    }
}
$navBar.Controls.Add($navFlow, 0, 0)
$navBar.Controls.Add($listActions, 2, 0)
$contentCard.Controls.Add($navBar, 0, 0)

$tabs = New-Object System.Windows.Forms.Panel
$tabs.Dock = 'Fill'
$tabs.Margin = New-Object System.Windows.Forms.Padding(0)
function New-Page {
    $p = New-Object System.Windows.Forms.Panel
    $p.Dock = 'Fill'
    $p.Visible = $false
    $p.Padding = New-Object System.Windows.Forms.Padding(0)
    return $p
}
$tabList = New-Page
$tabConfig = New-Page
$tabLog = New-Page
$script:pages['list'] = $tabList
$script:pages['config'] = $tabConfig
$script:pages['log'] = $tabLog
$tabList.Controls.Add($grid)
$tabList.Controls.Add($listBar)
$tabSettings = New-Page
$script:pages['settings'] = $tabSettings
# ---------- หน้า ตั้งค่า: ทุกการตั้งค่าอยู่ที่นี่ แยกเป็นหมวดตามปุ่มที่ใช้ ----------
$setFlow = New-Object System.Windows.Forms.FlowLayoutPanel
$setFlow.Dock = 'Fill'
$setFlow.FlowDirection = 'TopDown'
$setFlow.WrapContents = $false
$setFlow.AutoScroll = $true
$setFlow.BackColor = $uiSurface
$setFlow.Padding = New-Object System.Windows.Forms.Padding(0, 2, 0, 0)
function Add-SecCtl($sec, $ctl) {
    $sec.RowCount += 1
    [void]$sec.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))
    $sec.Controls.Add($ctl, 0, ($sec.RowCount - 1))
}
function New-SetSection([string]$title, [string]$sub) {
    $sec = New-Card 1
    $sec.RowCount = 0
    $sec.Dock = 'None'
    $sec.AutoSize = $true
    $sec.AutoSizeMode = 'GrowAndShrink'
    $sec.Padding = New-Object System.Windows.Forms.Padding(16, 12, 16, 10)
    $sec.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 10)
    $h = New-Object System.Windows.Forms.Label
    $h.Text = $title; $h.Font = $fontBold; $h.ForeColor = $uiInk; $h.AutoSize = $true
    $h.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 2)
    Add-SecCtl $sec $h
    if ($sub) {
        $s = New-Label $sub
        $s.Font = $fontSmall; $s.ForeColor = $uiFaint
        $s.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 8)
        Add-SecCtl $sec $s
    }
    [void]$setFlow.Controls.Add($sec)
    return $sec
}
function Add-SetRow($sec, [string]$label, [object[]]$ctrls, [string]$hint = '') {
    $row = New-Table @('Auto', 'Auto', 'Fill')
    $row.Margin = New-Object System.Windows.Forms.Padding(0, 2, 0, 2)
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $label; $l.AutoSize = $false; $l.Width = 170; $l.Height = 34
    $l.TextAlign = 'MiddleLeft'; $l.ForeColor = $uiMuted
    $l.Margin = New-Object System.Windows.Forms.Padding(0)
    $f = New-Flow
    $f.Anchor = 'Left'
    $first = $true
    foreach ($c in $ctrls) {
        $left = if ($first) { 0 } else { 8 }
        $top = if ($c -is [System.Windows.Forms.ComboBox]) { 5 } elseif ($c -is [System.Windows.Forms.Label]) { 9 } else { 0 }
        $c.Margin = New-Object System.Windows.Forms.Padding($left, $top, 0, 0)
        [void]$f.Controls.Add($c)
        $first = $false
    }
    $hl = New-Label $hint
    $hl.Font = $fontSmall; $hl.ForeColor = $uiFaint; $hl.Anchor = 'Left'
    $hl.Margin = New-Object System.Windows.Forms.Padding(14, 0, 0, 0)
    $row.Controls.Add($l, 0, 0); $row.Controls.Add($f, 1, 0); $row.Controls.Add($hl, 2, 0)
    Add-SecCtl $sec $row
    return $hl
}
# 1) LINE Script
$secLine = New-SetSection '▶  LINE Script' 'ใช้กับปุ่ม "▶ เริ่ม LINE" — ชุด ID แก้ได้ที่แท็บ "ชุด ID"'
[void](Add-SetRow $secLine 'ใช้ ID ของแต่ละชุด' @($comboUseId) 'ทุกช่อง = ค้นหาทุก ID ในชุด, เฉพาะ ID n = ใช้แค่ช่องเดียว')
$comboAfterId.Width = 230
$script:hintAfterId = Add-SetRow $secLine 'หลังเพิ่ม ID แล้ว' @($comboAfterId) ''
# 2) tick circles
$secSel = New-SetSection '◉  ติ๊กวงกลม' 'ใช้กับปุ่ม "ติ๊กวงกลม" และหลังเปิดหน้าเชิญ (วงที่เป็นสีเขียวแล้วจะไม่ติ๊กซ้ำ)'
[void](Add-SetRow $secSel 'วิธีติ๊ก' @($comboSelMode, $numSelWrap, $lblSelUnit) 'ถึงล่างสุด = ติ๊กทุกวงจนสุดรายการ, ตามจำนวน = ติ๊กครบตามที่ใส่แล้วหยุด')
# 3) group invite
$secInv = New-SetSection '+  เชิญเข้ากลุ่ม' 'ใช้กับปุ่ม "+ เชิญเข้ากลุ่ม" และโหมด "หากลุ่มเอง + ติ๊กวงกลม"'
[void](Add-SetRow $secInv 'เลือกกลุ่มที่สมาชิกไม่เกิน' @($numMaxMemWrap, $lblMaxMemUnit) 'ถ้าทุกกลุ่มเกินจำนวนนี้ หรือไม่มีกลุ่ม จะสร้างกลุ่มใหม่')
$script:setPreEd = New-PreTickEditor ([string]$cfg.PreTickNames) { if ($script:setPreEd) { $cfg.PreTickNames = Get-PreTickText $script:setPreEd; Save-Config } }
[void](Add-SetRow $secInv 'ค้นหาชื่อก่อนติ๊กวงกลม' @($script:setPreEd.Panel) 'กดเชิญแล้ว → ค้นหาทีละชื่อ → ติ๊กทุกคนที่ตรง → กด X → ติ๊กวงกลมตามที่ตั้ง')
# 4) device list
$secList = New-SetSection '☰  รายการเครื่อง' 'แสดงเฉพาะ LD ที่เปิดอยู่และเชื่อม ADB แล้ว'
[void](Add-SetRow $secList 'เรียงตาม' @($comboLdSort) '')
$comboTheme = New-Object System.Windows.Forms.ComboBox
$comboTheme.DropDownStyle = 'DropDownList'; $comboTheme.FlatStyle = 'Flat'; $comboTheme.Font = $font
$comboTheme.BackColor = $uiInput; $comboTheme.ForeColor = $uiInk; $comboTheme.Width = 160
[void]$comboTheme.Items.Add('มืด (Dark)'); [void]$comboTheme.Items.Add('สว่าง (Light)')
$comboTheme.SelectedIndex = $(if ($script:LightTheme) { 1 } else { 0 })
$comboTheme.Add_SelectionChangeCommitted({
    $want = if ($comboTheme.SelectedIndex -eq 1) { 'light' } else { 'dark' }
    if (-not (Switch-Theme $want)) { $comboTheme.SelectedIndex = $(if ($script:LightTheme) { 1 } else { 0 }) }
})
[void](Add-SetRow $secList 'ธีมหน้าจอ' @($comboTheme) 'เปลี่ยนแล้วมีผลทันที')
$btnCountReset = New-Btn 'รีเซ็ตยอดนับ' {
    if ([System.Windows.Forms.MessageBox]::Show($form, "รีเซ็ตยอด สมัครใหม่ / เพิ่มเพื่อน ทั้งของวันนี้และยอดรวมเป็น 0 ?", 'รีเซ็ตยอดนับ', 'YesNo', 'Question') -ne 'Yes') { return }
    $cfg.Counters = @{ date = (Get-Date).ToString('yyyy-MM-dd') }
    foreach ($k in 'regToday', 'regFailToday', 'addToday', 'addFailToday', 'regTotal', 'regFailTotal', 'addTotal', 'addFailTotal') { $cfg.Counters[$k] = 0 }
    Save-Config; Update-CountUi
    Write-LineJobLog 'รีเซ็ตยอดนับ สมัครใหม่ / เพิ่มเพื่อน แล้ว'
} 'ghost'
[void](Add-SetRow $secList 'ยอดนับ' @($btnCountReset) 'สมัครใหม่ = LINE Script ที่สำเร็จ · เพิ่มเพื่อน = งานอื่นที่สำเร็จ (นับครั้งต่อเครื่อง)')
$chkAutoInfo = New-Object System.Windows.Forms.CheckBox
$chkAutoInfo.Text = 'ดึงข้อมูล LINE อัตโนมัติ'
$chkAutoInfo.AutoSize = $true; $chkAutoInfo.ForeColor = $uiInk; $chkAutoInfo.Cursor = [System.Windows.Forms.Cursors]::Hand
$chkAutoInfo.Checked = [bool]$cfg.AutoInfo
$chkAutoInfo.Add_CheckedChanged({ $cfg.AutoInfo = $chkAutoInfo.Checked; Save-Config; $grid.Invalidate() })

# 5) ADB connection
$secAdb = New-SetSection '⚡  การเชื่อมต่อ ADB' 'โฟลเดอร์ LDPlayer และการเชื่อมต่ออัตโนมัติ'
$lblDir.AutoSize = $false; $lblDir.Width = 170; $lblDir.Height = 34; $lblDir.TextAlign = 'MiddleLeft'
$row1.Margin = New-Object System.Windows.Forms.Padding(0, 2, 0, 6)
Add-SecCtl $secAdb $row1
foreach ($c in @($chkAuto, $lblEvery, $numWrap, $lblSec)) { [void]$row2Opts.Controls.Remove($c) }
[void](Add-SetRow $secAdb 'เชื่อมต่ออัตโนมัติ' @($chkAuto, $lblEvery, $numWrap, $lblSec) '')
# ================= อัปเดตโปรแกรมอัตโนมัติ (ไฟล์ version.json + LineDeck.zip บน GitHub) =================
# ลิงก์ version.json: ตั้งในหน้าตั้งค่า หรือใส่ไว้ในไฟล์ update.json ข้างโปรแกรม (ผู้ดูแลตั้งครั้งเดียวแล้วแจกพร้อม zip)
$script:UpdTask = $null; $script:UpdKind = ''; $script:UpdInfo = $null; $script:UpdFile = ''; $script:UpdManual = $false
$script:UpdNextCheck = (Get-Date).AddSeconds(8)
$script:UpdPending = $null   # update downloaded/accepted, waiting for running jobs to finish
function Get-UpdateUrl {
    if (([string]$cfg.UpdateUrl).Trim()) { return ([string]$cfg.UpdateUrl).Trim() }
    try {
        $f = Join-Path $PSScriptRoot 'update.json'
        if (Test-Path -LiteralPath $f) { $j = Get-Content -LiteralPath $f -Raw -Encoding UTF8 | ConvertFrom-Json; if ($j.versionUrl) { return ([string]$j.versionUrl).Trim() } }
    } catch {}
    return ''
}
# "v2026.10.25 #6" -> 2026102500006 (compare as numbers)
function Get-VersionNum([string]$v) {
    $m = [regex]::Match([string]$v, '(\d{4})\.(\d{1,2})\.(\d{1,2})(?:\s*#\s*(\d+))?')
    if (-not $m.Success) { return [int64]0 }
    $n = [int64]$m.Groups[1].Value * 100000000 + [int64]$m.Groups[2].Value * 1000000 + [int64]$m.Groups[3].Value * 10000
    if ($m.Groups[4].Success) { $n += [int64]$m.Groups[4].Value }
    return $n
}
function Set-UpdStatus([string]$t) { try { $lblUpdStatus.Text = $t } catch {} }
function Start-UpdateCheck([bool]$manual = $false) {
    if ($script:UpdTask) { return }
    $url = Get-UpdateUrl
    if (-not $url) { if ($manual) { [void][System.Windows.Forms.MessageBox]::Show($form, 'ยังไม่ได้ตั้งลิงก์ version.json (หน้าตั้งค่า → อัปเดตโปรแกรม)', 'อัปเดตโปรแกรม') }; return }
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        $wc = New-Object System.Net.WebClient
        $wc.Headers['Cache-Control'] = 'no-cache'
        $wc.Encoding = [System.Text.Encoding]::UTF8
        $sep = if ($url.Contains('?')) { '&' } else { '?' }
        $script:UpdTask = $wc.DownloadStringTaskAsync("$url$($sep)t=$([DateTime]::UtcNow.Ticks)")
        $script:UpdKind = 'check'; $script:UpdManual = $manual
        Set-UpdStatus 'กำลังเช็คเวอร์ชันล่าสุด...'
        $script:UpdTimer.Start()
    } catch { Set-UpdStatus "เช็คไม่ได้: $($_.Exception.Message)" }
}
function Start-UpdateDownload {
    $info = $script:UpdInfo
    try { $updBanner.Tag.Text = "กำลังดาวน์โหลด $($info.version) ... โปรแกรมจะเปิดใหม่ให้เอง"; $updBanner.Tag.W = 0 } catch {}
    $dir = Join-Path $env:TEMP 'LineDeck_update'
    [void][System.IO.Directory]::CreateDirectory($dir)
    $script:UpdFile = Join-Path $dir ("LineDeck_{0}.zip" -f (Get-VersionNum ([string]$info.version)))
    Remove-Item -LiteralPath $script:UpdFile -Force -ErrorAction SilentlyContinue
    $wc = New-Object System.Net.WebClient
    $script:UpdTask = $wc.DownloadFileTaskAsync([string]$info.url, $script:UpdFile)
    $script:UpdKind = 'download'
    Set-UpdStatus "กำลังดาวน์โหลด $($info.version)..."
    Write-LineJobLog "อัปเดต: กำลังดาวน์โหลด $($info.version)"
    $script:UpdTimer.Start()
}
function Test-AppBusy { return ($script:LineJobs.Count + $script:InfoJobs.Count + $(if ($script:LineStartQueue) { $script:LineStartQueue.Count } else { 0 })) -gt 0 }
function Install-Update {
    # check the zip, then a small helper waits for this window to close, unzips over the program folder and starts it again
    $zip = $script:UpdFile
    try {
        $want = ([string]$script:UpdInfo.sha256).Trim().ToLowerInvariant()
        if ($want) {
            $have = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
            if ($have -ne $want) { throw "ไฟล์ไม่ตรงกับรหัส SHA-256 ใน version.json (ไฟล์อาจเสียหรือถูกแก้) จึงไม่ติดตั้ง" }
        }
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $z = [System.IO.Compression.ZipFile]::OpenRead($zip)
        try { $names = @($z.Entries | ForEach-Object { $_.FullName }) } finally { $z.Dispose() }
        if ($names -notcontains 'LineDeck.ps1') { throw 'ไฟล์ zip ไม่มี LineDeck.ps1 อยู่ชั้นนอกสุด' }
    } catch { Set-UpdStatus "ติดตั้งไม่ได้: $($_.Exception.Message)"; Write-LineJobLog "อัปเดตไม่สำเร็จ: $($_.Exception.Message)"; return }
    $helper = Join-Path (Split-Path $zip) 'apply_update.ps1'
    $code = @'
param([int]$WaitPid, [string]$Zip, [string]$Dest)
try { Wait-Process -Id $WaitPid -Timeout 90 -ErrorAction SilentlyContinue } catch {}
Start-Sleep -Milliseconds 800
$ok = $false
for ($i = 0; $i -lt 5 -and -not $ok; $i++) {
    try { Expand-Archive -LiteralPath $Zip -DestinationPath $Dest -Force -ErrorAction Stop; $ok = $true } catch { Start-Sleep -Seconds 2 }
}
try { Get-ChildItem -LiteralPath $Dest -File | Unblock-File } catch {}
$exe = Join-Path $PSHOME 'powershell.exe'
Start-Process -FilePath $exe -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "' + (Join-Path $Dest 'LineDeck.ps1') + '"') -WorkingDirectory $Dest
'@
    [System.IO.File]::WriteAllText($helper, $code, (New-Object System.Text.UTF8Encoding($true)))
    Write-LineJobLog "อัปเดต: ติดตั้ง $($script:UpdInfo.version) แล้วเปิดโปรแกรมใหม่..."
    $exe = Join-Path $PSHOME 'powershell.exe'; if (-not (Test-Path $exe)) { $exe = 'powershell.exe' }
    Start-Process -FilePath $exe -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $helper + '" -WaitPid ' + $PID + ' -Zip "' + $zip + '" -Dest "' + $PSScriptRoot + '"') | Out-Null
    $form.Close()
}
function Confirm-Update {
    $info = $script:UpdInfo
    $notes = if ($info.notes) { "`r`n`r`nมีอะไรใหม่:`r`n$($info.notes)" } else { '' }
    if (-not [bool]$cfg.AutoUpdate -or $script:UpdManual) {
        $a = [System.Windows.Forms.MessageBox]::Show($form, "มีเวอร์ชันใหม่ $($info.version)`r`n(ตอนนี้ใช้ $($script:AppVersion))$notes`r`n`r`nอัปเดตตอนนี้เลยไหม? โปรแกรมจะปิดแล้วเปิดใหม่ให้เอง ข้อมูลไม่หาย", 'มีเวอร์ชันใหม่', 'YesNo', 'Information')
        if ($a -ne 'Yes') { Set-UpdStatus "มี $($info.version) (ยังไม่อัปเดต)"; return }
    }
    if (Test-AppBusy) {
        $script:UpdPending = $info
        Set-UpdStatus "จะอัปเดตเป็น $($info.version) เมื่องานที่รันอยู่เสร็จ"
        Write-LineJobLog "อัปเดต: มี $($info.version) จะอัปเดตเมื่องานที่รันอยู่เสร็จ"
        $script:UpdTimer.Start()
        return
    }
    Start-UpdateDownload
}
$script:UpdTimer = New-Object System.Windows.Forms.Timer
$script:UpdTimer.Interval = 700
$script:UpdTimer.Add_Tick({
    if ($script:UpdWaitInstall -and -not $script:UpdTask) {
        if (Test-AppBusy) { return }
        $script:UpdWaitInstall = $false; $script:UpdTimer.Stop(); Install-Update; return
    }
    if ($script:UpdPending -and -not $script:UpdTask) {
        if (Test-AppBusy) { return }
        $script:UpdPending = $null; Start-UpdateDownload; return
    }
    $t = $script:UpdTask
    if (-not $t) { $script:UpdTimer.Stop(); return }
    if (-not $t.IsCompleted) { return }
    $script:UpdTask = $null
    $script:UpdTimer.Stop()
    if ($t.IsFaulted -or $t.IsCanceled) {
        $err = if ($t.Exception) { $t.Exception.GetBaseException().Message } else { 'ยกเลิก' }
        Set-UpdStatus "เชื่อมต่อไม่ได้: $err"
        if ($script:UpdManual -or $script:UpdKind -eq 'download') { Write-LineJobLog "อัปเดต: เชื่อมต่อไม่ได้ ($err)" }
        return
    }
    if ($script:UpdKind -eq 'check') {
        try { $info = ([string]$t.Result).Trim().TrimStart([char]0xFEFF) | ConvertFrom-Json } catch { Set-UpdStatus 'อ่าน version.json ไม่ได้ (รูปแบบไม่ถูกต้อง)'; return }
        $script:UpdInfo = $info
        $remote = Get-VersionNum ([string]$info.version); $local = Get-VersionNum $script:AppVersion
        $script:UpdLastCheck = Get-Date
        if ($remote -le $local -or -not $info.url) {
            Show-UpdateBanner $null
            Set-UpdStatus "เป็นเวอร์ชันล่าสุดแล้ว ($($script:AppVersion)) · เช็คล่าสุด $((Get-Date).ToString('HH:mm'))"
            if ($script:UpdManual) { [void][System.Windows.Forms.MessageBox]::Show($form, "ใช้เวอร์ชันล่าสุดอยู่แล้ว ($($script:AppVersion))", 'อัปเดตโปรแกรม') }
            return
        }
        Set-UpdStatus "มีเวอร์ชันใหม่ $($info.version)"
        Show-UpdateBanner $info
        if (-not $script:UpdNotified -or $script:UpdNotified -ne [string]$info.version) { $script:UpdNotified = [string]$info.version; Write-LineJobLog "อัปเดต: มีเวอร์ชันใหม่ $($info.version) (ตอนนี้ $($script:AppVersion)) — คลิกแถบตัวหนังสือวิ่งด้านบนเพื่ออัปเดต" }
        # popup only when asked by hand; automatic checks just show the running banner (or update by themselves when that is turned on)
        if ($script:UpdManual -or [bool]$cfg.AutoUpdate) { Confirm-Update }
        return
    }
    if ($script:UpdKind -eq 'download') {
        if (Test-AppBusy) {
            Set-UpdStatus "ดาวน์โหลด $($script:UpdInfo.version) แล้ว รองานที่รันอยู่เสร็จก่อนติดตั้ง"
            Write-LineJobLog "อัปเดต: ดาวน์โหลดแล้ว จะติดตั้งเมื่องานที่รันอยู่เสร็จ"
            $script:UpdWaitInstall = $true; $script:UpdTimer.Start(); return
        }
        Install-Update
    }
})

$secUpd = New-SetSection '⟳  อัปเดตโปรแกรม' 'ทุกเครื่องเช็คเวอร์ชันจากลิงก์ version.json ตอนเปิดโปรแกรมและทุก 30 นาที'
$txtUpdUrl = New-Object System.Windows.Forms.TextBox
$txtUpdUrl.BackColor = $uiInput; $txtUpdUrl.ForeColor = $uiInk; $txtUpdUrl.Font = $font; $txtUpdUrl.BorderStyle = 'FixedSingle'; $txtUpdUrl.Width = 420
$txtUpdUrl.Text = Get-UpdateUrl
$txtUpdUrl.Add_Leave({ $v = $txtUpdUrl.Text.Trim(); if ($v -ne ([string]$cfg.UpdateUrl)) { $cfg.UpdateUrl = $v; Save-Config } })
[void](Add-SetRow $secUpd 'ลิงก์ version.json' @($txtUpdUrl) 'เช่น https://raw.githubusercontent.com/ชื่อคุณ/linedeck/main/version.json')
$chkAutoUpd = New-Object System.Windows.Forms.CheckBox
$chkAutoUpd.Text = 'อัปเดตเองเลยไม่ต้องถาม (รองานที่รันอยู่เสร็จก่อน)'; $chkAutoUpd.AutoSize = $true; $chkAutoUpd.ForeColor = $uiInk; $chkAutoUpd.Cursor = [System.Windows.Forms.Cursors]::Hand
$chkAutoUpd.Checked = [bool]$cfg.AutoUpdate
$chkAutoUpd.Add_CheckedChanged({ $cfg.AutoUpdate = $chkAutoUpd.Checked; Save-Config })
$btnUpdNow = New-Btn 'เช็คอัปเดตตอนนี้' { $cfg.UpdateUrl = $txtUpdUrl.Text.Trim(); Save-Config; Start-UpdateCheck $true } 'ghost'
[void](Add-SetRow $secUpd 'การอัปเดต' @($chkAutoUpd, $btnUpdNow) '')
# ---------- "มีอะไรใหม่" หลังอัปเดต (อ่านจาก whatsnew.json ที่มากับ zip) ----------
function Get-WhatsNew {
    try {
        $f = Join-Path $PSScriptRoot 'whatsnew.json'
        if (-not (Test-Path -LiteralPath $f)) { return @() }
        return @(Get-Content -LiteralPath $f -Raw -Encoding UTF8 | ConvertFrom-Json | Where-Object { $_ -and $_.version })
    } catch { return @() }
}
function Show-WhatsNew($entries, [string]$title = 'มีอะไรใหม่ใน LineDeck') {
    $entries = @($entries)
    if (-not $entries.Count) { [void][System.Windows.Forms.MessageBox]::Show($form, 'ยังไม่มีบันทึกการเปลี่ยนแปลง', $title); return }
    try {
        $f = New-Object System.Windows.Forms.Form
        $f.Text = $title; $f.StartPosition = 'CenterParent'
        $f.Size = New-Object System.Drawing.Size(560, 460); $f.MinimumSize = New-Object System.Drawing.Size(420, 320)
        $f.BackColor = $uiBg; $f.ForeColor = $uiInk; $f.Font = $font; $f.ShowInTaskbar = $false; $f.MinimizeBox = $false; $f.MaximizeBox = $false
        try { Set-DarkTitle $f } catch {}
        $head = New-Object System.Windows.Forms.Panel
        $head.Dock = 'Top'; $head.Height = 74; $head.BackColor = $uiBg
        $h1 = New-Object System.Windows.Forms.Label
        $h1.Text = "อัปเดตเป็น $($entries[0].version) แล้ว"; $h1.Font = $fontTitle; $h1.ForeColor = $uiInk; $h1.AutoSize = $true; $h1.Location = New-Object System.Drawing.Point(22, 14)
        $h2 = New-Object System.Windows.Forms.Label
        $h2.Text = 'นี่คือสิ่งที่เปลี่ยนไป'; $h2.ForeColor = $uiMuted; $h2.AutoSize = $true; $h2.Location = New-Object System.Drawing.Point(24, 44)
        $head.Controls.AddRange(@($h1, $h2))
        $body = New-Object System.Windows.Forms.RichTextBox
        $body.ReadOnly = $true; $body.BorderStyle = 'None'; $body.BackColor = $uiSurface; $body.ForeColor = $uiInk; $body.Font = $font; $body.Dock = 'Fill'
        $body.DetectUrls = $false
        foreach ($e in $entries) {
            $body.SelectionFont = $fontBold; $body.SelectionColor = $uiAccentText
            $body.AppendText("$($e.version)")
            $body.SelectionFont = $fontSmall; $body.SelectionColor = $uiMuted
            $body.AppendText($(if ($e.date) { "   $($e.date)" } else { '' }) + "`r`n")
            $lines = @(([string]$e.notes) -split '\s*(\||;|\r?\n)\s*' | Where-Object { $_ -and $_ -notmatch '^(\||;|\r?\n)$' })
            if (-not $lines.Count) { $lines = @('ปรับปรุงและแก้ไขเล็กน้อย') }
            $body.SelectionFont = $font; $body.SelectionColor = $uiInk
            foreach ($ln in $lines) { $body.AppendText("   •  $ln`r`n") }
            $body.AppendText("`r`n")
        }
        $body.SelectionStart = 0
        $wrap = New-Object System.Windows.Forms.Panel
        $wrap.Dock = 'Fill'; $wrap.Padding = New-Object System.Windows.Forms.Padding(22, 4, 22, 4); $wrap.BackColor = $uiBg
        $card = New-Object System.Windows.Forms.Panel
        $card.Dock = 'Fill'; $card.Padding = New-Object System.Windows.Forms.Padding(14, 12, 14, 12); $card.BackColor = $uiSurface
        $card.Controls.Add($body); $wrap.Controls.Add($card)
        $bar = New-Object System.Windows.Forms.FlowLayoutPanel
        $bar.Dock = 'Bottom'; $bar.AutoSize = $true; $bar.FlowDirection = 'RightToLeft'; $bar.Padding = New-Object System.Windows.Forms.Padding(20, 8, 20, 14); $bar.BackColor = $uiBg
        $ok = New-Btn 'เริ่มใช้งาน' { $this.FindForm().Close() } 'line'
        $bar.Controls.Add($ok)
        $f.Controls.Add($wrap); $f.Controls.Add($bar); $f.Controls.Add($head)
        $f.AcceptButton = $ok
        try { Apply-Texts $f } catch {}
        [void]$f.ShowDialog($form)
        $f.Dispose()
    } catch {}
}
function Test-ShowWhatsNew {
    $seen = [string]$cfg.LastSeenVersion
    if ($seen -eq $script:AppVersion) { return }
    $all = @(Get-WhatsNew)
    $cur = Get-VersionNum $script:AppVersion
    $old = Get-VersionNum $seen
    # everything newer than what this computer saw last, up to this version (first time: only this version)
    $show = @($all | Where-Object { $n = Get-VersionNum ([string]$_.version); $n -le $cur -and $(if ($seen) { $n -gt $old } else { $n -eq $cur }) } | Sort-Object { Get-VersionNum ([string]$_.version) } -Descending)
    $cfg.LastSeenVersion = $script:AppVersion
    Save-Config
    if ($show.Count) { Show-WhatsNew $show }
}

# ---------- ตัวหนังสือวิ่ง: มีเวอร์ชันใหม่ ----------
$updBanner = New-Object System.Windows.Forms.Panel
$updBanner.Dock = 'Fill'; $updBanner.Height = 32; $updBanner.Visible = $false
$updBanner.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 6)
$updBanner.Cursor = [System.Windows.Forms.Cursors]::Hand
$updBanner.BackColor = $uiBg
Set-DoubleBuffered $updBanner
$updBanner.Tag = @{ Text = ''; X = 0.0; W = 0 }
$updBanner.Add_Paint({
    param($s, $e)
    $g = $e.Graphics
    $g.Clear($s.BackColor)
    $g.SmoothingMode = 'AntiAlias'
    $h = $s.ClientSize.Height
    Fill-Round $g (New-Rgb 52 42 14) 0.5 0.5 ($s.Width - 1.5) ($h - 1.5) 9 (New-Rgb 120 92 30)
    # right: fixed "update" button area
    $btnTxt = 'อัปเดตเลย  ›'
    $bw = [System.Windows.Forms.TextRenderer]::MeasureText($g, $btnTxt, $fontBold, (New-Object System.Drawing.Size(999, 99)), $tfLeft).Width + 24
    $left = 38; $right = $s.Width - $bw - 8
    # badge on the left
    [System.Windows.Forms.TextRenderer]::DrawText($g, '★', $fontBold, (New-Object System.Drawing.Rectangle(12, 0, 22, $h)), (New-Rgb 227 179 65), $tfLeft)
    # scrolling text, clipped between the badge and the button
    $t = [string]$s.Tag.Text
    if (-not $s.Tag.W) { $s.Tag.W = [System.Windows.Forms.TextRenderer]::MeasureText($g, $t, $fontBold, (New-Object System.Drawing.Size(99999, 99)), $tfLeft).Width + 60 }
    $old = $g.Clip
    $g.SetClip((New-Object System.Drawing.Rectangle($left, 0, [Math]::Max(1, $right - $left), $h)))
    $x = [int]($left + $s.Tag.X)
    while ($x -lt $right) {
        [System.Windows.Forms.TextRenderer]::DrawText($g, $t, $fontBold, (New-Object System.Drawing.Rectangle($x, 0, $s.Tag.W, $h)), (New-Rgb 240 214 140), $tfLeft)
        $x += $s.Tag.W
    }
    $g.Clip = $old
    Fill-Round $g (New-Rgb 227 179 65) ([float]$right) 4.5 ([float]($bw)) ([float]($h - 9)) 7 $null
    [System.Windows.Forms.TextRenderer]::DrawText($g, $btnTxt, $fontBold, (New-Object System.Drawing.Rectangle($right, 2, $bw, ($h - 4))), (New-Rgb 30 24 8), $tfCenter)
})
$script:BannerTimer = New-Object System.Windows.Forms.Timer
$script:BannerTimer.Interval = 30
$script:BannerTimer.Add_Tick({
    if (-not $updBanner.Visible) { $script:BannerTimer.Stop(); return }
    $w = [double]$updBanner.Tag.W
    $updBanner.Tag.X = [double]$updBanner.Tag.X - 1.6
    if ($w -gt 0 -and $updBanner.Tag.X -le -$w) { $updBanner.Tag.X += $w }
    $updBanner.Invalidate()
})
$updBanner.Add_Click({ if ($script:UpdInfo) { $script:UpdManual = $true; Confirm-Update } })
$tipBanner = New-Object System.Windows.Forms.ToolTip
$tipBanner.SetToolTip($updBanner, 'คลิกเพื่ออัปเดต')
function Show-UpdateBanner($info) {
    if (-not $info) { $updBanner.Visible = $false; return }
    $notes = (@(([string]$info.notes) -split '\s*(\||;|\r?\n)\s*' | Where-Object { $_ -and $_ -notmatch '^(\||;|\r?\n)$' }) -join '  ·  ')
    $updBanner.Tag.Text = "มีเวอร์ชันใหม่ $($info.version) พร้อมให้อัปเดต (ตอนนี้ใช้ $($script:AppVersion))" + $(if ($notes) { "   —   มีอะไรใหม่: $notes" } else { '' }) + '   —   คลิกเพื่ออัปเดต'
    $updBanner.Tag.W = 0; $updBanner.Tag.X = 0.0
    $updBanner.BackColor = $uiBg
    $updBanner.Visible = $true
    $script:BannerTimer.Start()
}
$layout.Controls.Add($updBanner, 0, 1)
$lblUpdStatus = New-Label "ตอนนี้ใช้ $($script:AppVersion)"
$lblUpdStatus.ForeColor = $uiMuted
[void](Add-SetRow $secUpd 'สถานะ' @($lblUpdStatus) '')
$btnNews = New-Btn 'ดูมีอะไรใหม่' { $all = @(Get-WhatsNew | Sort-Object { Get-VersionNum ([string]$_.version) } -Descending); Show-WhatsNew $all 'ประวัติการอัปเดต LineDeck' } 'ghost'
[void](Add-SetRow $secUpd 'ประวัติ' @($btnNews) '')
# 6) rename words in the program
$secTx = New-SetSection 'Aa  เปลี่ยนคำในโปรแกรม' 'พิมพ์คำใหม่ในช่องขวา (เว้นว่าง = ใช้คำเดิม) แล้วกด "บันทึกและใช้เลย" — เปลี่ยนได้ทั้งปุ่ม แท็บ เมนู หัวตาราง หน้าต่าง และข้อความในบันทึก'
$txGrid = New-Object System.Windows.Forms.DataGridView
Set-GridTheme $txGrid
$txGrid.AllowUserToAddRows = $true
$txGrid.AllowUserToDeleteRows = $true
$txGrid.AutoSizeColumnsMode = 'Fill'
$txGrid.Height = 260
$txGrid.Width = 620
$txGrid.Margin = New-Object System.Windows.Forms.Padding(0, 4, 0, 6)
[void]$txGrid.Columns.Add('Orig', 'คำเดิม (บางส่วนของข้อความก็ได้)')
[void]$txGrid.Columns.Add('New', 'คำใหม่')
$txGrid.Columns['Orig'].FillWeight = 55
$txGrid.Columns['New'].FillWeight = 45
$txGrid.Columns['New'].DefaultCellStyle.ForeColor = $uiAccentText
function Fill-TextGrid {
    $txGrid.Rows.Clear()
    foreach ($k in $script:TextMap.Keys) { [void]$txGrid.Rows.Add($k, [string]$script:TextMap[$k]) }
}
function Get-ScreenTexts {
    $skip = @($lblStatus, $lblChecked, $lblRunHint, $txGrid)
    $out = New-Object System.Collections.Generic.List[string]
    $add = { param($s) $s = ([string]$s).Trim(); if ($s.Length -ge 2 -and $s -notmatch '^[\d\s\.,:/\-\(\)]+$' -and -not $out.Contains($s)) { $out.Add($s) } }
    $stack = New-Object System.Collections.Stack
    $stack.Push($form)
    while ($stack.Count) {
        $c = $stack.Pop()
        if ($skip -contains $c -or $c -is [System.Windows.Forms.TextBoxBase] -or $c -is [System.Windows.Forms.NumericUpDown]) { continue }
        $st = $script:TxtOrig[$c]
        if ($c -is [System.Windows.Forms.DataGridView]) {
            foreach ($col in $c.Columns) { if ($col.Visible) { $s2 = $script:TxtOrig[$col]; & $add $(if ($s2) { $s2.Orig } else { $col.HeaderText }) } }
            continue
        }
        if ($c -is [System.Windows.Forms.ComboBox]) {
            if ($c.DropDownStyle -eq 'DropDownList' -and $script:TxtSkipCombo -notcontains $c) { foreach ($x in $(if ($st) { $st.Orig } else { @($c.Items) })) { & $add $x } }
            continue
        }
        if (-not ($c -is [System.Windows.Forms.Form])) { & $add $(if ($st) { $st.Orig } else { $c.Text }) }
        foreach ($ch in $c.Controls) { $stack.Push($ch) }
    }
    foreach ($it in $ctx.Items) { if ($it -isnot [System.Windows.Forms.ToolStripSeparator]) { $s3 = $script:TxtOrig[$it]; & $add ((($(if ($s3) { $s3.Orig } else { $it.Text })) -replace '\s*\(.*$', '')) } }
    foreach ($k in $script:RunJobs.Keys) { & $add ($script:RunJobs[$k][0]); & $add ($script:RunJobs[$k][1]) }
    & $add 'LineDeck'; & $add 'ADB Manager  ·  LINE Automation'
    return , $out
}
$btnTxScan = New-Btn 'ดึงคำบนหน้าจอทั้งหมด' {
    [void]$txGrid.EndEdit()
    $have = @{}
    foreach ($r in $txGrid.Rows) { if (-not $r.IsNewRow -and $r.Cells['Orig'].Value) { $have[[string]$r.Cells['Orig'].Value] = 1 } }
    $n = 0
    foreach ($s in (Get-ScreenTexts)) { if (-not $have.ContainsKey($s)) { [void]$txGrid.Rows.Add($s, ''); $n++ } }
    $lblStatus.Text = "เพิ่มคำจากหน้าจอ $n คำ — พิมพ์คำใหม่ในช่องขวาเฉพาะคำที่อยากเปลี่ยน"
} 'ghost'
$btnTxSave = New-Btn 'บันทึกและใช้เลย' {
    [void]$txGrid.EndEdit()
    $m = [ordered]@{}
    foreach ($r in $txGrid.Rows) {
        if ($r.IsNewRow) { continue }
        $o = [string]$r.Cells['Orig'].Value; $nw = [string]$r.Cells['New'].Value
        if ($o.Trim() -and $nw.Trim() -and $o -ne $nw) { $m[$o.Trim()] = $nw.Trim() }
    }
    $script:TextMap = $m
    Update-TextKeys
    Save-TextMap
    Apply-Texts $form
    Apply-MenuTexts $ctx.Items
    $header.Invalidate()
    # keep only the rows that change something
    Fill-TextGrid
    Write-LineJobLog "บันทึกการเปลี่ยนคำแล้ว $($m.Count) คำ"
} 'primary'
$btnTxClear = New-Btn 'คืนคำเดิมทั้งหมด' {
    if ([System.Windows.Forms.MessageBox]::Show($form, 'ลบการเปลี่ยนคำทั้งหมด แล้วกลับไปใช้คำเดิม?', 'เปลี่ยนคำในโปรแกรม', 'YesNo', 'Question') -ne 'Yes') { return }
    $script:TextMap = [ordered]@{}
    Update-TextKeys
    Save-TextMap
    Apply-Texts $form
    Apply-MenuTexts $ctx.Items
    $header.Invalidate()
    Fill-TextGrid
} 'ghost'
$txBar = New-Flow
$txBar.Controls.AddRange(@($btnTxSave, $btnTxScan, $btnTxClear))
$btnTxSave.Margin = New-Object System.Windows.Forms.Padding(0)
$txHint = New-Label ("ไฟล์เก็บคำ: " + $script:TextsPath + '   (แก้ไฟล์นี้เองก็ได้ รูปแบบ  "คำเดิม": "คำใหม่")')
$txHint.Font = $fontSmall; $txHint.ForeColor = $uiFaint
$txHint.Margin = New-Object System.Windows.Forms.Padding(0, 6, 0, 0)
Add-SecCtl $secTx $txGrid
Add-SecCtl $secTx $txBar
Add-SecCtl $secTx $txHint
Fill-TextGrid
# cards follow the page width
$setFlow.Add_Resize({
    $w = [Math]::Max(500, $this.ClientSize.Width - 6)
    foreach ($c in $this.Controls) { $c.MinimumSize = New-Object System.Drawing.Size($w, 0); $c.MaximumSize = New-Object System.Drawing.Size($w, 0) }
    try { $txGrid.Width = [Math]::Max(400, $w - 40) } catch {}
})
$tabSettings.Controls.Add($setFlow)
Update-ModeHint
$tabs.Controls.AddRange(@($tabLog, $tabSettings, $tabConfig, $tabList))
$contentCard.Controls.Add($tabs, 0, 1)
$layout.Controls.Add($contentCard, 0, 2)
function Show-Page([string]$name) {
    foreach ($k in @($script:navBtns.Keys)) {
        $on = ($k -eq $name)
        $script:pages[$k].Visible = $on
        Set-BtnKind $script:navBtns[$k] $(if ($on) { 'tabOn' } else { 'tab' })
    }
    $listActions.Visible = $true   # counters show on every page
    Set-BtnKind $btnToggleSettings $(if ($name -eq 'settings') { 'tabOn' } else { 'ghost' })
}
Show-Page 'list'


# --- Editable config.json from user's Adb-LineAddFriend.ps1 ---
$script:LineConfigPath = Join-Path $PSScriptRoot 'config.json'
$script:LineConfigMirror = Join-Path $CfgDir 'line_config.json'
function Save-LineConfigText([string]$json) {
    Write-SafeText $script:LineConfigPath $json
    try { Write-SafeText $script:LineConfigMirror $json } catch {}
}
# ชุด ID ไม่หาย: ถ้า config.json ในโฟลเดอร์โปรแกรมหายไป (เช่น แตก zip ใหม่) ให้กู้จากสำรองใน %APPDATA% หรือใช้ไฟล์ตัวอย่าง
try {
    if (-not (Test-Path -LiteralPath $script:LineConfigPath)) {
        $src = $null
        foreach ($c in @($script:LineConfigMirror, "$($script:LineConfigMirror).bak", "$($script:LineConfigPath).bak", (Join-Path $PSScriptRoot 'config.default.json'))) {
            if (Test-Path -LiteralPath $c) { $src = $c; break }
        }
        if ($src) { Copy-Item -LiteralPath $src -Destination $script:LineConfigPath -Force }
    } elseif (-not (Test-Path -LiteralPath $script:LineConfigMirror)) {
        Copy-Item -LiteralPath $script:LineConfigPath -Destination $script:LineConfigMirror -Force
    }
} catch {}
$configLayout = New-Object System.Windows.Forms.TableLayoutPanel
$configLayout.Dock = 'Fill'
$configLayout.ColumnCount = 1
$configLayout.RowCount = 3
$configLayout.Padding = New-Object System.Windows.Forms.Padding(0)
[void]$configLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100)))
[void]$configLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('AutoSize')))
[void]$configLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent', 100)))
[void]$configLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('AutoSize')))
$lblCfg = New-Object System.Windows.Forms.Label
$lblCfg.Text = 'แถวละ 1 ชุด  ·  10 ID ต่อชุด  ·  สูงสุด 10 ชุด  ·  ใช้ชุดบนสุดก่อน แล้วย้ายไปท้ายอัตโนมัติ'
$lblCfg.AutoSize = $true
$lblCfg.ForeColor = $uiMuted
$lblCfg.Margin = New-Object System.Windows.Forms.Padding(2, 0, 0, 10)
$cfgGrid = New-Object System.Windows.Forms.DataGridView
$cfgGrid.Dock = 'Fill'
$cfgGrid.AllowUserToAddRows = $false
$cfgGrid.AllowUserToDeleteRows = $false
$cfgGrid.AutoSizeColumnsMode = 'Fill'
$script:CfgMaxSets = [int]::MaxValue   # ไม่จำกัดจำนวนชุด
$script:CfgMaxIds = 10
$cfgGrid.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 12)
Set-GridTheme $cfgGrid
$cfgGrid.SelectionMode = 'CellSelect'
$ci = $cfgGrid.Columns.Add('SetNo', 'ชุด')
$cfgGrid.Columns[$ci].ReadOnly = $true
$cfgGrid.Columns[$ci].AutoSizeMode = 'None'
$cfgGrid.Columns[$ci].Width = 52
$cfgGrid.Columns[$ci].DefaultCellStyle.ForeColor = $uiMuted
$cfgGrid.Columns[$ci].DefaultCellStyle.Alignment = 'MiddleCenter'
$cfgGrid.Columns[$ci].HeaderCell.Style.Alignment = 'MiddleCenter'
$cfgGrid.Columns[$ci].SortMode = 'NotSortable'
for ($n = 1; $n -le $script:CfgMaxIds; $n++) {
    $ci = $cfgGrid.Columns.Add("line_id_$n", (Get-IdColLabel $n))
    $cfgGrid.Columns[$ci].MinimumWidth = 110
    $cfgGrid.Columns[$ci].SortMode = 'NotSortable'
}
$ci = $cfgGrid.Columns.Add('groups', 'กลุ่ม (Line)')
$cfgGrid.Columns[$ci].MinimumWidth = 90; $cfgGrid.Columns[$ci].FillWeight = 45; $cfgGrid.Columns[$ci].SortMode = 'NotSortable'
$cfgGrid.Columns[$ci].DefaultCellStyle.Alignment = 'MiddleCenter'; $cfgGrid.Columns[$ci].HeaderCell.Style.Alignment = 'MiddleCenter'
$cfgGrid.Columns[$ci].ToolTipText = 'จำนวนกลุ่มของบัญชีในช่อง Line (กรอกเอง แล้วโปรแกรมจะ +1 ทุกครั้งที่ชุดนี้ถูกใช้สำเร็จ)'
$cfgGrid.Add_CellValidating({
    param($s, $e)
    if ($s.Columns[$e.ColumnIndex].Name -ne 'groups') { return }
    $t = ([string]$e.FormattedValue).Trim()
    $n = 0
    if ($t -and -not [int]::TryParse($t, [ref]$n)) { $e.Cancel = $true; [System.Media.SystemSounds]::Beep.Play() }
})
$cfgGrid.ShowCellToolTips = $true
$cfgGrid.Columns['SetNo'].ToolTipText = 'ลำดับชุด: ชุดบนสุดที่ว่างจะถูกใช้ก่อน ใช้แล้วย้ายไปท้ายรายการ (หมุนเวียน)'
$cfgGrid.Columns['line_id_1'].ToolTipText = "Line@: ใส่ ID ของ LINE OA (เช่น @shop123)`r`nใช้เมื่อเลือก 'ทุกช่อง' หรือ 'เฉพาะ Line@' · ชื่อจริงจะขึ้นในวงเล็บหลังค้นหาแล้ว"
$cfgGrid.Columns['line_id_2'].ToolTipText = "Line: ใส่ ID ของบัญชี LINE`r`nใช้เมื่อเลือก 'ทุกช่อง' หรือ 'เฉพาะ Line' · ชื่อจริงจะขึ้นในวงเล็บหลังค้นหาแล้ว"
for ($q = 3; $q -le $script:CfgMaxIds; $q++) { $cfgGrid.Columns["line_id_$q"].ToolTipText = "ID ${q}: ช่องเสริม ใช้เมื่อเลือก 'ทุกช่อง' หรือ 'เฉพาะ ID $q'" }
$script:GroupsTip = "กลุ่ม (Line): กรอกจำนวนกลุ่มที่บัญชีในช่อง Line มีอยู่ตอนนี้ เป็นตัวเลข (เช่น 12) แล้วกด 'บันทึก config.json'`r`nทุกครั้งที่ LINE Script ใช้ชุดนี้สำเร็จ (ตั้ง 'ทุกช่อง' หรือ 'เฉพาะ Line') ระบบจะ +1 ให้เอง`r`nเว้นว่างได้ = เริ่มนับจาก 0"
$cfgGrid.Columns['groups'].ToolTipText = $script:GroupsTip
$cfgGrid.Add_CellToolTipTextNeeded({
    param($s, $e)
    if ($e.RowIndex -lt 0 -or $e.ColumnIndex -lt 0) { return }
    $cn = $s.Columns[$e.ColumnIndex].Name
    if ($cn -eq 'groups') { $e.ToolTipText = $script:GroupsTip }
    elseif ($cn -like 'line_id_*' -and -not ([string]$s.Rows[$e.RowIndex].Cells[$e.ColumnIndex].Value).Trim()) { $e.ToolTipText = $s.Columns[$e.ColumnIndex].ToolTipText }
})
$cfgGrid.Add_CellValueChanged({ $script:CfgDirty = $true })
# ช่อง ID ที่แสดง: ปกติ ID 1-2 (กด "+ เพิ่มช่อง ID" เพื่อเพิ่ม) - ช่องที่มีข้อมูลอยู่จะแสดงเสมอ
function Get-IdColCount {
    $used = 0
    foreach ($r in $cfgGrid.Rows) {
        if ($r.IsNewRow) { continue }
        for ($c = $script:CfgMaxIds; $c -ge 1; $c--) { if (([string]$r.Cells["line_id_$c"].Value).Trim()) { if ($c -gt $used) { $used = $c }; break } }
    }
    return [Math]::Max(1, [Math]::Min($script:CfgMaxIds, [Math]::Max([int]$cfg.IdCols, $used)))
}
$script:RebuildUseId = $false
function Update-IdCols {
    $n = Get-IdColCount
    for ($c = 1; $c -le $script:CfgMaxIds; $c++) { $cfgGrid.Columns["line_id_$c"].Visible = ($c -le $n) }
    try { $btnIdColAdd.Enabled = ($n -lt $script:CfgMaxIds); $btnIdColDel.Enabled = ($n -gt 1) } catch {}
    # "ใช้ ID" choices follow the number of ID columns
    $want = 1 + $n
    if ($comboUseId.Items.Count -ne $want) {
        $script:RebuildUseId = $true
        $comboUseId.Items.Clear()
        [void]$comboUseId.Items.Add('ทุกช่อง')
        for ($k = 1; $k -le $n; $k++) { [void]$comboUseId.Items.Add("เฉพาะ $(Get-IdColLabel $k)") }
        $comboUseId.SelectedIndex = [Math]::Max(0, [Math]::Min($n, [int]$cfg.UseIdCol))
        $script:RebuildUseId = $false
        if ($comboUseId.SelectedIndex -ne [int]$cfg.UseIdCol) { $cfg.UseIdCol = [int]$comboUseId.SelectedIndex; Save-Config }
    }
}
$cfgGrid.Add_RowsRemoved({ $script:CfgDirty = $true })
$cfgGrid.Add_CellFormatting({
    param($s, $e)
    if ($e.ColumnIndex -eq 0 -and $e.RowIndex -ge 0) { $e.Value = [string]($e.RowIndex + 1); $e.FormattingApplied = $true; return }
    if ($e.ColumnIndex -ge 1 -and $e.RowIndex -ge 0 -and $s.Columns[$e.ColumnIndex].Name -like 'line_id_*' -and -not $s.Rows[$e.RowIndex].Cells[$e.ColumnIndex].IsInEditMode) {
        $v = ([string]$e.Value).Trim()
        if ($v) {
            $nm = Get-IdNameText $v
            if ($nm) {
                $e.Value = "$v  ($nm)"; $e.FormattingApplied = $true
                if ($nm -eq 'ไม่พบบัญชี') { $e.CellStyle.ForeColor = (New-Rgb 255 110 110) }
            }
        }
    }
})
function Update-CfgCount {
    $n = $cfgGrid.Rows.Count
    $btnCfgAdd.Enabled = $true
    $btnCfgDel.Enabled = ($n -gt 0)
    $lblCfgCount.Text = "$n ชุด"
    $cfgGrid.Invalidate()
}
$cfgGrid.RowTemplate.Height = 32
$lblMode = New-Label 'ค้นหาด้วย'
$comboMode = New-Object System.Windows.Forms.ComboBox
$comboMode.DropDownStyle = 'DropDownList'
[void]$comboMode.Items.Add('ID')
[void]$comboMode.Items.Add('Phone')
$comboMode.SelectedIndex = 0
$comboMode.Width = 140
$comboMode.Anchor = 'Left'
$comboMode.FlatStyle = 'Flat'
$comboMode.Font = $font
$comboMode.BackColor = $uiInput
$comboMode.ForeColor = $uiInk
$comboMode.Cursor = [System.Windows.Forms.Cursors]::Hand
$cfgButtons = New-Table @('Auto', 'Auto', 'Fill', 'Auto', 'Auto', 'Auto', 'Auto', 'Auto')
$lblCfgCount = New-Label '0 ชุด'
$lblCfgCount.Font = $fontBold
$lblCfgCount.ForeColor = $uiAccentText
$lblCfgCount.Margin = New-Object System.Windows.Forms.Padding(0, 0, 4, 0)
$btnCfgAdd = New-Btn '+  เพิ่มชุด' {
    $n = $cfgGrid.Rows.Add()
    $cfgGrid.CurrentCell = $cfgGrid.Rows[$n].Cells[1]
    [void]$cfgGrid.BeginEdit($true)
    Update-CfgCount
} 'ghost'
$btnCfgDel = New-Btn 'ลบชุดที่เลือก' {
    $rows = @($cfgGrid.SelectedCells | ForEach-Object { $_.RowIndex } | Sort-Object -Unique -Descending)
    if (-not $rows.Count -and $cfgGrid.CurrentCell) { $rows = @($cfgGrid.CurrentCell.RowIndex) }
    if (-not $rows.Count) { return }
    [void]$cfgGrid.EndEdit()
    foreach ($r in $rows) { $cfgGrid.Rows.RemoveAt($r) }
    Update-CfgCount
} 'danger'
$btnCfgSave = New-Btn 'บันทึก config.json' $null 'primary'
$btnCfgLoad = New-Btn 'โหลดใหม่' $null 'ghost'
$cfgButtons.Controls.Add($lblMode, 0, 0)
$cfgButtons.Controls.Add($comboMode, 1, 0)
$cfgButtons.Controls.Add($lblCfgCount, 3, 0)
$cfgButtons.Controls.Add($btnCfgAdd, 4, 0)
$cfgButtons.Controls.Add($btnCfgDel, 5, 0)
$cfgButtons.Controls.Add($btnCfgLoad, 6, 0)
$cfgButtons.Controls.Add($btnCfgSave, 7, 0)
$configLayout.Controls.Add($lblCfg, 0, 0)
$configLayout.Controls.Add($cfgGrid, 0, 1)
$cfgFlow = New-Object System.Windows.Forms.FlowLayoutPanel
$cfgFlow.Dock = 'Fill'
$cfgFlow.AutoSize = $true
$cfgFlow.AutoSizeMode = 'GrowAndShrink'
$cfgFlow.WrapContents = $true
$cfgFlow.Margin = New-Object System.Windows.Forms.Padding(0)
$lblMode.Margin = New-Object System.Windows.Forms.Padding(0, 9, 8, 0)
$comboMode.Width = 110
$comboMode.Margin = New-Object System.Windows.Forms.Padding(0, 5, 0, 0)
$lblCfgCount.Margin = New-Object System.Windows.Forms.Padding(0, 9, 4, 0)
$btnIdNames = New-Btn 'ดึงชื่อจริงของ ID' { Start-IdNameCheck } 'ghost'
$btnIdColAdd = New-Btn '+  เพิ่มช่อง ID' {
    $cfg.IdCols = [Math]::Min($script:CfgMaxIds, (Get-IdColCount) + 1); Save-Config; Update-IdCols
} 'ghost'
$btnIdColDel = New-Btn '−  ลดช่อง ID' {
    $n = Get-IdColCount
    $hasData = @($cfgGrid.Rows | Where-Object { -not $_.IsNewRow -and ([string]$_.Cells["line_id_$n"].Value).Trim() }).Count
    if ($hasData) { [void][System.Windows.Forms.MessageBox]::Show($form, "ช่อง ID $n ยังมีข้อมูลอยู่ $hasData ชุด กรุณาลบข้อมูลในช่องนี้ก่อน", 'ลดช่อง ID'); return }
    $cfg.IdCols = [Math]::Max(1, $n - 1); Save-Config; Update-IdCols
} 'ghost'
$cfgFlow.Controls.AddRange(@(
    (New-Group @($lblMode, $comboMode)),
    (New-Group @($lblCfgCount, $btnCfgAdd, $btnCfgDel)),
    (New-Group @($btnIdColAdd, $btnIdColDel)),
    (New-Group @($btnIdNames)),
    (New-Group @($btnCfgLoad, $btnCfgSave))))
$cfgButtons = $cfgFlow
$configLayout.Controls.Add($cfgButtons, 0, 2)
$tabConfig.Controls.Add($configLayout)
# --- ชื่อจริงของ ID (ชื่อที่ LINE แสดงตอนค้นหา ID) : เก็บไว้แสดงในวงเล็บในหน้า "ชุด ID" ---
$script:IdNamePath = Join-Path $CfgDir 'id_names.json'
$script:IdNames = @{}
try { $jn = Read-JsonSafe $script:IdNamePath; if ($jn) { foreach ($pr in $jn.PSObject.Properties) { $script:IdNames[$pr.Name] = $pr.Value } } } catch {}
function Get-IdKey([string]$id) { return ([string]$id).Trim().ToLowerInvariant() }
function Set-IdName([string]$id, [string]$name, [string]$state = 'ok') {
    $k = Get-IdKey $id
    if (-not $k) { return }
    $script:IdNames[$k] = [pscustomobject]@{ name = ([string]$name).Trim(); state = $state; time = (Get-Date).ToString('yyyy-MM-dd HH:mm') }
}
function Save-IdNames {
    try { Write-SafeText $script:IdNamePath (ConvertTo-Json -InputObject $script:IdNames -Depth 4) } catch {}
    try { $cfgGrid.Invalidate() } catch {}
}
# rounds of a LINE run / check -> remember each ID's real name
function Update-IdNamesFromRounds($rounds) {
    $n = 0
    foreach ($rd in @($rounds)) {
        if ($null -eq $rd -or -not $rd.text) { continue }
        if ($rd.name) { Set-IdName ([string]$rd.text) ([string]$rd.name) 'ok'; $n++ }
        elseif ($rd.status -eq 'notfound') { Set-IdName ([string]$rd.text) '' 'notfound'; $n++ }
    }
    if ($n) { Save-IdNames }
    return $n
}
function Get-IdNameText([string]$id) {
    $v = $script:IdNames[(Get-IdKey $id)]
    if (-not $v) { return '' }
    if ($v.state -eq 'notfound') { return 'ไม่พบบัญชี' }
    return [string]$v.name
}
# ปุ่ม "ดึงชื่อจริงของ ID": ค้นหาแต่ละ ID แล้วอ่านชื่อ (ไม่กดเพิ่มเพื่อน) แบ่ง ID ไปทำในเครื่องที่ติ๊กไว้
function Start-IdNameCheck {
    [void]$cfgGrid.EndEdit()
    $ids = @()
    foreach ($r in $cfgGrid.Rows) {
        if ($r.IsNewRow) { continue }
        for ($c = 1; $c -le $script:CfgMaxIds; $c++) { $v = ([string]$r.Cells[$c].Value).Trim(); if ($v -and $ids -notcontains $v) { $ids += $v } }
    }
    if (-not $ids.Count) { [void][System.Windows.Forms.MessageBox]::Show($form, 'ยังไม่มี ID ในตาราง', 'ดึงชื่อจริงของ ID'); return }
    $onlyNew = ([System.Windows.Forms.MessageBox]::Show($form, "มี ID ทั้งหมด $($ids.Count) ตัว`r`n`r`nYes = ดึงเฉพาะ ID ที่ยังไม่มีชื่อ`r`nNo = ดึงใหม่ทั้งหมด", 'ดึงชื่อจริงของ ID', 'YesNoCancel', 'Question'))
    if ($onlyNew -eq 'Cancel') { return }
    if ($onlyNew -eq 'Yes') { $ids = @($ids | Where-Object { -not $script:IdNames.ContainsKey((Get-IdKey $_)) }) }
    if (-not $ids.Count) { [void][System.Windows.Forms.MessageBox]::Show($form, 'ทุก ID มีชื่อแล้ว', 'ดึงชื่อจริงของ ID'); return }
    $lds = @(Get-CheckedIdx | Where-Object { (Test-RowReady $_) -and -not (Test-RowBusy $_) })
    if (-not $lds.Count) { [void][System.Windows.Forms.MessageBox]::Show($form, 'กรุณาติ๊ก ✔ LD ที่เปิดอยู่และว่างอย่างน้อย 1 เครื่องในหน้า "รายการเครื่อง" (ใช้ค้นหา ID โดยไม่กดเพิ่มเพื่อน)', 'ดึงชื่อจริงของ ID'); return }
    $scriptPath = Join-Path $PSScriptRoot 'Adb-LineAddFriend.ps1'
    $adbPath = [string]$Sync.Adb
    if (-not (Test-Path -LiteralPath $scriptPath) -or -not $adbPath -or -not (Test-Path -LiteralPath $adbPath)) { [void][System.Windows.Forms.MessageBox]::Show($form, 'ไม่พบ Adb-LineAddFriend.ps1 หรือ adb.exe', 'ดึงชื่อจริงของ ID'); return }
    $outDir = Join-Path $env:APPDATA 'LDAdbConnector\IdNames'
    [void][System.IO.Directory]::CreateDirectory($outDir)
    $exe = Join-Path $PSHOME 'powershell.exe'
    if (-not (Test-Path $exe)) { $exe = 'powershell.exe' }
    $searchBy = if ([string]$comboMode.SelectedItem -eq 'Phone') { 'Phone' } else { 'ID' }
    # spread the IDs over the ticked LDs
    $chunks = @{}
    for ($i = 0; $i -lt $ids.Count; $i++) { $ld = $lds[$i % $lds.Count]; if (-not $chunks.ContainsKey($ld)) { $chunks[$ld] = @() }; $chunks[$ld] += $ids[$i] }
    $started = 0
    foreach ($ld in @($chunks.Keys | Sort-Object)) {
        $serial = Get-LdSerial $ld
        if (-not $serial) { Write-LineJobLog "LD #$ld | ดึงชื่อ ID ไม่ได้: ไม่พบ ADB Serial"; continue }
        $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss_fff')
        $conf = Join-Path $outDir "LD${ld}_${stamp}_ids.json"
        [System.IO.File]::WriteAllText($conf, (ConvertTo-Json -InputObject ([ordered]@{ texts = @($chunks[$ld]); searchBy = $searchBy }) -Depth 3), (New-Object System.Text.UTF8Encoding($false)))
        $stdout = Join-Path $outDir "LD${ld}_${stamp}.json"
        $stderr = Join-Path $outDir "LD${ld}_${stamp}.err.txt"
        $argLine = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $scriptPath + '"'), '-Adb', ('"' + $adbPath + '"'),
            '-Serial', ('"' + $serial + '"'), '-ConfigPath', ('"' + $conf + '"'), '-LaunchLine', '-CheckOnly') -join ' '
        try {
            $p = Start-Process -FilePath $exe -ArgumentList $argLine -WorkingDirectory $PSScriptRoot -PassThru -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr
        } catch { Write-LineJobLog "LD #$ld | เริ่มดึงชื่อ ID ไม่ได้: $($_.Exception.Message)"; continue }
        [void]$script:InfoJobs.Add([pscustomobject]@{ Kind = 'check'; Detail = "ดึงชื่อจริง $(@($chunks[$ld]).Count) ID"; Index = $ld; Process = $p; Output = $stdout; ErrorFile = $stderr; Started = (Get-Date); Timeout = (90 + 25 * @($chunks[$ld]).Count) })
        Write-LineJobLog "LD #$ld | เริ่มดึงชื่อจริงของ ID $(@($chunks[$ld]).Count) ตัว (ค้นหาอย่างเดียว ไม่กดเพิ่มเพื่อน): $(@($chunks[$ld]) -join ', ')"
        $script:LineMainStatus[$ld] = 'กำลังดึงชื่อจริงของ ID'
        $started++
    }
    if ($started) { $script:InfoJobTimer.Start() }
    try { Update-Status } catch {}
}
# ช่อง ID ตามตำแหน่งจริง (ช่องว่างคงไว้): ID 1 ว่าง + ID 2 มีข้อมูล -> @('', 'xxx')
function Get-PairSlots($pair) {
    $ids = @()
    if ($null -ne $pair.line_ids) { $ids = @($pair.line_ids) }
    else { $ids = @($pair.first_line_id, $pair.second_line_id) }
    $out = @($ids | Select-Object -First 10 | ForEach-Object { ([string]$_).Trim() })
    while ($out.Count -and -not $out[$out.Count - 1]) { $out = @($out | Select-Object -First ($out.Count - 1)) }
    return $out   # callers wrap with @()
}
function Get-PairIds($pair) {
    $ids = @()
    if ($null -ne $pair.line_ids) { $ids = @($pair.line_ids) }
    else { $ids = @($pair.first_line_id, $pair.second_line_id) }
    return @($ids | ForEach-Object { ([string]$_).Trim() } | Where-Object { $_ } | Select-Object -First 10)
}
function Get-LinePairs {
    [void]$cfgGrid.EndEdit()
    $pairs = @()
    foreach ($r in $cfgGrid.Rows) {
        if ($r.IsNewRow) { continue }
        $slots = @()
        for ($c = 1; $c -le $script:CfgMaxIds; $c++) { $slots += ([string]$r.Cells[$c].Value).Trim() }
        while ($slots.Count -and -not $slots[$slots.Count - 1]) { $slots = @($slots | Select-Object -First ($slots.Count - 1)) }
        if (-not $slots.Count) { continue }
        $second = if ($slots.Count -gt 1) { $slots[1] } else { '' }
        $pp = [ordered]@{ first_line_id = $slots[0]; second_line_id = $second; line_ids = @($slots) }
        $gv = ([string]$r.Cells['groups'].Value).Trim(); $gn = 0
        if ($gv -and [int]::TryParse($gv, [ref]$gn)) { $pp.groups = $gn }
        $pairs += $pp
    }
    return $pairs
}
function Load-LineConfig {
    try {
        $cfgGrid.Rows.Clear()
        if (Test-Path -LiteralPath $script:LineConfigPath) {
            $j = Get-Content -LiteralPath $script:LineConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
            $sets = @()
            if ($j.pairs) {
                $grpVals = @()
                foreach ($p in @($j.pairs)) { $sets += ,@(Get-PairSlots $p); $grpVals += $(if ($null -ne $p.groups -and "$($p.groups)" -ne '') { [string]$p.groups } else { '' }) }
            } elseif ($j.texts) {
                $v = @($j.texts)
                for ($n=0; $n+1 -lt $v.Count; $n+=2) { $sets += ,@([string]$v[$n],[string]$v[$n+1]) }
            }
            $si = 0
            foreach ($ids in $sets) {
                $n = $cfgGrid.Rows.Add()
                for ($c = 0; $c -lt @($ids).Count -and $c -lt $script:CfgMaxIds; $c++) { $cfgGrid.Rows[$n].Cells[$c + 1].Value = [string]@($ids)[$c] }
                if ($grpVals -and $si -lt @($grpVals).Count) { $cfgGrid.Rows[$n].Cells['groups'].Value = [string]@($grpVals)[$si] }
                $si++
            }
            $comboMode.SelectedItem = if ($j.searchBy -eq 'Phone') { 'Phone' } else { 'ID' }
        }
    } catch { [void][System.Windows.Forms.MessageBox]::Show("อ่าน config ไม่สำเร็จ: $($_.Exception.Message)") }
    try { Update-IdCols } catch {}
    Update-CfgCount
    $script:CfgDirty = $false
}
function Save-LineConfig {
    try {
        $pairs = @(Get-LinePairs)
        if (-not $pairs.Count) { throw 'กรุณากรอกอย่างน้อยหนึ่งชุด' }
        $data = [ordered]@{pairs=@($pairs);searchBy=[string]$comboMode.SelectedItem}
        $json = ConvertTo-Json -InputObject $data -Depth 5
        Save-LineConfigText $json
        $script:CfgDirty = $false
        $lblStatus.Text = "บันทึก LINE config แล้ว ($($pairs.Count) ชุด)"
        [void][System.Windows.Forms.MessageBox]::Show('บันทึกเรียบร้อย','LINE Config')
    } catch { [void][System.Windows.Forms.MessageBox]::Show("บันทึกไม่สำเร็จ: $($_.Exception.Message)") }
}
$btnCfgSave.Add_Click({ Save-LineConfig })
$btnCfgLoad.Add_Click({ Load-LineConfig })
Load-LineConfig

# --- Log ---
$logWrap = New-Object System.Windows.Forms.Panel
$logWrap.Dock = 'Fill'
$logWrap.BackColor = $uiLogBg
$logWrap.Padding = New-Object System.Windows.Forms.Padding(14, 12, 6, 12)
Set-DoubleBuffered $logWrap
$logWrap.Add_Paint({
    param($s, $e)
    $g = $e.Graphics
    $g.Clear($s.Parent.BackColor)
    $g.SmoothingMode = 'AntiAlias'
    Fill-Round $g $uiLogBg 0.5 0.5 ($s.Width - 1.5) ($s.Height - 1.5) 10 $uiGrid
})
$logWrap.Add_Resize({ $this.Invalidate() })
$txtLog = New-Object System.Windows.Forms.TextBox
$txtLog.Multiline = $true
$txtLog.ReadOnly = $true
$txtLog.ScrollBars = 'Vertical'
$txtLog.Dock = 'Fill'
$txtLog.BorderStyle = 'None'
$txtLog.BackColor = $uiLogBg
$txtLog.ForeColor = New-Rgb 201 209 217
$txtLog.Font = New-Object System.Drawing.Font('Tahoma', 9.5)
$logWrap.Controls.Add($txtLog)
$tabLog.Controls.Add($logWrap)



# --- แถบสถานะ ---
$statusBar = New-Object System.Windows.Forms.Panel
$statusBar.Dock = 'Fill'
$statusBar.Height = 24
$statusBar.BackColor = $uiBg
$statusBar.Margin = New-Object System.Windows.Forms.Padding(0)
$statusBar.Padding = New-Object System.Windows.Forms.Padding(18, 0, 0, 0)
Set-DoubleBuffered $statusBar
$statusBar.Add_Paint({
    param($s, $e)
    $g = $e.Graphics
    $g.SmoothingMode = 'AntiAlias'
    $c = if (-not $Sync.PathOk) { $uiBad } elseif ([string]$Sync.Summary -like '*หยุด*') { $uiWarn } else { $uiOk }
    $br = New-Object System.Drawing.SolidBrush($c)
    $g.FillEllipse($br, [float]4, [float]($s.Height / 2 - 4), [float]8, [float]8); $br.Dispose()
})
$lblStatus = New-Object System.Windows.Forms.Label
$lblStatus.AutoSize = $false
$lblStatus.Dock = 'Fill'
$lblStatus.TextAlign = 'MiddleLeft'
$lblStatus.AutoEllipsis = $true
$lblStatus.ForeColor = $uiMuted
$lblStatus.Font = $font
$statusBar.Controls.Add($lblStatus)
$layout.Controls.Add($statusBar, 0, 3)

function Update-HeaderStats {
    $total = @($grid.Rows | Where-Object { $null -ne $_.Tag }).Count
    $openCnt = @($script:RowRunning.Keys | Where-Object { [bool]$script:RowRunning[$_] }).Count
    $chk = 0
    foreach ($r in $grid.Rows) { if ([string]$r.Cells['Chk'].Value -eq 'True') { $chk++ } }
    $run = $script:LineJobs.Count + $script:InfoJobs.Count
    $q = 0
    if ($script:LineStartQueue) { $q = $script:LineStartQueue.Count }
    $auto = $chkAuto.Checked
    $lblChecked.Text = "ติ๊กแล้ว $chk/$total"
    $sig = "$total|$openCnt|$chk|$run|$q|$auto|$($Sync.PathOk)|$($Sync.Summary)"
    if ($sig -eq $script:hdrSig) { return }
    $script:hdrSig = $sig
    $statusBar.Invalidate()
}
function Show-Main { $form.Show(); $form.WindowState = 'Normal'; $form.Activate() }
$form.ShowInTaskbar = $true

# --- ตั้งค่าโฟลเดอร์ ---
function Apply-Dir {
    $dir = $txtDir.Text.Trim().Trim('"').TrimEnd('\')
    $adb = Join-Path $dir 'adb.exe'
    $lc = Join-Path $dir 'ldconsole.exe'
    if (-not (Test-Path $lc)) { $lc = Join-Path $dir 'dnconsole.exe' }
    $ok = ($dir -ne '') -and (Test-Path $adb) -and (Test-Path $lc)
    $Sync.LdDir = $dir
    $Sync.Adb = $adb
    $Sync.LdConsole = $lc
    $Sync.PathChanged = $true
    $Sync.PathOk = $ok
    $txtDir.BackColor = if ($ok) { $uiInput } else { $uiInputBad }
    try { $statusBar.Invalidate() } catch {}
    if ($ok) { $cfg.LdDir = $dir; Save-Config }
}
$txtDir.Add_Leave({ Apply-Dir })
$txtDir.Add_KeyDown({ if ($_.KeyCode -eq 'Enter') { Apply-Dir; $_.SuppressKeyPress = $true } })

# --- อัปเดตตาราง ---
$script:rowMap = @{}
$colOk   = [System.Drawing.Color]::FromArgb(212, 247, 212)
$colBad  = [System.Drawing.Color]::FromArgb(255, 224, 224)
function Set-Cell($row, [string]$col, $val) {
    if ("$($row.Cells[$col].Value)" -ne "$val") { $row.Cells[$col].Value = $val }
}
$script:RowRunning = @{}
$script:RowReady = @{}
# --- เวลาที่สร้าง LD: วันที่สร้างไฟล์ตั้งค่า vms\config\leidianN.config (หรือโฟลเดอร์ vms\leidianN) ---
$script:LdCreated = @{}
$script:LdCreatedAt = @{}
$script:LdCreatedDir = ''
function Get-LdCreated([int]$idx) {
    $dir = [string]$Sync.LdDir
    if ($dir -ne $script:LdCreatedDir) { $script:LdCreated = @{}; $script:LdCreatedDir = $dir }
    if ($script:LdCreated.ContainsKey($idx) -and ((Get-Date) - $script:LdCreatedAt[$idx]).TotalSeconds -lt 20) { return $script:LdCreated[$idx] }
    $when = $null
    if ($dir) {
        foreach ($cand in @((Join-Path $dir "vms\leidian$idx"), (Join-Path $dir "vms\config\leidian$idx.config"))) {
            try {
                if (Test-Path -LiteralPath $cand) { $when = (Get-Item -LiteralPath $cand -Force).CreationTime; break }
            } catch {}
        }
    }
    $script:LdCreated[$idx] = $when
    $script:LdCreatedAt[$idx] = Get-Date
    return $when
}
$script:SortDirty = $true
function Get-SortKey($row) {
    $tail = '{0:D6}' -f [int]$row.Tag
    if ([int]$cfg.LdSort -eq 4) { $n = ([string]$row.Cells['LineName'].Value).Trim().ToLowerInvariant(); return $(if ($n) { "0$n" } else { '1' }) + "|$tail" }
    return $tail
}
function Update-Sort([switch]$Force) {
    if ($grid.IsCurrentCellInEditMode) { return }
    foreach ($row in $grid.Rows) {
        if ($null -eq $row.Tag) { continue }
        $k = Get-SortKey $row
        if ([string]$row.Cells['SortKey'].Value -ne $k) { $row.Cells['SortKey'].Value = $k; $script:SortDirty = $true }
    }
    if ($script:SortDirty -or $Force) {
        try { $grid.Sort($grid.Columns['SortKey'], [System.ComponentModel.ListSortDirection]::Ascending) } catch {}
        $script:SortDirty = $false
    }
}
function Test-RowReady([int]$i) { return [bool]$script:RowReady[$i] }
# ---------- ข้อมูล LINE ผูกกับ "ตัวเครื่อง" (เลข + เวลาสร้าง) ไม่ใช่แค่เลข ----------
$script:IdxUid = @{}      # idx -> key of the LD that has this number now
$script:RowUidShown = @{} # idx -> key whose data the row is showing
function Get-LdStamp([int]$idx) { $w = Get-LdCreated $idx; if ($w) { return $w.ToString('yyyyMMddHHmmss') } else { return '' } }
function Get-InfoKey([int]$idx) { if ($script:IdxUid.ContainsKey($idx)) { return [string]$script:IdxUid[$idx] } else { return [string]$idx } }
function Get-UidIdx([string]$uid) { $n = 0; [void][int]::TryParse(($uid -split '@')[0], [ref]$n); return $n }
function Get-UidCreated([string]$uid) {
    $s = @($uid -split '@')
    if ($s.Count -gt 1 -and $s[1]) { try { return [datetime]::ParseExact($s[1], 'yyyyMMddHHmmss', [System.Globalization.CultureInfo]::InvariantCulture) } catch {} }
    return $null
}
function Test-InfoHasData($li) { return ($li -and ([string]$li.Name -or [string]$li.Friends -or [string]$li.Groups)) }
function New-InfoRec { return @{ Name = ''; Friends = ''; Groups = ''; LastOpen = '' } }
function Resolve-LdUids($snap) {
    $dir = [string]$Sync.LdDir
    $live = @{}
    $pending = New-Object System.Collections.ArrayList
    $dirty = $false
    foreach ($it in @($snap)) {
        $idx = [int]$it.Index
        $uid = "$idx@" + (Get-LdStamp $idx)
        $live[$idx] = $uid
        if ($cfg.LineInfo.ContainsKey($uid)) { continue }
        $legacy = [string]$idx
        $old = @($cfg.LineInfo.Keys | Where-Object { $_ -like "$idx@*" } | Sort-Object -Descending)
        if ($cfg.LineInfo.ContainsKey($legacy) -and -not $old.Count) {
            # data from the old version (saved by number only) -> this LD
            $cfg.LineInfo[$uid] = $cfg.LineInfo[$legacy]; $cfg.LineInfo.Remove($legacy); $dirty = $true
            continue
        }
        $stamp = ($uid -split '@')[1]
        if (-not $stamp -and $old.Count) { $live[$idx] = $old[0]; continue }   # creation time not readable right now: keep the newest record
        $unknown = @($old | Where-Object { $_ -eq "$idx@" })
        if ($unknown.Count) { $cfg.LineInfo[$uid] = $cfg.LineInfo[$unknown[0]]; $cfg.LineInfo.Remove($unknown[0]); $dirty = $true; continue }
        if ($old.Count) { [void]$pending.Add(@($idx, $uid, $old[0])) } else { $cfg.LineInfo[$uid] = New-InfoRec; $dirty = $true }
    }
    if ($pending.Count) {
        # LDPlayer folder changed / moved (all creation times change together) -> keep data on the same numbers
        $rebind = (-not $cfg.UidDir) -or ($cfg.UidDir -ne $dir) -or ($pending.Count -ge 3 -and $pending.Count -ge [Math]::Ceiling($live.Count * 0.8))
        foreach ($pd in $pending) {
            $idx = $pd[0]; $uid = $pd[1]; $old = $pd[2]
            if ($rebind) {
                $cfg.LineInfo[$uid] = $cfg.LineInfo[$old]; $cfg.LineInfo.Remove($old)
            } else {
                $cfg.LineInfo[$uid] = New-InfoRec
                if (Test-InfoHasData $cfg.LineInfo[$old]) { Write-LineJobLog "LD #$idx เป็นเครื่องใหม่ (สร้างใหม่ด้วยเลขเดิม) — ข้อมูล LINE ของเครื่องเดิม '$([string]$cfg.LineInfo[$old].Name)' เก็บไว้เป็นแถว 'ข้อมูลเก่า'" }
            }
            $dirty = $true
        }
    }
    if ($dir -and $cfg.UidDir -ne $dir) { $cfg.UidDir = $dir; $dirty = $true }
    $script:IdxUid = $live
    return $dirty
}
function Update-Grid {
    $snap = $Sync.Snapshot
    if ($null -eq $snap) { return }
    $seen = @{}
    $cfgDirty = $false
    $script:InGridUpdate = $true
    try { if (Resolve-LdUids $snap) { $cfgDirty = $true } } catch {}
    foreach ($it in @($snap | Where-Object { [bool]$_.Running -and [bool]$_.AdbOk })) {
        $key = [string]$it.Index
        $idx = [int]$it.Index
        $seen[$key] = $true
        $row = $script:rowMap[$key]
        if ($null -eq $row) {
            $n = $grid.Rows.Add()
            $row = $grid.Rows[$n]
            $row.Tag = $idx
            $row.Cells['Chk'].Value = [bool]$script:checked[$idx]
            $script:rowMap[$key] = $row
        }
        $infoKey = Get-InfoKey $idx
        if ([string]$script:RowUidShown[$idx] -ne $infoKey) {
            # new row, or this number now belongs to a different (new) LD: show that LD's own data
            $li = $cfg.LineInfo[$infoKey]
            Set-Cell $row 'LineName' $(if ($li) { [string]$li.Name } else { '' })
            Set-Cell $row 'Friends' $(if ($li) { [string]$li.Friends } else { '' })
            Set-Cell $row 'Groups' $(if ($li) { [string]$li.Groups } else { '' })
            $script:RowUidShown[$idx] = $infoKey
            $script:SortDirty = $true
        }
        $running = [bool]$it.Running
        $ready = [bool]$it.AdbOk
        # remember when this LD was last seen opening
        if ($running -and -not [bool]$script:RowRunning[$idx]) {
            if (-not $cfg.LineInfo.ContainsKey($infoKey)) { $cfg.LineInfo[$infoKey] = New-InfoRec }
            $cfg.LineInfo[$infoKey]['LastOpen'] = (Get-Date).ToString('yyyy-MM-dd HH:mm')
            $cfgDirty = $true
        }
        $script:RowRunning[$idx] = $running
        $script:RowReady[$idx] = $ready
        if ($ready) { if (-not $script:ReadySince.ContainsKey($idx)) { $script:ReadySince[$idx] = Get-Date } } else { [void]$script:ReadySince.Remove($idx) }
        $script:idleStatus[$idx] = $it.Status
        Set-Cell $row 'Index' $it.Index
        $state = if ($ready) { 'ok' } elseif ($running) { 'wait' } else { 'off' }
        $adbText = switch ($state) { 'ok' { [string]$it.Adb } 'wait' { 'กำลังเชื่อม…' } default { 'ปิดอยู่' } }
        Set-Cell $row 'Adb' $adbText
        $row.Cells['Adb'].Tag = $state
        $dim = ($state -eq 'off')
        $want = if ($dim) { $uiFaint } else { [System.Drawing.Color]::Empty }
        if ($row.DefaultCellStyle.ForeColor -ne $want) { $row.DefaultCellStyle.ForeColor = $want }
    }
    foreach ($k in @($script:rowMap.Keys)) {
        if (-not $seen.ContainsKey($k)) { $grid.Rows.Remove($script:rowMap[$k]); $script:rowMap.Remove($k); $script:RowUidShown.Remove([int]$k); $script:RowRunning[[int]$k] = $false; $script:RowReady[[int]$k] = $false; [void]$script:ReadySince.Remove([int]$k); [void]$script:TickedNames.Remove([int]$k) }
    }
    $script:InGridUpdate = $false
    if ($cfgDirty) { Save-Config }
    try { Update-Sort } catch {}
    Update-Status
}
$script:LmsSeen = @{}
$script:LmsTime = @{}
function Update-Status {
    foreach ($row in $grid.Rows) {
        if ($null -eq $row.Tag) { continue }
        $i = [int]$row.Tag
        $fr = ([string]$row.Cells['Friends'].Value).Trim(); $gr = ([string]$row.Cells['Groups'].Value).Trim()
        Set-Cell $row 'FG' $(if ($fr -or $gr) { "$(if ($fr) { $fr } else { '-' }) · $(if ($gr) { $gr } else { '-' })" } else { '' })
        Set-Cell $row 'Today' (Get-TodayText $i)
        Set-Cell $row 'LastSet' ([string]$cfg.LastSet[(Get-InfoKey $i)])
        $act = Get-RowActivity $i
        $b = $Sync.Busy[$i]
        if ($act) {
            $badge = $act.Label
            if ($act.Since) {
                $sec = [int]((Get-Date) - $act.Since).TotalSeconds
                $badge += ' · ' + ('{0:00}:{1:00}' -f [int][Math]::Floor($sec / 60), ($sec % 60))
            }
            $script:RowActInfo[$i] = @{ Kind = $act.Kind; Badge = $badge; Detail = $act.Detail }
            Set-Cell $row 'Status' ("$badge  $($act.Detail)").Trim()
            $row.Cells['Status'].Style.ForeColor = $script:ActColors[$act.Kind]
        } elseif ($b) {
            $script:RowActInfo[$i] = @{ Kind = 'worker'; Badge = [string]$b; Detail = '' }
            Set-Cell $row 'Status' $b
            $row.Cells['Status'].Style.ForeColor = $uiWarn
        } else {
            [void]$script:RowActInfo.Remove($i)
            if (-not [bool]$script:RowRunning[$i]) {
                $lo = $cfg.LineInfo[(Get-InfoKey $i)]
                $txt = 'ปิดอยู่' + $(if ($lo -and $lo.LastOpen) { " · เปิดล่าสุด $($lo.LastOpen)" } else { '' })
                Set-Cell $row 'Status' $txt
                $row.Cells['Status'].Style.ForeColor = $uiFaint
                continue
            }
            if ($script:LineMainStatus.ContainsKey($i)) {
                $txt = [string]$script:LineMainStatus[$i]
                if ($script:LmsSeen[$i] -ne $txt) { $script:LmsSeen[$i] = $txt; $script:LmsTime[$i] = (Get-Date).ToString('HH:mm') }
                $shown = "$txt · $($script:LmsTime[$i])"
            } else { $txt = [string]$script:idleStatus[$i]; $shown = $txt }
            Set-Cell $row 'Status' $shown
            $row.Cells['Status'].Style.ForeColor = if ($txt -match 'ไม่สำเร็จ|ผิดพลาด|ไม่ครบ|ไม่ได้|หมดเวลา|ERROR') { $uiBad } elseif ($txt -match 'หยุด|ยกเลิก') { $uiWarn } else { $uiOk }
        }
    }
}

# --- หน้าต่างรายงาน ---
function Show-Diag([string]$text) {
    $f = New-Object System.Windows.Forms.Form
    $f.Text = 'รายงานตรวจสอบปัญหา'
    $f.Size = New-Object System.Drawing.Size(980, 640)
    $f.StartPosition = 'CenterParent'
    $f.Font = $font
    $f.BackColor = $uiBg
    $f.ForeColor = $uiInk
    $f.Icon = $script:AppIcon
    $f.Padding = New-Object System.Windows.Forms.Padding(12, 12, 12, 0)
    Set-DarkTitle $f
    $tb = New-Object System.Windows.Forms.TextBox
    $tb.Multiline = $true; $tb.ReadOnly = $true; $tb.WordWrap = $false
    $tb.ScrollBars = 'Both'; $tb.Dock = 'Fill'
    $tb.BackColor = $uiLogBg
    $tb.ForeColor = New-Rgb 201 209 217
    $tb.BorderStyle = 'None'
    $tb.Font = New-Object System.Drawing.Font('Tahoma', 9.5)
    $tb.Text = ($text -replace "`r?`n", "`r`n")
    $bar = New-Object System.Windows.Forms.FlowLayoutPanel
    $bar.Dock = 'Bottom'; $bar.AutoSize = $true; $bar.FlowDirection = 'RightToLeft'
    $bar.BackColor = $uiBg
    $bar.Padding = New-Object System.Windows.Forms.Padding(0, 10, 0, 12)
    $bClose = New-Btn 'ปิด' { $f.Close() }
    $bSave = New-Btn 'บันทึกเป็นไฟล์' {
        $d = New-Object System.Windows.Forms.SaveFileDialog
        $d.Filter = 'Text (*.txt)|*.txt'
        $d.FileName = "ld-adb-report-$((Get-Date).ToString('yyyyMMdd-HHmmss')).txt"
        if ($d.ShowDialog($f) -eq 'OK') { [System.IO.File]::WriteAllText($d.FileName, $tb.Text, [System.Text.Encoding]::UTF8) }
    }
    $bCopy = New-Btn 'คัดลอกทั้งหมด' { [System.Windows.Forms.Clipboard]::SetText($tb.Text) } 'primary'
    $bar.Controls.AddRange(@($bClose, $bSave, $bCopy))
    $f.Controls.Add($tb)
    $f.Controls.Add($bar)
    $f.Show($form)
}

# --- เริ่ม worker ---
function Start-Worker {
    $script:rs = [runspacefactory]::CreateRunspace()
    $script:rs.ApartmentState = 'MTA'
    $script:rs.ThreadOptions = 'ReuseThread'
    $script:rs.Open()
    $script:ps = [powershell]::Create()
    $script:ps.Runspace = $script:rs
    [void]$script:ps.AddScript($WorkerScript).AddArgument($Sync)
    $script:handle = $script:ps.BeginInvoke()
}

# --- Timer ฝั่ง UI (อ่านผลจาก worker, ไม่ทำงานหนัก) ---
$script:lastVersion = -1
$script:lastDiag = 0
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 400
$script:TxtTick = 0
$timer.Add_Tick({
    $script:TxtTick++
    if ($script:TxtTick % 5 -eq 0 -and $script:TextKeys.Count) { try { Apply-Texts $form } catch {} }
    if ($script:TxtTick % 5 -eq 0) { try { Invoke-AutoFindOa } catch {} }
    if ($script:TxtTick % 3 -eq 0) { try { Update-SysMon } catch {} }
    if ($script:TxtTick % 75 -eq 0) { try { Update-CountUi } catch {} }   # new day -> today's counts back to 0
    if ((Get-Date) -ge $script:UpdNextCheck) { $script:UpdNextCheck = (Get-Date).AddMinutes(30); try { Start-UpdateCheck $false } catch {} }
    $line = $null
    $sb = New-Object System.Text.StringBuilder
    while ($Sync.Log.TryDequeue([ref]$line)) { [void]$sb.AppendLine($line) }
    if ($sb.Length -gt 0) {
        if ($txtLog.TextLength -gt 150000) { $txtLog.Text = $txtLog.Text.Substring($txtLog.TextLength - 60000) }
        $txtLog.AppendText($sb.ToString())
    }
    if ($Sync.Version -ne $script:lastVersion) {
        $script:lastVersion = $Sync.Version
        try { Update-Grid } catch {}
        $lblStatus.Text = $Sync.Summary
    }
    if ($Sync.DiagVersion -ne $script:lastDiag) {
        $script:lastDiag = $Sync.DiagVersion
        Show-Diag $Sync.DiagReport
    }
    try { Update-Status } catch {}
    try { Update-HeaderStats } catch {}
    # watchdog: ถ้า worker ตายให้เริ่มใหม่
    if (-not $Sync.Stop -and $script:handle -and $script:handle.IsCompleted) {
        $err = ($script:ps.Streams.Error | Select-Object -Last 1)
        $Sync.Log.Enqueue("[$((Get-Date).ToString('HH:mm:ss'))] worker หยุดทำงาน ($err) -> เริ่มใหม่")
        try { $script:ps.Dispose(); $script:rs.Dispose() } catch {}
        Start-Worker
    }
})

# ---- คำอธิบายปุ่มต่างๆ (เอาเมาส์ชี้) ----
Set-Tip $btnAll 'ติ๊ก ✔ ทุกเครื่องในตาราง'
Set-Tip $btnNone 'เอาติ๊กออกทุกเครื่อง'
Set-Tip $lblChecked 'จำนวนเครื่องที่ติ๊กไว้ / ทั้งหมดในตาราง (งานจะทำกับเครื่องที่ติ๊กเท่านั้น)'
Set-Tip $btnStopSel 'หยุดงานของเครื่องที่ติ๊กไว้ (รวมเครื่องที่รอคิวอยู่)'
Set-Tip $btnLineStop 'หยุดงานทุกเครื่อง และยกเลิกคิวทั้งหมด'
Set-Tip $btnToggleSettings 'ตั้งค่าโปรแกรม: ธีม, การเชื่อมต่อ ADB, อัปเดตโปรแกรม, รีเซ็ตยอดนับ ฯลฯ'
Set-Tip $btnCfgAdd 'เพิ่มแถวชุด ID ใหม่ (เพิ่มได้ไม่จำกัด) แล้วกรอก ID ลงในช่อง'
Set-Tip $btnCfgDel 'ลบชุดที่เลือกอยู่ (คลิกช่องในแถวนั้นก่อน) แล้วอย่าลืมกดบันทึก'
Set-Tip $btnCfgSave 'บันทึกทุกชุด ID และจำนวนกลุ่ม ลงไฟล์ config.json (ต้องกดหลังแก้ไขทุกครั้ง)'
Set-Tip $btnCfgLoad 'โหลดชุด ID จากไฟล์ใหม่ (ทิ้งการแก้ไขที่ยังไม่ได้บันทึก)'
Set-Tip $btnIdColAdd 'เพิ่มช่อง ID ให้แต่ละชุด (ID 3, ID 4, ...)'
Set-Tip $btnIdColDel 'ลดช่อง ID ช่องสุดท้าย (ต้องลบข้อมูลในช่องนั้นก่อน)'
Set-Tip $btnIdNames "ค้นหาแต่ละ ID ด้วย LD ที่ติ๊กไว้ แล้วอ่านชื่อจริงมาใส่ในวงเล็บ`r`nค้นหาอย่างเดียว ไม่กดเพิ่มเพื่อน"
Set-Tip $comboMode 'ค้นหาด้วย ID หรือเบอร์โทร ตอนเพิ่มเพื่อนใน LINE'
try { $grid.Columns['Chk'].ToolTipText = 'ติ๊กเครื่องที่จะสั่งงาน (คลิกหัวช่องนี้ = ติ๊ก/เอาออกทั้งหมด)' } catch {}
try { $grid.Columns['Index'].ToolTipText = 'หมายเลข LD (เลขเดียวกับใน LDPlayer)' } catch {}
try { $grid.Columns['Adb'].ToolTipText = 'สถานะ ADB: เขียว = เชื่อมแล้วพร้อมใช้' } catch {}
try { $grid.Columns['Status'].ToolTipText = 'งานที่กำลังทำ / ผลล่าสุดของเครื่องนี้ (ชื่อที่ติ๊ก, ชื่อซ้ำเป็นสีแดง)' } catch {}
$form.Add_Shown({
    try { Write-LineJobLog "เปิดโปรแกรม LineDeck เวอร์ชัน $($script:AppVersion)" } catch {}
    $script:NewsTimer = New-Object System.Windows.Forms.Timer
    $script:NewsTimer.Interval = 900
    $script:NewsTimer.Add_Tick({ $script:NewsTimer.Stop(); try { Test-ShowWhatsNew } catch {} })
    $script:NewsTimer.Start()
    $script:TxtSkipCombo = @($comboMode)
    try { Apply-Texts $form } catch {}
    if ($cfg.LdDir -and (Test-Path (Join-Path $cfg.LdDir 'adb.exe'))) { $txtDir.Text = $cfg.LdDir }
    else { $txtDir.Text = Find-LdDir }
    Apply-Dir
    Start-Worker
    $timer.Start()
    if (-not $Sync.PathOk) {
        Show-Page 'settings'
        [void][System.Windows.Forms.MessageBox]::Show($form, 'หาโฟลเดอร์ LDPlayer9 ไม่เจอ กรุณากด "เลือก..." (แท็บ ตั้งค่า → การเชื่อมต่อ ADB) แล้วเลือกโฟลเดอร์ที่มี ldconsole.exe', 'ตั้งค่าครั้งแรก')
    }
})

$form.Add_FormClosing({
    try {
        $bnd = if ($form.WindowState -eq 'Normal') { $form.Bounds } else { $form.RestoreBounds }
        if ($bnd.Width -ge 720 -and $bnd.Height -ge 420) { $cfg.WinX = $bnd.X; $cfg.WinY = $bnd.Y; $cfg.WinW = $bnd.Width; $cfg.WinH = $bnd.Height }
    } catch {}
    Save-Config
    $timer.Stop()
    $script:LineJobTimer.Stop()
    $script:LineStartTimer.Stop()
    try { $script:InfoJobTimer.Stop() } catch {}
    foreach ($job in @($script:InfoJobs.ToArray())) {
        try { if (-not $job.Process.HasExited) { $job.Process.Kill() } } catch {}
        try { $job.Process.Dispose() } catch {}
    }
    foreach ($job in @($script:LineJobs.ToArray())) {
        try { if (-not $job.Process.HasExited) { $job.Process.Kill() } } catch {}
        try { $job.Process.Dispose() } catch {}
    }
    $Sync.Stop = $true
    try {
        if ($script:handle -and -not $script:handle.AsyncWaitHandle.WaitOne(2500)) { [void]$script:ps.BeginStop($null, $null) }
    } catch {}
})

$script:ErrLogPath = Join-Path $CfgDir 'errors.log'
[System.Windows.Forms.Application]::add_ThreadException({
    param($sender, $ev)
    try {
        $ex = $ev.Exception
        $where = ''
        $detail = ''
        if ($ex -is [System.Management.Automation.RuntimeException] -and $ex.ErrorRecord -and $ex.ErrorRecord.InvocationInfo) {
            $where = " (บรรทัด $($ex.ErrorRecord.InvocationInfo.ScriptLineNumber))"
            $detail = $ex.ErrorRecord.InvocationInfo.PositionMessage
        }
        $msg = "[$((Get-Date).ToString('HH:mm:ss'))] ⚠ ข้อผิดพลาดภายใน$where : $($ex.Message)"
        try { $txtLog.AppendText("$msg`r`n") } catch {}
        try { $lblStatus.Text = "เกิดข้อผิดพลาดภายใน$where ดูแท็บบันทึก" } catch {}
        try { [System.IO.File]::AppendAllText($script:ErrLogPath, "$((Get-Date).ToString('yyyy-MM-dd HH:mm:ss')) $($ex.GetType().FullName): $($ex.Message)`r`n$detail`r`n$($ex.StackTrace)`r`n`r`n", [System.Text.Encoding]::UTF8) } catch {}
    } catch {}
})
[System.Windows.Forms.Application]::Run($form)

try { $script:ps.Dispose(); $script:rs.Dispose() } catch {}
if ($script:ConsoleHandle -and $script:ConsoleHandle -ne [IntPtr]::Zero) { try { [void][LdAdb.ConWin]::ShowWindow($script:ConsoleHandle, 5) } catch {} }
