﻿<#
.SYNOPSIS
  อ่านข้อมูลบัญชี LINE บน LDPlayer ผ่าน ADB (ไม่ต้องใช้ Root)
    - ชื่อ LINE (ชื่อโปรไฟล์)
    - จำนวนเพื่อน
    - จำนวนกลุ่ม
  วิธีทำงาน: เปิด LINE > แตะแท็บหน้าหลัก (Home) > อ่านโครงสร้างหน้าจอ (uiautomator)
  ถ้ายังไม่เห็นตัวเลข จะเลื่อนหน้าจอลงแล้วอ่านซ้ำ (สูงสุด -Scrolls ครั้ง)
.OUTPUTS
  JSON บรรทัดเดียว:
  {"ok":true,"serial":"..","name":"..","nameSource":"id|guess","friends":120,"groups":5,"dump":"C:\...\ui.xml"}
  Exit code 0 = อ่านได้อย่างน้อย 1 ค่า, 1 = อ่านไม่ได้, 2 = ผิดพลาด
.EXAMPLE
  .\Adb-LineInfo.ps1 -Serial 127.0.0.1:5555 -LaunchLine
#>
param(
    [string]$Adb       = '',
    [string]$Serial    = '',
    [string]$Package   = 'jp.naver.line.android',
    [string]$OutDir    = '',
    [int]$Scrolls      = 3,
    [int]$StepDelayMs  = 1200,
    [switch]$LaunchLine
)

$ErrorActionPreference = 'Stop'
function Out-Result($o, [int]$code) {
    $json = $o | ConvertTo-Json -Compress -Depth 5
    # escape non-ASCII (Thai names, emoji) so the result survives console-codepage redirection
    $json = [regex]::Replace($json, '[^\x00-\x7F]', [System.Text.RegularExpressions.MatchEvaluator]{ param($m) '\u{0:x4}' -f [int][char]$m.Value })
    $json
    exit $code
}

# ---------- Find adb ----------
if (-not $Adb) {
    $cands = @('C:\LDPlayer\LDPlayer9\adb.exe', 'C:\LDPlayer\LDPlayer4.0\adb.exe', 'D:\LDPlayer\LDPlayer9\adb.exe', "$env:ProgramFiles\LDPlayer\LDPlayer9\adb.exe")
    $p = Get-Process -Name 'dnplayer', 'Ld9BoxHeadless' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($p -and $p.Path) { $cands = @((Join-Path (Split-Path $p.Path) 'adb.exe')) + $cands }
    $Adb = $cands | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (-not $Adb) { $c = Get-Command adb -ErrorAction SilentlyContinue; if ($c) { $Adb = $c.Source } }
}
if (-not $Adb -or -not (Test-Path $Adb)) { Out-Result @{ ok = $false; error = 'adb.exe not found, specify -Adb' } 2 }

function Invoke-Adb([string[]]$a) {
    $all = @(); if ($Serial) { $all += @('-s', $Serial) }; $all += $a
    $old = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { return (& $Adb @all 2>&1 | Out-String) } finally { $ErrorActionPreference = $old }
}

if (-not $OutDir) { $OutDir = Join-Path $env:TEMP 'adb_line' }
[void][System.IO.Directory]::CreateDirectory($OutDir)

# ---------- Text patterns (TH / EN / JP / KR) ----------
$FriendsLabel = 'friends?|เพื่อน|友だち|친구'
$GroupsLabel  = 'groups?|กลุ่ม|グループ|그룹'
$HomeLabel    = '(?i)^\s*(home|หน้าหลัก|ホーム|홈)\s*$'
$HomeId       = '(?i)(bnb_home|tab_home|home_tab|main_tab_home|bottom_navigation_home)'
$NameId       = '(?i)(profile[_\.]?name|name[_\.]?profile|my[_\.]?name|home.*(user|profile|my).*name|display[_\.]?name|header.*name)'
$SkipName     = '(?i)^\s*(home|หน้าหลัก|chats?|แชท|voom|news|ข่าว|today|wallet|วอลเล็ท|shopping|ช็อปปิ้ง|mini|search|ค้นหา|' +
                $FriendsLabel + '|' + $GroupsLabel + '|services?|บริการ|see all|ดูทั้งหมด|more|เพิ่มเติม|add friends?|เพิ่มเพื่อน|' +
                'settings?|ตั้งค่า|keep|notes?|โน้ต|edit|แก้ไข|official accounts?|บัญชีทางการ|stickers?|สติกเกอร์|themes?|ธีม)\s*$'

# ---------- Read screen structure (pull as UTF-8 file so Thai names are not garbled) ----------
$script:DumpN = 0
$script:LastDump = ''
$safeSerial = ($Serial -replace '[^\w\-\.]', '_')
function Get-Ui {
    for ($i = 1; $i -le 3; $i++) {
        $script:DumpN++
        $local = Join-Path $OutDir ("ui_{0}_{1}_{2}.xml" -f $safeSerial, (Get-Date).ToString('HHmmss'), $script:DumpN)
        [void](Invoke-Adb @('shell', 'rm -f /sdcard/__lineinfo.xml; uiautomator dump /sdcard/__lineinfo.xml'))
        [void](Invoke-Adb @('pull', '/sdcard/__lineinfo.xml', $local))
        if (Test-Path -LiteralPath $local) {
            try {
                $txt = [System.IO.File]::ReadAllText($local, [System.Text.Encoding]::UTF8)
                [xml]$x = $txt
                $script:LastDump = $local
                $nodes = New-Object System.Collections.ArrayList
                foreach ($n in $x.SelectNodes('//node')) {
                    $b = [string]$n.bounds
                    if ($b -match '\[(-?\d+),(-?\d+)\]\[(-?\d+),(-?\d+)\]') {
                        [void]$nodes.Add([pscustomobject]@{
                            Text  = ([string]$n.text).Trim()
                            Desc  = ([string]$n.'content-desc').Trim()
                            Id    = [string]$n.'resource-id'
                            Click = ([string]$n.clickable -eq 'true')
                            X1 = [int]$Matches[1]; Y1 = [int]$Matches[2]; X2 = [int]$Matches[3]; Y2 = [int]$Matches[4]
                        })
                    }
                }
                if ($nodes.Count -gt 0) { return , $nodes.ToArray() }
            } catch { }
        }
        Start-Sleep -Milliseconds 700
    }
    return , @()
}
function Get-Label($n) { if ($n.Text) { return $n.Text } return $n.Desc }
function Convert-Num([string]$s) {
    $d = ($s -replace '[^\d]', '')
    if ($d) { return [int]$d }
    return $null
}
function Tap-Node($n) {
    $cx = [int](($n.X1 + $n.X2) / 2)
    $cy = [int](($n.Y1 + $n.Y2) / 2)
    [void](Invoke-Adb @('shell', "input tap $cx $cy"))
}

# จำนวน: แบบอยู่ในข้อความเดียวกัน ("Friends 120", "เพื่อน (120)")
# หรือแยกเป็น 2 ช่อง ("Friends" + "120" อยู่แถวเดียวกันด้านขวา)
function Find-Count($nodes, [string]$label) {
    $inline = "(?i)^\s*(?:$label)\s*[·•:\-]?\s*[\(\[]?\s*(\d[\d,\.]*)\s*[\)\]]?\s*$"
    foreach ($n in $nodes) {
        foreach ($t in @($n.Text, $n.Desc)) {
            if (-not $t) { continue }
            $m = [regex]::Match($t, $inline)
            if ($m.Success) { return (Convert-Num $m.Groups[1].Value) }
        }
    }
    $only = "(?i)^\s*(?:$label)\s*$"
    foreach ($n in $nodes) {
        if ((Get-Label $n) -notmatch $only) { continue }
        $cy = ($n.Y1 + $n.Y2) / 2
        $best = $null; $bestD = [int]::MaxValue
        foreach ($o in $nodes) {
            $ot = Get-Label $o
            if ($ot -notmatch '^\s*[\(\[]?\s*\d[\d,\.]*\s*[\)\]]?\s*$') { continue }
            $ocy = ($o.Y1 + $o.Y2) / 2
            if ([Math]::Abs($ocy - $cy) -gt 30) { continue }
            if ($o.X1 -lt $n.X1) { continue }
            $d = $o.X1 - $n.X2
            if ($d -lt $bestD) { $bestD = $d; $best = $o }
        }
        if ($best) { return (Convert-Num (Get-Label $best)) }
    }
    return $null
}
function Find-LabelY($nodes, [string]$label) {
    $re = "(?i)^\s*(?:$label)\b"
    $hit = @($nodes | Where-Object { (Get-Label $_) -match $re } | Sort-Object Y1 | Select-Object -First 1)
    if ($hit.Count) { return $hit[0].Y1 }
    return $null
}
function Find-Name($nodes, $limitY) {
    $byId = @($nodes | Where-Object { $_.Id -match $NameId -and $_.Text -and $_.Text -notmatch $SkipName } | Sort-Object Y1 | Select-Object -First 1)
    if ($byId.Count) { return @($byId[0].Text, 'id') }
    $maxY = if ($limitY) { [int]$limitY } else { 800 }
    $cand = @($nodes | Where-Object {
            $_.Text -and $_.Text.Length -ge 2 -and
            $_.Text -notmatch $SkipName -and
            $_.Text -notmatch '^[\d,\.\s\(\)\+\-:/]+$' -and
            $_.Y1 -ge 60 -and $_.Y2 -le $maxY
        } | Sort-Object Y1, X1 | Select-Object -First 1)
    if ($cand.Count) { return @($cand[0].Text, 'guess') }
    return @('', '')
}

try {
    # ---------- Check device ----------
    if (-not $Serial) {
        $dev = (Invoke-Adb @('devices')) -split "`r?`n" | Where-Object { $_ -match '^\S+\s+device$' } | Select-Object -First 1
        if (-not $dev) { Out-Result @{ ok = $false; error = 'No ADB device found (is LDPlayer open with ADB enabled?)' } 2 }
        $Serial = ($dev -split '\s+')[0]
        $safeSerial = ($Serial -replace '[^\w\-\.]', '_')
    }

    # ---------- Screen size (for scrolling) ----------
    $w = 720; $h = 1280
    $ws = Invoke-Adb @('shell', 'wm size')
    $sm = [regex]::Matches($ws, '(\d{3,5})x(\d{3,5})')
    if ($sm.Count -gt 0) { $w = [int]$sm[$sm.Count - 1].Groups[1].Value; $h = [int]$sm[$sm.Count - 1].Groups[2].Value }

    # ---------- Open LINE ----------
    $focus = Invoke-Adb @('shell', 'dumpsys window | grep -E "mCurrentFocus|mFocusedApp"')
    if ($focus -notmatch [regex]::Escape($Package)) {
        if ($LaunchLine) {
            [void](Invoke-Adb @('shell', "monkey -p $Package -c android.intent.category.LAUNCHER 1"))
            Start-Sleep -Seconds 4
        } else {
            Out-Result @{ ok = $false; serial = $Serial; error = 'LINE is not on screen (add -LaunchLine to open it)' } 1
        }
    }

    # ---------- Go to Home tab ----------
    $nodes = Get-Ui
    $homeTapped = $false
    $homeNode = @($nodes | Where-Object { ((Get-Label $_) -match $HomeLabel) -or ($_.Id -match $HomeId) } | Sort-Object Y1 -Descending | Select-Object -First 1)
    if ($homeNode.Count) {
        Tap-Node $homeNode[0]
        $homeTapped = $true
        Start-Sleep -Milliseconds $StepDelayMs
        $nodes = Get-Ui
    }

    # ---------- Read values (scroll down if needed) ----------
    $name = ''; $nameSource = ''
    $friends = $null; $groups = $null
    $swipes = 0
    for ($s = 0; $s -le $Scrolls; $s++) {
        if ($s -gt 0) {
            $x = [int]($w / 2)
            [void](Invoke-Adb @('shell', "input swipe $x $([int]($h * 0.75)) $x $([int]($h * 0.35)) 450"))
            $swipes++
            Start-Sleep -Milliseconds $StepDelayMs
            $nodes = Get-Ui
        }
        if (-not $nodes.Count) { continue }
        if ($null -eq $friends) { $friends = Find-Count $nodes $FriendsLabel }
        if ($null -eq $groups)  { $groups  = Find-Count $nodes $GroupsLabel }
        if ($s -eq 0 -and -not $name) {
            $limit = Find-LabelY $nodes ($GroupsLabel + '|' + $FriendsLabel)
            $nm = Find-Name $nodes $limit
            $name = [string]$nm[0]; $nameSource = [string]$nm[1]
        }
        if ($null -ne $friends -and $null -ne $groups) { break }
    }

    # ---------- Scroll back to top ----------
    for ($i = 0; $i -lt $swipes; $i++) {
        $x = [int]($w / 2)
        [void](Invoke-Adb @('shell', "input swipe $x $([int]($h * 0.35)) $x $([int]($h * 0.75)) 300"))
        Start-Sleep -Milliseconds 250
    }
    [void](Invoke-Adb @('shell', 'rm -f /sdcard/__lineinfo.xml'))

    $ok = ($null -ne $friends) -or ($null -ne $groups) -or [bool]$name
    $res = [ordered]@{
        ok = [bool]$ok; serial = $Serial; name = $name; nameSource = $nameSource
        friends = $friends; groups = $groups; homeTapped = $homeTapped; dump = $script:LastDump
    }
    if (-not $ok) { $res.error = 'อ่านข้อมูลจากหน้าจอ LINE ไม่ได้ (ตรวจว่า LINE ล็อกอินแล้วและอยู่หน้าหลัก)' }
    Out-Result $res ([int](-not $ok))
}
catch {
    Out-Result @{ ok = $false; serial = $Serial; error = $_.Exception.Message; dump = $script:LastDump } 2
}
