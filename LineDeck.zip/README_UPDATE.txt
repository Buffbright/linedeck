﻿LineDeck - วิธีตั้งระบบอัปเดตอัตโนมัติ (ทำครั้งเดียว)
=====================================================

1) สร้าง repository บน GitHub
   - เข้า github.com > ปุ่ม New (สร้าง repository ใหม่)
   - ตั้งชื่อ เช่น linedeck
   - เลือก Public (ต้องเป็น Public เครื่องอื่นถึงจะดาวน์โหลดได้)
   - ติ๊ก "Add a README file" แล้วกด Create repository

2) ใส่ลิงก์ในไฟล์ update.json (อยู่ในโฟลเดอร์โปรแกรม) แก้เป็น:
   {
     "versionUrl": "https://raw.githubusercontent.com/ชื่อบัญชีGitHub/linedeck/main/version.json"
   }
   (เปลี่ยน "ชื่อบัญชีGitHub" และ "linedeck" ให้ตรงกับของคุณ)

3) ปล่อยเวอร์ชันแรก
   - ดับเบิลคลิก make-release.bat
   - จะได้โฟลเดอร์ release มี LineDeck.zip กับ version.json
   - ใน GitHub repository กด Add file > Upload files > ลาก 2 ไฟล์นั้นใส่ > Commit changes

4) แจก LineDeck.zip (ในโฟลเดอร์ release) ให้ทุกเครื่องติดตั้งครั้งแรกด้วยมือ 1 ครั้ง
   หลังจากนี้ทุกเครื่องจะอัปเดตเองจาก GitHub

ทุกครั้งที่มีเวอร์ชันใหม่
------------------------
   - เอาไฟล์ใหม่วางทับในโฟลเดอร์โปรแกรมของคุณ
   - ดับเบิลคลิก make-release.bat อีกครั้ง
   - อัปโหลด LineDeck.zip + version.json ทับของเดิมใน GitHub
   - ทุกเครื่องจะเห็นภายใน 30 นาที หรือตอนเปิดโปรแกรม
     (ตั้งในหน้า ตั้งค่า > อัปเดตโปรแกรม ได้ว่าจะให้ถามก่อน หรืออัปเดตเองเลย)

ข้อมูลของแต่ละเครื่อง (ชุด ID, ค่าตั้ง, บันทึก) ไม่หายเวลาอัปเดต
ห้ามให้คนอื่นเข้าบัญชี GitHub นี้ เพราะใครแก้ไฟล์ได้ = ส่งโปรแกรมเข้าทุกเครื่องได้

อัปโหลดอัตโนมัติ (แนะนำ - ทำครั้งเดียว แล้วต่อไปดับเบิลคลิก make-release.bat อย่างเดียวจบ)
-----------------------------------------------------------------------------------
1) เข้า github.com > รูปโปรไฟล์มุมขวาบน > Settings
2) เมนูซ้ายล่างสุด Developer settings > Personal access tokens > Fine-grained tokens > Generate new token
3) ตั้งค่า:
   - Token name: LineDeck release
   - Expiration: เลือกนานตามต้องการ (เช่น 1 year)
   - Repository access: Only select repositories > เลือก repo ของ LineDeck
   - Permissions > Repository permissions > Contents: Read and write
4) กด Generate token แล้วคัดลอก token (ขึ้นต้นด้วย github_pat_...)
5) ดับเบิลคลิก make-release.bat > ตอนถาม token ให้วางแล้วกด Enter
   โปรแกรมจะจำไว้ในไฟล์ github-token.txt ครั้งต่อไปไม่ถามอีก
ห้ามส่งไฟล์ github-token.txt ให้ใคร (ไฟล์นี้ไม่ถูกใส่ใน zip อยู่แล้ว)

== กันคนแก้ไฟล์โปรแกรม (ตรวจไฟล์อัตโนมัติ) ==
- ตอนกด make-release.bat โปรแกรมจะเก็บ "ลายนิ้วมือ" (SHA-256) ของทุกไฟล์ไว้ใน version.json
- เครื่องอื่นจะเทียบไฟล์ของตัวเองกับลายนิ้วมือนี้ตอนเปิดโปรแกรม และทุก 30 นาที
- ถ้ามีไฟล์ถูกแก้หรือหายไป จะโหลดต้นฉบับจาก GitHub มาทับแล้วเปิดโปรแกรมใหม่เอง (วันละครั้ง)
- เครื่องผู้ดูแล (โฟลเดอร์ที่มี make-release.ps1 หรือ github-token.txt) จะไม่ถูกตรวจ จึงแก้ไฟล์เตรียมเวอร์ชันใหม่ได้ตามปกติ
- ห้ามส่ง make-release.ps1 / make-release.bat / github-token.txt ให้คนอื่น
