@echo off
cd /d "%~dp0"
if not exist "%~dp0LineDeck.ps1" (
    echo Not found: LineDeck.ps1
    pause
    exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%~dp0' -File | Unblock-File" >nul 2>&1
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%~dp0LineDeck.ps1"
exit /b 0
